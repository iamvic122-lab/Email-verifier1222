/*
 * export.js
 * -----------------------------------------------------------
 * Handles exporting collected leads to CSV, JSON, and Clipboard.
 * Everything here is local: a Blob download or a clipboard
 * write. Nothing is sent anywhere over the network.
 * -----------------------------------------------------------
 */

const LXExport = (() => {
  const COLUMNS = window.LX.COLUMNS;

  function downloadFile(content, fileName, contentType) {
    const a = document.createElement('a');
    const file = new Blob([content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function downloadCsv(leads, meta) {
    const headers = COLUMNS.map(c => c.label).join(',');
    const rows = leads.map(lead => {
      return COLUMNS.map(c => {
        let val = window.LX.exportValue(lead, c.key);
        val = String(val).replace(/"/g, '""');
        return `"${val}"`;
      }).join(',');
    });
    const csv = [headers, ...rows].join('\n');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    downloadFile(csv, `leads_export_${timestamp}.csv`, 'text/csv');
  }

  function downloadJson(leads, meta) {
    const data = {
      meta: {
        ...meta,
        exportedAt: new Date().toISOString(),
        count: leads.length
      },
      leads
    };
    const json = JSON.stringify(data, null, 2);
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    downloadFile(json, `leads_export_${timestamp}.json`, 'application/json');
  }

  async function copyAll(leads) {
    const headers = COLUMNS.map(c => c.label).join('\t');
    const rows = leads.map(lead => {
      return COLUMNS.map(c => window.LX.exportValue(lead, c.key)).map(window.LX.tsvEscape).join('\t');
    });
    const text = [headers, ...rows].join('\n');
    await navigator.clipboard.writeText(text);
  }

  return {
    downloadCsv,
    downloadJson,
    copyAll
  };
})();

window.LXExport = LXExport;
