(function () {
  // ---- Guard against double injection ----
  if (window.__LX_CONTENT_LOADED__) {
    window.LX && window.LX.log && window.LX.log('content script already loaded, skipping re-init');
    return;
  }
  window.__LX_CONTENT_LOADED__ = true;

  const U = window.LX; // utils
  const S = window.LXStorage; // storage
  if (!U || !S) {
    console.warn('[LX] utils or storage not loaded', { utils: !!U, storage: !!S });
    window.__LX_CONTENT_LOADED__ = false;
    return;
  }

  // ============================================================
  // 1. Logger
  // ============================================================
  const Logger = {
    _timestamp() {
      return new Date().toISOString();
    },
    info(...args)    { console.info('[LX][' + this._timestamp() + '][INFO]', ...args); },
    warning(...args) { console.warn('[LX][' + this._timestamp() + '][WARN]', ...args); },
    error(...args)   { console.error('[LX][' + this._timestamp() + '][ERROR]', ...args); }
  };

  // ============================================================
  // 2. Selectors (all in one place)
  // ============================================================
  const SEL = {
    resultRow: [
      'li.artdeco-list__item[data-x-search-result="LEAD"]',
      'li[data-x-search-result="LEAD"]',
      'li.artdeco-list__item.pl3.pv3',
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'div.artdeco-entity-lockup__content'
    ],
    personLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a.ember-view[href*="/sales/lead/"]'
    ],
    personName: [
      '[data-anonymize="person-name"]',
      'span[data-anonymize="person-name"]',
      '.artdeco-entity-lockup__title a',
      '.artdeco-entity-lockup__title span'
    ],
    jobTitle: [
      '[data-anonymize="title"]',
      '[data-anonymize="job-title"]',
      '.artdeco-entity-lockup__subtitle span[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle'
    ],
    companyLink: [
      'a[data-anonymize="company-name"]',
      'a[href*="/sales/company/"]'
    ],
    companyName: [
      '[data-anonymize="company-name"]',
      'a[data-anonymize="company-name"]'
    ],
    location: [
      '[data-anonymize="location"]',
      '.artdeco-entity-lockup__caption span[data-anonymize="location"]'
    ],
    employeeCount: [
      '[data-anonymize="company-size"]',
      '.artdeco-entity-lockup__metadata span:nth-child(1)',
      '.artdeco-entity-lockup__metadata'
    ],
    connectionDegree: [
      '.artdeco-entity-lockup__degree',
      'span.artdeco-entity-lockup__degree',
      '[data-test-connection-degree]'
    ],
    premiumBadge: [
      'li-icon[type="linkedin-premium-gold-icon"]',
      'svg[data-test-icon="premium-app-medium"]',
      '.premium-icon',
      'img[alt*="Premium"]'
    ],
    about: [
      '[data-anonymize="person-blurb"]',
      '.result-lockup__highlight-keyword',
      '.artdeco-entity-lockup__content p'
    ]
  };

  // ============================================================
  // 3. Page readiness + Extractor
  //    The extension still never scrolls/clicks/paginates. Before an
  //    extraction, it only waits for the manually-opened results to
  //    become stable so we don't capture a half-rendered page.
  // ============================================================
  const DEFAULT_READINESS = {
    stableMs: 700,
    timeoutMs: 15000,
    pollMs: 120
  };

  const PageReadiness = {
    _signature() {
      const rows = Extractor._findResultRows();
      const keys = rows.map((row) => {
        const a = Extractor._q(row, SEL.personLink);
        return a ? (a.getAttribute('href') || '') : '';
      }).filter(Boolean);
      return `${rows.length}|${keys.join('|')}`;
    },

    _hasBlockingLoader() {
      const selectors = [
        '[aria-busy="true"]',
        '[role="progressbar"]',
        '.artdeco-loader',
        '.search-results-container .loader'
      ];
      return selectors.some((selector) => {
        try {
          return Array.from(document.querySelectorAll(selector)).some((el) => {
            const style = window.getComputedStyle(el);
            const rect = el.getBoundingClientRect();
            return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
          });
        } catch (_) {
          return false;
        }
      });
    },

    async wait(options = {}) {
      const stableMs = Number(options.stableMs) > 0 ? Number(options.stableMs) : DEFAULT_READINESS.stableMs;
      const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_READINESS.timeoutMs;
      const pollMs = Number(options.pollMs) > 0 ? Number(options.pollMs) : DEFAULT_READINESS.pollMs;
      const startedAt = Date.now();
      let lastSignature = '';
      let stableSince = 0;
      let lastRowCount = 0;

      while (Date.now() - startedAt < timeoutMs) {
        const rows = Extractor._findResultRows();
        lastRowCount = rows.length;
        const signature = this._signature();
        const blocked = this._hasBlockingLoader();

        if (lastRowCount > 0 && signature === lastSignature && signature && !blocked) {
          if (!stableSince) stableSince = Date.now();
          if (Date.now() - stableSince >= stableMs) {
            return {
              ready: true,
              waitedMs: Date.now() - startedAt,
              rowsVisible: lastRowCount,
              reason: 'stable'
            };
          }
        } else {
          lastSignature = signature;
          stableSince = blocked || !signature ? 0 : Date.now();
        }

        await new Promise((resolve) => setTimeout(resolve, pollMs));
      }

      return {
        ready: false,
        waitedMs: Date.now() - startedAt,
        rowsVisible: lastRowCount,
        reason: lastRowCount ? 'timeout-unstable' : 'timeout-no-results'
      };
    }
  };

  const Extractor = {
    _q(root, selectors) {
      for (const s of selectors) {
        try {
          const el = root.querySelector(s);
          if (el) return el;
        } catch (_) { /* ignore */ }
      }
      return null;
    },

    _text(el) { return el ? U.cleanText(el.textContent) : ''; },

    _dedupeRows(rows) {
      const seen = new Set();
      const result = [];
      for (const row of rows || []) {
        const a = this._q(row, SEL.personLink) || row.querySelector('a[href*="/sales/lead/"]');
        const href = a ? U.convertLeadUrl(a.getAttribute('href') || '') : '';
        const key = href || row;
        if (seen.has(key)) continue;
        seen.add(key);
        result.push(row);
      }
      return result;
    },

    _findResultRows() {
      for (const sel of SEL.resultRow) {
        try {
          const list = document.querySelectorAll(sel);
          if (list && list.length > 3) return this._dedupeRows(Array.from(list));
        } catch (_) { /* ignore */ }
      }
      // Fallback: infer rows from anchors
      const anchors = document.querySelectorAll('a[href*="/sales/lead/"]');
      const rows = new Set();
      anchors.forEach((a) => {
        const li = a.closest('li') || a.closest('article') || a.closest('div[class*="lockup"]');
        if (li) rows.add(li);
      });
      return this._dedupeRows(Array.from(rows));
    },

    extractLead(row, index = 0) {
      if (!row) return null;
      const personA = this._q(row, SEL.personLink) || row.querySelector('a[href*="/sales/lead/"]');
      if (!personA) return null;
      const rawPersonUrl = personA.getAttribute('href') || '';
      const personLinkedInUrl = U.convertLeadUrl(rawPersonUrl);
      if (!personLinkedInUrl) return null;

      let personName = this._text(this._q(row, SEL.personName));
      if (!personName) personName = this._text(personA);

      let jobTitle = this._text(this._q(row, SEL.jobTitle));
      if (jobTitle) {
        jobTitle = jobTitle.split(/\d+\s*year|\d+\s*month|in role|in company/i)[0].trim();
        jobTitle = jobTitle.replace(/[,·•]$/, '').trim();
      }

      const companyA = this._q(row, SEL.companyLink);
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      let companyLinkedInUrl = '';
      if (companyA) {
        const rawCo = companyA.getAttribute('href') || '';
        companyLinkedInUrl = U.convertCompanyUrl(rawCo);
      }

      if (jobTitle && companyName) {
        const atIdx = jobTitle.toLowerCase().lastIndexOf(' at ' + companyName.toLowerCase());
        if (atIdx > 0) jobTitle = jobTitle.slice(0, atIdx).trim();
      }

      if (!jobTitle) {
        const candidates = Array.from(row.querySelectorAll('span, div'))
          .map((el) => this._text(el))
          .filter(Boolean)
          .filter((t) => t !== personName && t !== companyName && t.length < 120);
        const skipWords = /^(1st|2nd|3rd|3\+|connect|message|save|premium|open profile|view profile)$/i;
        const guess = candidates.find((t) => !skipWords.test(t) && !/^\d+\s*(year|month|employee)/i.test(t));
        if (guess) jobTitle = guess;
      }

      // Tenure ("2 years 5 months in role", "4 years in company") is
      // rendered as plain text near the title, not behind a stable
      // selector, so it's read off the row's own visible text.
      const rowText = this._text(row);
      const roleMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in role/i);
      const companyTenureMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in company/i);
      const yearsInRole = roleMatch ? U.cleanText(roleMatch[1]) : '';
      const yearsInCompany = companyTenureMatch ? U.cleanText(companyTenureMatch[1]) : '';

      const location = this._text(this._q(row, SEL.location));
      let connectionDegree = this._text(this._q(row, SEL.connectionDegree));
      if (connectionDegree) {
        const dm = connectionDegree.match(/(1st|2nd|3rd|3\+|Out of network|Following|You)/i);
        if (dm) connectionDegree = dm[1];
      }
      const premium = !!this._q(row, SEL.premiumBadge);

      let about = this._text(this._q(row, SEL.about));
      if (!about) {
        const p = row.querySelector('p');
        if (p) about = this._text(p);
      }
      if (about) about = about.replace(/\s*…\s*Show more$/i, '').trim();

      let employeeCount = this._text(this._q(row, SEL.employeeCount));
      if (employeeCount) {
        if (employeeCount.includes('·')) employeeCount = employeeCount.split('·')[0].trim();
        if (!/\d/.test(employeeCount)) employeeCount = '';
      }

      return U.normalizeLead({
        personName,
        jobTitle,
        companyName,
        location,
        connectionDegree,
        premium,
        about,
        yearsInRole,
        yearsInCompany,
        personLinkedInUrl,
        companyLinkedInUrl,
        employeeCount,
        sourceRow: index + 1,
        leadId: U.extractLeadId(personLinkedInUrl),
        companyId: U.extractCompanyId(companyLinkedInUrl),
        capturedAt: new Date().toISOString(),
        capturedFromUrl: window.location.href
      });
    },

    extractAll() {
      const rows = this._findResultRows();
      const leads = [];
      const seen = new Set();
      rows.forEach((row, i) => {
        try {
          const lead = this.extractLead(row, i);
          if (!lead || !lead.personLinkedInUrl) return;
          const key = lead.personLinkedInUrl.toLowerCase();
          if (seen.has(key)) return;
          seen.add(key);
          leads.push(lead);
        } catch (err) {
          Logger.error('Row extraction failed', err);
        }
      });
      return leads;
    }
  };

  // ============================================================
  // 4. Message Bridge — two messages only. No loops, no timers,
  //    nothing runs unless the popup asks for it right now.
  // ============================================================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return false;

    // Ping: let the popup know this tab is a Sales Navigator page
    // and how many result rows are currently visible.
    if (msg.type === 'LX_PING') {
      sendResponse({
        ok: true,
        url: window.location.href,
        onSearch: /\/sales\/(search|lists|people)/.test(window.location.pathname),
        rowsVisible: Extractor._findResultRows().length,
        loading: PageReadiness._hasBlockingLoader()
      });
      return true;
    }

    // Wait only for the manually-opened result set to become stable.
    // This never scrolls, clicks, paginates, or runs unattended.
    if (msg.type === 'LX_EXTRACT_PAGE') {
      (async () => {
        try {
          const settings = await S.getSettings();
          const readiness = await PageReadiness.wait({
            stableMs: settings.readinessWaitMs,
            timeoutMs: settings.readinessTimeoutMs
          });

          if (!readiness.ready) {
            const suffix = readiness.reason === 'timeout-no-results'
              ? ' No lead rows became available.'
              : ' The visible results kept changing.';
            sendResponse({
              ok: false,
              reason: `Page did not finish rendering within ${Math.round(readiness.waitedMs / 1000)}s.${suffix}`,
              readiness
            });
            return;
          }

          const rows = Extractor.extractAll();
          const result = await S.mergeLeads(rows);
          await S.setMeta({
            lastUpdate: new Date().toISOString(),
            lastUrl: window.location.href,
            lastCount: result.all.length,
            lastReadiness: readiness
          });
          Logger.info(`Extracted ${rows.length} row(s) on page, ${result.added.length} new, ${result.updated.length} updated`);
          sendResponse({
            ok: true,
            foundOnPage: rows.length,
            added: result.added.length,
            updated: result.updated.length,
            changed: result.changed,
            waitedMs: readiness.waitedMs,
            totalLeads: result.all.length,
            leads: result.all
          });
        } catch (err) {
          Logger.error('Extraction failed', err);
          sendResponse({ ok: false, reason: (err && err.message) || 'Extraction failed' });
        }
      })();
      return true; // keep the message channel open for the async response
    }

    return false;
  });

  Logger.info('content script ready on', location.href);
})();
