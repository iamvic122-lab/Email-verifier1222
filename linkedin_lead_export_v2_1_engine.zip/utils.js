/*
 * utils.js
 * -----------------------------------------------------------
 * Shared helpers: URL normalization, text cleanup, data quality,
 * CSV/TSV escaping, and the column schema used by the table + exports.
 * -----------------------------------------------------------
 */

if (typeof self !== 'undefined' && self.__LX_UTILS_LOADED__) {
  // already loaded
} else {
if (typeof self !== 'undefined') self.__LX_UTILS_LOADED__ = true;

const LX = (typeof window !== 'undefined' && window.LX) || (typeof self !== 'undefined' && self.LX) || {};
(function attach(root) {

  root.NA = 'N/A';

  root.convertLeadUrl = function convertLeadUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let url = String(rawUrl).trim();
      if (url.startsWith('/')) url = 'https://www.linkedin.com' + url;
      url = url.split('?')[0].split('#')[0];
      url = url.replace('/sales/lead/', '/in/');
      const commaIdx = url.indexOf(',');
      if (commaIdx !== -1) url = url.substring(0, commaIdx);
      return url;
    } catch (e) {
      return rawUrl;
    }
  };

  root.convertCompanyUrl = function convertCompanyUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let url = String(rawUrl).trim();
      if (url.startsWith('/')) url = 'https://www.linkedin.com' + url;
      url = url.split('?')[0].split('#')[0];
      url = url.replace('/sales/company/', '/company/');
      const commaIdx = url.indexOf(',');
      if (commaIdx !== -1) url = url.substring(0, commaIdx);
      return url;
    } catch (e) {
      return rawUrl;
    }
  };

  root.extractLeadId = function extractLeadId(inUrl) {
    if (!inUrl) return '';
    const m = String(inUrl).match(/\/in\/([^/?#,]+)/);
    return m ? m[1] : '';
  };

  root.extractCompanyId = function extractCompanyId(companyUrl) {
    if (!companyUrl) return '';
    const m = String(companyUrl).match(/\/company\/([^/?#,]+)/);
    return m ? m[1] : '';
  };

  root.cleanText = function cleanText(txt) {
    if (txt == null) return '';
    return String(txt).replace(/\s+/g, ' ').trim();
  };

  root.displayValue = function displayValue(val) {
    if (val == null || String(val).trim() === '') return root.NA;
    return String(val).trim();
  };

  root.normalizeLead = function normalizeLead(lead) {
    const next = { ...(lead || {}) };
    const textFields = [
      'personName', 'jobTitle', 'companyName', 'location',
      'connectionDegree', 'about', 'yearsInRole', 'yearsInCompany',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount'
    ];

    for (const key of textFields) {
      const value = next[key];
      next[key] = root.cleanText(value);
    }

    next.premium = !!next.premium;
    next.sourceRow = Number.isFinite(Number(next.sourceRow)) ? Number(next.sourceRow) : 0;
    next.leadId = next.leadId || root.extractLeadId(next.personLinkedInUrl);
    next.companyId = next.companyId || root.extractCompanyId(next.companyLinkedInUrl);
    next.capturedAt = next.capturedAt || new Date().toISOString();
    next.lastSeenAt = next.lastSeenAt || next.capturedAt;
    next.dataQuality = root.calculateDataQuality(next);
    return next;
  };

  root.calculateDataQuality = function calculateDataQuality(lead) {
    const required = [
      'personName', 'jobTitle', 'companyName', 'location',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount',
      'connectionDegree', 'yearsInRole', 'yearsInCompany', 'about'
    ];
    let present = 0;
    for (const key of required) {
      if (lead && lead[key] != null && String(lead[key]).trim() !== '') present += 1;
    }
    const percent = Math.round((present / required.length) * 100);
    return {
      percent,
      status: percent >= 80 ? 'complete' : percent >= 50 ? 'partial' : 'weak'
    };
  };

  root.csvEscape = function csvEscape(val) {
    const s = val == null ? '' : String(val);
    if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  };

  root.tsvEscape = function tsvEscape(val) {
    const s = val == null ? '' : String(val);
    return s.replace(/[\t\r\n]+/g, ' ').trim();
  };

  root.COLUMNS = [
    { key: 'personName',         label: 'Person Name' },
    { key: 'jobTitle',           label: 'Job Title' },
    { key: 'personLinkedInUrl',  label: 'Person LinkedIn URL' },
    { key: 'companyName',        label: 'Company Name' },
    { key: 'companyLinkedInUrl', label: 'Company LinkedIn URL' },
    { key: 'location',           label: 'Location' },
    { key: 'employeeCount',      label: 'Employee Count' },
    { key: 'connectionDegree',   label: 'Connection Degree' },
    { key: 'yearsInRole',        label: 'Years in Role' },
    { key: 'yearsInCompany',     label: 'Years in Company' },
    { key: 'about',              label: 'About' },
    { key: 'dataQuality',        label: 'Data Quality' }
  ];

  root.exportValue = function exportValue(lead, key) {
    if (key === 'dataQuality') {
      const q = lead && lead.dataQuality;
      if (!q) return root.NA;
      return `${q.percent}% ${q.status}`;
    }
    return root.displayValue(lead && lead[key]);
  };

  root.log = function log(...args) {
    try { console.log('%c[LX]', 'color:#0A66C2;font-weight:bold;', ...args); } catch (_) {}
  };

  root.clone = (v) => JSON.parse(JSON.stringify(v));

  if (typeof window !== 'undefined') window.LX = root;
  if (typeof self   !== 'undefined') self.LX   = root;
  if (typeof globalThis !== 'undefined') globalThis.LX = root;

})(LX);

} // end guard
