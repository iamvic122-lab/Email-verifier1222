# Sales Navigator Lead Export — v2.1.0

A Chrome extension that turns the Sales Navigator search page you're
currently looking at into a CSV, JSON, or clipboard export. You browse;
it copies what's already on your screen into a spreadsheet-friendly format.

## What it does

- Reads the lead cards rendered on the current page (name, title, company,
  location, connection degree, employee count, profile/company URLs).
- Saves them locally in the browser (`chrome.storage.local`) so results from
  multiple pages accumulate as you go.
- Upserts by normalized profile URL instead of blindly discarding repeat
  captures; a later capture can enrich an existing lead.
- Normalizes missing export fields to `N/A` and records a simple data-quality
  percentage/status (`complete`, `partial`, or `weak`).
- Records the source page URL correctly and keeps the original capture time
  stable while tracking the latest observation internally.
- Exports everything to CSV, JSON, or your clipboard, on demand.

## What it deliberately does NOT do

This is a rebuild of an earlier version that auto-scrolled, auto-paged
through search results, and randomized its timing/scroll behavior
specifically to look human to LinkedIn's bot detection. That version has
been removed, not just disabled:

- **No auto-scroll.** Nothing scrolls the page for you.
- **No auto-pagination.** Nothing clicks "next page" for you.
- **No timing randomization or "human-like" behavior simulation.**
- **No unattended/background runs, and nothing to resume** — every
  extraction happens once, synchronously, because you clicked a button.

Extraction only reads the result cards already rendered by the page you're
manually viewing. Before extracting, v2.1 waits briefly for the visible
result set to become stable, with a hard timeout, so it doesn't capture a
half-rendered list. It still never scrolls, clicks, paginates, or runs in
the background.

## Why that matters

LinkedIn's User Agreement and the Sales Navigator terms prohibit bots,
scraping, and automated data collection, and LinkedIn actively enforces
this (account restrictions, and legal action against tool vendors in the
past). Removing the automation and detection-evasion pieces doesn't make
large-scale extraction "allowed," but it does mean the tool no longer
tries to impersonate a human to get around detection, and it puts a real
person's manual, page-by-page browsing back in the loop rather than
running unattended at scale. You're responsible for how you use it —
worth reading LinkedIn's current terms for your account/plan before
relying on this for anything beyond light personal use.

## Install (unpacked, for personal use / development)

1. Open `chrome://extensions`.
2. Enable **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Open a Sales Navigator search on linkedin.com, click the extension
   icon, then **Extract This Page**.
5. Use **Copy All**, **Download CSV**, or **Download JSON** whenever
   you're ready to export what's been collected.

## v2.1 engine changes

- **Page readiness:** waits for the visible result set to stop changing and
  for common loading indicators to clear. Default stable window: 700 ms.
  Default maximum wait: 15 seconds.
- **Safe extraction:** de-duplicates result rows and leads within the same
  extraction before storage.
- **Enrichment:** repeated captures are merged field-by-field instead of
  being ignored.
- **Missing values:** exported/table values show `N/A` rather than blanks or
  em-dashes.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | Extension config (Manifest V3), scoped to `linkedin.com/sales/*` only |
| `content.js` | Waits for visible results to stabilize, then reads lead data on request — no automation |
| `popup.html` / `popup.css` / `popup.js` | The extension popup UI |
| `storage.js` | Local storage, normalization, de-duplication, and lead upserts |
| `utils.js` | URL/text formatting helpers, column schema |
| `export.js` | CSV / JSON / clipboard export (all local — nothing is sent anywhere) |
| `background.js` | Minimal service worker (install lifecycle only) |

## Data & privacy

Everything stays on your machine: leads are stored in the browser's local
extension storage and exported straight to a file or your clipboard.
Nothing is transmitted to any server.
