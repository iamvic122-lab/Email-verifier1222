/*
 * storage.js
 * -----------------------------------------------------------
 * Thin async wrapper around chrome.storage.local for
 * settings + collected leads + session metadata.
 *
 * Leads are normalized and upserted by profile URL. A later
 * extraction can enrich an existing lead instead of discarding it.
 * -----------------------------------------------------------
 */

if (typeof self !== 'undefined' && self.__LX_STORAGE_LOADED__) {
  // already loaded
} else {
if (typeof self !== 'undefined') self.__LX_STORAGE_LOADED__ = true;

const LXStorage = (() => {

  const KEYS = {
    LEADS:    'lx_leads',
    SETTINGS: 'lx_settings',
    META:     'lx_meta'
  };

  const DEFAULT_SETTINGS = {
    autoDownload: false,
    darkMode: true,
    readinessWaitMs: 700,
    readinessTimeoutMs: 15000
  };

  function get(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  }
  function set(obj) {
    return new Promise((resolve) => chrome.storage.local.set(obj, resolve));
  }
  function remove(keys) {
    return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
  }

  async function getSettings() {
    const r = await get(KEYS.SETTINGS);
    return { ...DEFAULT_SETTINGS, ...(r[KEYS.SETTINGS] || {}) };
  }

  async function saveSettings(patch) {
    const cur = await getSettings();
    const next = { ...cur, ...patch };
    await set({ [KEYS.SETTINGS]: next });
    return next;
  }

  async function getLeads() {
    const r = await get(KEYS.LEADS);
    if (!Array.isArray(r[KEYS.LEADS])) return [];
    return r[KEYS.LEADS].map((lead) => window.LX.normalizeLead(lead));
  }

  function leadKey(lead) {
    return String((lead && (lead.personLinkedInUrl || lead.leadId)) || '').trim().toLowerCase();
  }

  function mergeField(oldValue, newValue) {
    const oldText = oldValue == null ? '' : String(oldValue).trim();
    const newText = newValue == null ? '' : String(newValue).trim();
    if (!newText) return oldValue || '';
    if (!oldText) return newValue;
    // Prefer the newer value when it is materially richer.
    if (newText.length > oldText.length + 8) return newValue;
    return oldValue;
  }

  function mergeLead(existing, incoming) {
    const merged = { ...existing };
    const fields = [
      'personName', 'jobTitle', 'companyName', 'location',
      'connectionDegree', 'about', 'yearsInRole', 'yearsInCompany',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount'
    ];
    for (const key of fields) merged[key] = mergeField(existing[key], incoming[key]);
    merged.premium = !!(existing.premium || incoming.premium);
    merged.sourceRow = incoming.sourceRow || existing.sourceRow || 0;
    merged.capturedFromUrl = incoming.capturedFromUrl || existing.capturedFromUrl || '';
    // Keep the original capture timestamp stable. Add a separate lastSeenAt
    // marker without counting every repeated extraction as a data update.
    merged.capturedAt = existing.capturedAt || incoming.capturedAt || new Date().toISOString();
    merged.lastSeenAt = incoming.capturedAt || existing.lastSeenAt || merged.capturedAt;
    merged.leadId = merged.leadId || incoming.leadId || window.LX.extractLeadId(merged.personLinkedInUrl);
    merged.companyId = merged.companyId || incoming.companyId || window.LX.extractCompanyId(merged.companyLinkedInUrl);
    return window.LX.normalizeLead(merged);
  }

  // Upsert freshly-extracted leads into storage, keyed by profile URL.
  // Returns both newly-added and enriched/updated records.
  async function mergeLeads(newLeads) {
    const existing = await getLeads();
    const byKey = new Map();
    const order = [];

    for (const lead of existing) {
      const normalized = window.LX.normalizeLead(lead);
      const key = leadKey(normalized);
      if (!key) continue;
      if (!byKey.has(key)) order.push(key);
      byKey.set(key, normalized);
    }

    const added = [];
    const updated = [];

    for (const rawLead of (Array.isArray(newLeads) ? newLeads : [])) {
      const incoming = window.LX.normalizeLead(rawLead);
      const key = leadKey(incoming);
      if (!key) continue;

      const current = byKey.get(key);
      if (!current) {
        byKey.set(key, incoming);
        order.push(key);
        added.push(incoming);
        continue;
      }

      const merged = mergeLead(current, incoming);
      const compareKeys = [
        'personName', 'jobTitle', 'companyName', 'location',
        'connectionDegree', 'premium', 'about', 'yearsInRole',
        'yearsInCompany', 'personLinkedInUrl', 'companyLinkedInUrl',
        'employeeCount', 'leadId', 'companyId', 'capturedFromUrl', 'dataQuality'
      ];
      const changed = compareKeys.some((field) => JSON.stringify(merged[field]) !== JSON.stringify(current[field]));
      byKey.set(key, merged);
      if (changed) updated.push(merged);
    }

    const all = order.map((key) => byKey.get(key)).filter(Boolean);
    await set({ [KEYS.LEADS]: all });
    return { all, added, updated, changed: added.length + updated.length };
  }

  async function clearLeads() {
    await remove(KEYS.LEADS);
  }

  async function getMeta() {
    const r = await get(KEYS.META);
    return r[KEYS.META] || {};
  }

  async function setMeta(patch) {
    const cur = await getMeta();
    const next = { ...cur, ...patch };
    await set({ [KEYS.META]: next });
    return next;
  }

  return {
    KEYS,
    DEFAULT_SETTINGS,
    getSettings, saveSettings,
    getLeads, mergeLeads, clearLeads,
    getMeta, setMeta
  };
})();

if (typeof self !== 'undefined') self.LXStorage = LXStorage;
if (typeof window !== 'undefined') window.LXStorage = LXStorage;

} // end guard
