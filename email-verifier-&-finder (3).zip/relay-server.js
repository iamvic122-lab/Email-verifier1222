/**
 * ============================================================================
 * SMTP RELAY SERVER FOR EMAIL VERIFIER
 * ============================================================================
 *
 * Run:
 *
 *     node relay-server.js
 *
 * This server needs to run on a machine/network/VPS where outbound TCP
 * port 25 is available.
 *
 * The AI Studio application sends:
 *
 *     POST /api/check
 *
 *     {
 *       "email": "person@example.com",
 *       "mxHost": "mail.example.com"
 *     }
 *
 * The relay returns:
 *
 *     {
 *       "smtp": {
 *         "status": "accepted",
 *         "accepted": true,
 *         "code": 250,
 *         "mxHost": "mail.example.com",
 *         "reason": "..."
 *       },
 *       "catchAll": {
 *         "catchAll": false,
 *         "testAddress": "...",
 *         "reason": "..."
 *       }
 *     }
 *
 * IMPORTANT:
 *
 * This relay NEVER sends an email.
 *
 * It only performs:
 *
 *     EHLO
 *     MAIL FROM
 *     RCPT TO
 *
 * followed by QUIT.
 *
 * No DATA command is issued.
 *
 * SECURITY:
 *
 * Keep this relay private. Do not expose an unauthenticated SMTP-probing
 * service to the public internet. Use a firewall, VPN, reverse proxy,
 * private network, or another appropriate access-control mechanism.
 *
 * ============================================================================
 */

import http from "node:http";
import net from "node:net";
import dns from "node:dns/promises";
import crypto from "node:crypto";
import { URL } from "node:url";

const PORT = Number(
  process.env.PORT || 8787
);

const HOST =
  process.env.HOST || "0.0.0.0";

const SMTP_TIMEOUT_MS = 8000;

const MAX_BODY_BYTES =
  16 * 1024;

// -----------------------------------------------------------------------------
// JSON response helper
// -----------------------------------------------------------------------------

function json(res, statusCode, body) {
  const payload =
    JSON.stringify(body);

  res.writeHead(statusCode, {
    "Content-Type":
      "application/json; charset=utf-8",

    "Content-Length":
      Buffer.byteLength(payload),

    "Cache-Control":
      "no-store",
  });

  res.end(payload);
}

// -----------------------------------------------------------------------------
// SMTP response parser
// -----------------------------------------------------------------------------

function parseCode(line) {
  const match =
    String(line || "")
      .match(/^(\d{3})[ -]/);

  return match
    ? Number(match[1])
    : null;
}

// -----------------------------------------------------------------------------
// Read a complete SMTP response
// -----------------------------------------------------------------------------

function readResponse(socket) {
  return new Promise(
    (resolve, reject) => {

      let buffer = "";

      const timer =
        setTimeout(() => {
          cleanup();

          reject(
            new Error(
              "SMTP response timeout"
            )
          );
        }, SMTP_TIMEOUT_MS);

      const cleanup = () => {
        clearTimeout(timer);

        socket.removeListener(
          "data",
          onData
        );

        socket.removeListener(
          "error",
          onError
        );

        socket.removeListener(
          "close",
          onClose
        );
      };

      const onError = (error) => {
        cleanup();
        reject(error);
      };

      const onClose = () => {
        if (!buffer) {
          cleanup();

          reject(
            new Error(
              "SMTP connection closed unexpectedly"
            )
          );
        }
      };

      const onData = (chunk) => {
        buffer +=
          chunk.toString("utf8");

        const lines =
          buffer.split(/\r?\n/);

        for (const line of lines) {

          /*
           * SMTP multiline responses use:
           *
           * 250-example
           * 250-SIZE 123
           * 250 final
           *
           * The final line has a space after
           * the numeric response code.
           */

          if (/^\d{3} /.test(line)) {

            cleanup();

            resolve({
              code: parseCode(line),
              line: line.trim(),
              raw: buffer,
            });

            return;
          }
        }
      };

      socket.on(
        "data",
        onData
      );

      socket.once(
        "error",
        onError
      );

      socket.once(
        "close",
        onClose
      );
    }
  );
}

// -----------------------------------------------------------------------------
// Send an SMTP command
// -----------------------------------------------------------------------------

function command(socket, text) {
  return new Promise(
    (resolve, reject) => {

      socket.write(
        `${text}\r\n`,
        (error) => {

          if (error) {
            reject(error);
          } else {
            resolve();
          }

        }
      );

    }
  );
}

// -----------------------------------------------------------------------------
// Connect to SMTP server on TCP port 25
// -----------------------------------------------------------------------------

function connect(host) {
  return new Promise(
    (resolve, reject) => {

      const socket =
        new net.Socket();

      let settled = false;

      const timer =
        setTimeout(() => {

          if (!settled) {

            settled = true;

            socket.destroy();

            const error =
              new Error(
                "SMTP connection timed out"
              );

            error.code =
              "ETIMEDOUT";

            reject(error);
          }

        }, SMTP_TIMEOUT_MS);

      socket.setTimeout(
        SMTP_TIMEOUT_MS
      );

      socket.once(
        "connect",
        () => {

          if (!settled) {

            settled = true;

            clearTimeout(timer);

            resolve(socket);
          }

        }
      );

      socket.once(
        "error",
        (error) => {

          if (!settled) {

            settled = true;

            clearTimeout(timer);

            socket.destroy();

            reject(error);
          }

        }
      );

      socket.once(
        "timeout",
        () => {

          if (!settled) {

            settled = true;

            clearTimeout(timer);

            socket.destroy();

            const error =
              new Error(
                "SMTP socket timeout"
              );

            error.code =
              "ETIMEDOUT";

            reject(error);
          }

        }
      );

      socket.connect(
        25,
        host
      );

    }
  );
}

// -----------------------------------------------------------------------------
// Perform one SMTP mailbox probe
// -----------------------------------------------------------------------------

async function smtpProbe(
  email,
  mxHost
) {

  let socket = null;

  try {

    socket =
      await connect(mxHost);

    // -----------------------------------------------------------------------
    // SMTP greeting
    // -----------------------------------------------------------------------

    const greeting =
      await readResponse(socket);

    if (
      !greeting.code ||
      greeting.code >= 400
    ) {

      return {
        status: "unknown",
        accepted: null,
        code: greeting.code,
        mxHost,

        reason:
          `Mail server rejected connection greeting: ${greeting.line}`,
      };
    }

    // -----------------------------------------------------------------------
    // EHLO
    // -----------------------------------------------------------------------

    await command(
      socket,
      "EHLO verifier-relay.internal"
    );

    const ehlo =
      await readResponse(socket);

    if (
      !ehlo.code ||
      ehlo.code >= 400
    ) {

      return {
        status: "unknown",
        accepted: null,
        code: ehlo.code,
        mxHost,

        reason:
          `SMTP EHLO failed: ${ehlo.line}`,
      };
    }

    // -----------------------------------------------------------------------
    // Envelope sender
    //
    // This does NOT send an email.
    // -----------------------------------------------------------------------

    await command(
      socket,
      "MAIL FROM:<verify-probe@internal.net>"
    );

    const mailFrom =
      await readResponse(socket);

    if (
      !mailFrom.code ||
      mailFrom.code >= 400
    ) {

      return {
        status: "unknown",
        accepted: null,
        code: mailFrom.code,
        mxHost,

        reason:
          `Mail server rejected MAIL FROM probe (${mailFrom.code})`,
      };
    }

    // -----------------------------------------------------------------------
    // Recipient test
    //
    // RCPT TO is the final command we issue.
    // We NEVER issue DATA.
    // -----------------------------------------------------------------------

    await command(
      socket,
      `RCPT TO:<${email}>`
    );

    const rcpt =
      await readResponse(socket);

    const code =
      rcpt.code;

    // 2xx = recipient accepted

    if (
      code !== null &&
      code >= 200 &&
      code < 300
    ) {

      return {
        status: "accepted",
        accepted: true,
        code,
        mxHost,

        reason:
          `SMTP server accepted mailbox (${code} OK)`,
      };
    }

    // 5xx = permanent rejection

    if (
      code !== null &&
      code >= 500 &&
      code < 600
    ) {

      return {
        status: "rejected",
        accepted: false,
        code,
        mxHost,

        reason:
          `SMTP server rejected mailbox (${code} User Unknown)`,
      };
    }

    // 4xx = temporary rejection/defer

    if (
      code !== null &&
      code >= 400 &&
      code < 500
    ) {

      return {
        status: "deferred",
        accepted: null,
        code,
        mxHost,

        reason:
          `SMTP server temporarily deferred recipient (${code})`,
      };
    }

    return {
      status: "unknown",
      accepted: null,
      code,
      mxHost,

      reason:
        `Unexpected SMTP response code: ${code}`,
    };

  } catch (error) {

    return {
      status: "unknown",
      accepted: null,
      code: null,
      mxHost,

      reason:
        `Could not connect to mail server on port 25 (${error.code || error.message})`,
    };

  } finally {

    if (socket) {

      try {
        await command(
          socket,
          "QUIT"
        );
      } catch {
        // Ignore QUIT failures during cleanup.
      }

      socket.destroy();
    }
  }
}

// -----------------------------------------------------------------------------
// Catch-all detection
// -----------------------------------------------------------------------------

async function catchAllProbe(
  domain,
  mxHost
) {

  const fakeEmail =
    `verify-catchall-${crypto.randomBytes(10).toString("hex")}@${domain}`;

  const smtp =
    await smtpProbe(
      fakeEmail,
      mxHost
    );

  if (
    smtp.accepted === true
  ) {

    return {
      catchAll: true,
      testAddress: fakeEmail,

      reason:
        "Domain is catch-all: mail server accepted a random mailbox",
    };
  }

  if (
    smtp.accepted === false
  ) {

    return {
      catchAll: false,
      testAddress: fakeEmail,

      reason:
        "Domain is not catch-all: random test mailbox was rejected",
    };
  }

  return {
    catchAll: null,
    testAddress: fakeEmail,

    reason:
      "Could not determine catch-all status because the SMTP probe was inconclusive",
  };
}

// -----------------------------------------------------------------------------
// Basic validation
// -----------------------------------------------------------------------------

function validEmail(email) {

  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    .test(email);

}

function validHostname(host) {

  return (
    typeof host === "string" &&
    host.length > 0 &&
    host.length <= 253 &&
    /^[a-zA-Z0-9.-]+$/.test(host) &&
    !host.includes("..") &&
    !host.startsWith(".") &&
    !host.endsWith(".")
  );

}

// -----------------------------------------------------------------------------
// Basic SSRF protection
//
// The relay should not be usable to probe private infrastructure.
// -----------------------------------------------------------------------------

function isPrivateIPv4(
  address
) {

  const parts =
    address
      .split(".")
      .map(Number);

  if (
    parts.length !== 4 ||
    parts.some(Number.isNaN)
  ) {
    return false;
  }

  const [
    a,
    b
  ] = parts;

  return (
    a === 10 ||
    a === 127 ||
    (a === 172 &&
      b >= 16 &&
      b <= 31) ||
    (a === 192 &&
      b === 168) ||
    a === 0 ||
    (a === 169 &&
      b === 254)
  );
}

function isPrivateIPv6(
  address
) {

  const value =
    address.toLowerCase();

  return (
    value === "::1" ||
    value === "::" ||
    value.startsWith("fc") ||
    value.startsWith("fd") ||
    value.startsWith("fe8") ||
    value.startsWith("fe9") ||
    value.startsWith("fea") ||
    value.startsWith("feb")
  );
}

async function rejectPrivateDestination(
  host
) {

  if (!validHostname(host)) {
    throw new Error(
      "Invalid mxHost"
    );
  }

  const records =
    await dns.lookup(
      host,
      { all: true }
    );

  if (!records.length) {
    throw new Error(
      "mxHost does not resolve"
    );
  }

  for (const record of records) {

    if (
      (
        record.family === 4 &&
        isPrivateIPv4(
          record.address
        )
      ) ||
      (
        record.family === 6 &&
        isPrivateIPv6(
          record.address
        )
      )
    ) {

      throw new Error(
        "mxHost resolves to a private/reserved address"
      );

    }
  }
}

// -----------------------------------------------------------------------------
// Read JSON request body
// -----------------------------------------------------------------------------

function readJsonBody(req) {

  return new Promise(
    (resolve, reject) => {

      let body = "";

      req.on(
        "data",
        (chunk) => {

          body +=
            chunk.toString("utf8");

          if (
            Buffer.byteLength(body) >
            MAX_BODY_BYTES
          ) {

            reject(
              new Error(
                "Request body too large"
              )
            );

            req.destroy();
          }

        }
      );

      req.on(
        "end",
        () => {

          try {

            resolve(
              JSON.parse(
                body || "{}"
              )
            );

          } catch {

            reject(
              new Error(
                "Request body must be valid JSON"
              )
            );

          }

        }
      );

      req.on(
        "error",
        reject
      );

    }
  );
}

// -----------------------------------------------------------------------------
// HTTP server
// -----------------------------------------------------------------------------

const server =
  http.createServer(
    async (req, res) => {

      try {

        const requestUrl =
          new URL(
            req.url || "/",
            `http://${req.headers.host || "localhost"}`
          );

        // -------------------------------------------------------------------
        // Health check
        // -------------------------------------------------------------------

        if (
          req.method === "GET" &&
          requestUrl.pathname === "/health"
        ) {

          return json(
            res,
            200,
            {
              ok: true,
              service:
                "email-verifier-smtp-relay",
              smtpPort: 25,
            }
          );

        }

        // -------------------------------------------------------------------
        // Main relay endpoint
        // -------------------------------------------------------------------

        if (
          req.method !== "POST" ||
          requestUrl.pathname !== "/api/check"
        ) {

          return json(
            res,
            404,
            {
              error: "Not found",
            }
          );

        }

        const body =
          await readJsonBody(req);

        const email =
          String(
            body.email || ""
          )
            .trim()
            .toLowerCase();

        const mxHost =
          String(
            body.mxHost || ""
          )
            .trim()
            .replace(/\.$/, "");

        if (
          !validEmail(email)
        ) {

          return json(
            res,
            400,
            {
              error:
                "A valid email is required",
            }
          );

        }

        if (
          !validHostname(mxHost)
        ) {

          return json(
            res,
            400,
            {
              error:
                "A valid MX hostname is required",
            }
          );

        }

        // Prevent the relay from becoming an arbitrary internal
        // network probing service.
        await rejectPrivateDestination(
          mxHost
        );

        const domain =
          email.split("@")[1];

        // Real mailbox probe.
        const smtp =
          await smtpProbe(
            email,
            mxHost
          );

        // Catch-all probe.
        let catchAll = {
          catchAll: null,

          reason:
            "Catch-all probe skipped because the SMTP mailbox probe was inconclusive",
        };

        if (
          smtp.status === "accepted"
        ) {

          catchAll =
            await catchAllProbe(
              domain,
              mxHost
            );

        }

        return json(
          res,
          200,
          {
            smtp,
            catchAll,
          }
        );

      } catch (error) {

        console.error(
          "SMTP relay error:",
          error
        );

        return json(
          res,
          500,
          {
            error:
              error?.message ||
              "Relay server error",
          }
        );

      }

    }
  );

// -----------------------------------------------------------------------------
// Start
// -----------------------------------------------------------------------------

server.listen(
  PORT,
  HOST,
  () => {

    console.log(
      `SMTP relay listening on http://${HOST}:${PORT}`
    );

    console.log(
      "Outbound TCP port 25 must be available from this machine."
    );

  }
);
