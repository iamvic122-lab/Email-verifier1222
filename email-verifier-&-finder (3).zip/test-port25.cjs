/**
 * ============================================================================
 * PORT 25 CONNECTIVITY TEST (CommonJS edition)
 * ============================================================================
 *
 * What this does:
 * Checks whether THIS machine/network allows outbound connections on
 * TCP port 25 (the port email servers use).
 *
 * Run:
 *   node test-port25.cjs
 * ============================================================================
 */

const net = require("node:net");

const TEST_SERVERS = [
  "smtp.gmail.com",
  "outlook-com.olc.protection.outlook.com",
  "aspmx.l.google.com",
];

const TIMEOUT_MS = 6000;

function testServer(host) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;

    const finish = (result) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(result);
    };

    socket.setTimeout(TIMEOUT_MS);

    socket.once("connect", () => {
      finish({ host, open: true, detail: "Connected successfully" });
    });

    socket.once("timeout", () => {
      finish({ host, open: false, detail: "Connection timed out" });
    });

    socket.once("error", (err) => {
      finish({ host, open: false, detail: err.message });
    });

    socket.connect(25, host);
  });
}

async function main() {
  console.log("");
  console.log("Testing outbound port 25 connectivity...");
  console.log("This may take up to 20 seconds.\n");

  const results = [];
  for (const host of TEST_SERVERS) {
    process.stdout.write(`  Trying ${host} ... `);
    const result = await testServer(host);
    console.log(result.open ? "OPEN ✅" : `BLOCKED ❌ (${result.detail})`);
    results.push(result);
  }

  const anyOpen = results.some((r) => r.open);

  console.log("");
  console.log("============================================================");
  if (anyOpen) {
    console.log("RESULT: PORT 25 IS OPEN ✅");
    console.log("");
    console.log("This machine/network CAN run relay-server.js successfully.");
    console.log("Next step: run 'node relay-server.js' here, then point your");
    console.log("email verifier's Relay Server URL setting at this machine.");
  } else {
    console.log("RESULT: PORT 25 IS BLOCKED ❌");
    console.log("");
    console.log("This machine/network cannot run relay-server.js as-is.");
    console.log("This is a restriction set by your ISP/network/firewall,");
    console.log("not something fixable in the code. Options:");
    console.log("  - Try this test again from a different network");
    console.log("    (e.g. office connection instead of home wifi)");
    console.log("  - Use a small paid VPS with port 25 confirmed open");
    console.log("    (e.g. Contabo, Hetzner)");
  }
  console.log("============================================================\n");
}

main().catch((err) => {
  console.error("Test execution error:", err);
});
