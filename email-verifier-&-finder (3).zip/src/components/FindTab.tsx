import React, { useState } from "react";
import { FinderCandidateResult, FinderResponse, VerificationResult } from "../types";
import { StatusBadge } from "./StatusBadge";
import { downloadFinderCsv } from "../utils/csv";
import {
  Search,
  Download,
  Copy,
  Check,
  Building,
  User,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  Eye,
  Loader2,
} from "lucide-react";

interface FindTabProps {
  onInspect: (result: VerificationResult) => void;
  relayUrl: string;
}

export const FindTab: React.FC<FindTabProps> = ({
  onInspect,
  relayUrl,
}) => {
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [response, setResponse] = useState<FinderResponse | null>(null);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);

  const handleCopy = (email: string) => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(email);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  const handlePreset = (presetName: string, presetDomain: string) => {
    setName(presetName);
    setDomain(presetDomain);
    setError(null);
  };

  const handleFind = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);

    const cleanName = name.trim();
    const cleanDomain = domain.trim();

    if (!cleanName) {
      setError("Please enter the person's full name (first and last name).");
      return;
    }

    if (!cleanDomain) {
      setError("Please enter the company domain (e.g. 'stripe.com').");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/find", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: cleanName,
          domain: cleanDomain,
          relayUrl: relayUrl.trim() || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to search for emails.");
      }

      setResponse(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred while running the finder.");
    } finally {
      setLoading(false);
    }
  };

  const candidateResults = response?.results || [];
  const validCandidates = candidateResults.filter(
    (c) => c.status === "Valid" || (c.status === "Risky" && c.confidence >= 60)
  );

  return (
    <div className="space-y-6">
      {/* Search Input Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">Corporate Email Finder</h2>
            <p className="text-xs text-slate-500">
              Generates company name permutations and verifies each through the native engine.
            </p>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500">
            <span>Quick Presets:</span>
            <button
              onClick={() => handlePreset("Satya Nadella", "microsoft.com")}
              className="text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded text-xs font-semibold"
            >
              Microsoft
            </button>
            <button
              onClick={() => handlePreset("Sundar Pichai", "google.com")}
              className="text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded text-xs font-semibold"
            >
              Google
            </button>
          </div>
        </div>

        <form onSubmit={handleFind} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="finder-name" className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  id="finder-name"
                  type="text"
                  placeholder="e.g. John Smith"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/40"
                />
              </div>
            </div>

            <div>
              <label htmlFor="finder-domain" className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Company Domain or Website
              </label>
              <div className="relative">
                <Building className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  id="finder-domain"
                  type="text"
                  placeholder="e.g. acme.com or https://company.org"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/40"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <p className="text-xs text-slate-500">
              Permutations tested include first.last@, firstlast@, first@, flast@, first_last@, and more.
            </p>

            <button
              id="find-submit-button"
              type="submit"
              disabled={loading || !name.trim() || !domain.trim()}
              className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-xs transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Searching Patterns...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Find Email</span>
                </>
              )}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Results View */}
      {response && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          {/* Header */}
          <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Candidate Discovery Results</h3>
              <p className="text-xs text-slate-600 mt-0.5">{response.message}</p>
            </div>

            {candidateResults.length > 0 && (
              <button
                id="download-finder-csv"
                onClick={() => downloadFinderCsv(candidateResults, response.name, response.domain)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl shadow-2xs transition-colors"
              >
                <Download className="w-4 h-4 text-slate-500" />
                <span>Download results as CSV</span>
              </button>
            )}
          </div>

          {/* If No Candidates Valid or High-Confidence */}
          {validCandidates.length === 0 ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
                <HelpCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">
                No Verified High-Confidence Address Found
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {response.message}
              </p>
            </div>
          ) : (
            <div className="p-5 bg-emerald-50/50 border-b border-emerald-100">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800 mb-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Top Recommended Candidate(s)
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {validCandidates.map((cand, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-white rounded-xl border border-emerald-200/80 shadow-xs flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-slate-900 break-all">
                          {cand.email}
                        </span>
                        <span className="text-[10px] uppercase font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          {cand.pattern}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{cand.reason}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <StatusBadge status={cand.status} size="sm" />
                        <div className="text-xs font-bold text-slate-700 mt-1">
                          {cand.confidence}%
                        </div>
                      </div>

                      <button
                        onClick={() => handleCopy(cand.email)}
                        className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                        title="Copy to clipboard"
                      >
                        {copiedEmail === cand.email ? (
                          <Check className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Full Permutations Ranking Table */}
          <div className="p-5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              All Generated Pattern Permutations ({candidateResults.length})
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100/70 border-b border-slate-200 text-[11px] uppercase tracking-wider text-slate-500 font-semibold">
                    <th className="py-2.5 px-3">Pattern</th>
                    <th className="py-2.5 px-3">Candidate Email</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Confidence</th>
                    <th className="py-2.5 px-3">Verification Details</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {candidateResults.map((c, i) => (
                    <tr key={i} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-3 font-mono font-medium text-slate-500">
                        {c.pattern}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-800 break-all">
                        {c.email}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <StatusBadge status={c.status} size="sm" />
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap font-bold text-slate-700">
                        {c.confidence}%
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate">
                        {c.reason}
                      </td>
                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleCopy(c.email)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                            title="Copy email"
                          >
                            {copiedEmail === c.email ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() =>
                              onInspect({
                                email: c.email,
                                status: c.status,
                                confidence: c.confidence,
                                reason: c.reason,
                                details: c.details,
                                timestamp: new Date().toISOString(),
                              })
                            }
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 bg-white hover:bg-indigo-50 px-2 py-0.5 rounded border border-slate-200 shadow-2xs"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Details</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
