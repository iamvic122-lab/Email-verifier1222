import React, { useState, useMemo } from "react";
import { VerificationResult, VerificationStatus } from "../types";
import { StatusBadge } from "./StatusBadge";
import { downloadVerificationCsv } from "../utils/csv";
import {
  Search,
  Download,
  Trash2,
  Play,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Eye,
  Loader2,
} from "lucide-react";

interface VerifyTabProps {
  onInspect: (result: VerificationResult) => void;
  relayUrl: string;
}

const SAMPLE_LIST = `contact@google.com
invalid-syntax-email@
test@mailinator.com
support@github.com
alex.smith@nonexistent-domain-xyz-12345.org
hello@stripe.com`;

export const VerifyTab: React.FC<VerifyTabProps> = ({
  onInspect,
  relayUrl,
}) => {
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<VerificationResult[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  const emailCount = useMemo(() => {
    return inputText
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean).length;
  }, [inputText]);

  const handleVerify = async () => {
    setError(null);
    const cleaned = inputText
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    if (cleaned.length === 0) {
      setError("Please enter at least one email address to verify.");
      return;
    }

    if (cleaned.length > 200) {
      setError("Maximum 200 email addresses allowed per bulk verification run.");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          emails: cleaned,
          relayUrl: relayUrl.trim() || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to verify emails");
      }

      setResults(data.results || []);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during verification.");
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setInputText("");
    setResults([]);
    setError(null);
  };

  const handleLoadSample = () => {
    setInputText(SAMPLE_LIST);
    setError(null);
  };

  // Metrics
  const stats = useMemo(() => {
    const valid = results.filter((r) => r.status === "Valid").length;
    const risky = results.filter((r) => r.status === "Risky").length;
    const invalid = results.filter((r) => r.status === "Invalid").length;
    const unknown = results.filter((r) => r.status === "Unknown").length;
    return { valid, risky, invalid, unknown, total: results.length };
  }, [results]);

  // Filtered results
  const filteredResults = useMemo(() => {
    return results.filter((r) => {
      const matchesStatus =
        statusFilter === "ALL" || r.status.toUpperCase() === statusFilter;
      const matchesSearch =
        !searchQuery ||
        r.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.reason.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [results, statusFilter, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Input Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <label htmlFor="verify-textarea" className="text-sm font-bold text-slate-900">
            Email Addresses <span className="text-slate-400 font-normal">({emailCount} detected)</span>
          </label>
          <div className="flex items-center gap-2">
            <button
              onClick={handleLoadSample}
              type="button"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50/80 hover:bg-indigo-100 px-2.5 py-1 rounded-lg transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Load Sample List
            </button>
            {inputText && (
              <button
                onClick={() => setInputText("")}
                type="button"
                className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-700 px-2 py-1 transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        <textarea
          id="verify-textarea"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Enter one email per line, e.g.:\njohn.doe@acme.com\nsales@company.org\nmarketing@startup.io`}
          rows={5}
          className="w-full p-3.5 text-sm font-mono border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50/50"
        />

        <div className="flex flex-wrap items-center justify-between gap-3 mt-4">
          <p className="text-xs text-slate-500">
            Supports single email or bulk list (up to 200 addresses per batch). Safe sequential pacing included.
          </p>

          <div className="flex items-center gap-2.5">
            {results.length > 0 && (
              <button
                onClick={handleClear}
                type="button"
                className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Reset All
              </button>
            )}

            <button
              id="verify-submit-button"
              onClick={handleVerify}
              disabled={loading || emailCount === 0}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-xs transition-all"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Checking ({emailCount} items)...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Check {emailCount > 0 ? `(${emailCount})` : ""}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
            <XCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Results Section */}
      {results.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          {/* Header & Stats Bar */}
          <div className="p-5 border-b border-slate-200 bg-slate-50/70 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Verification Results</h2>
                <p className="text-xs text-slate-500">
                  {results.length} total address{results.length > 1 ? "es" : ""} analyzed
                </p>
              </div>

              <button
                id="download-verify-csv"
                onClick={() => downloadVerificationCsv(results)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl shadow-2xs transition-colors"
              >
                <Download className="w-4 h-4 text-slate-500" />
                <span>Download results as CSV</span>
              </button>
            </div>

            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />

              <p>
                Unknown = we couldn't reach the mail server directly
                to confirm the mailbox (common on cloud hosting) —
                syntax, domain, and other checks did pass.
              </p>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200/80 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <div className="text-xs text-emerald-800 font-medium">Valid</div>
                  <div className="text-lg font-bold text-emerald-900">{stats.valid}</div>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 flex items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <div>
                  <div className="text-xs text-amber-800 font-medium">Risky</div>
                  <div className="text-lg font-bold text-amber-900">{stats.risky}</div>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200/80 flex items-center gap-2.5">
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <div>
                  <div className="text-xs text-rose-800 font-medium">Invalid</div>
                  <div className="text-lg font-bold text-rose-900">{stats.invalid}</div>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200/80 flex items-center gap-2.5">
                <HelpCircle className="w-4 h-4 text-yellow-600 shrink-0" />
                <div>
                  <div className="text-xs text-yellow-800 font-medium">Unknown</div>
                  <div className="text-lg font-bold text-yellow-900">{stats.unknown}</div>
                </div>
              </div>
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-1.5 flex-wrap w-full sm:w-auto">
                {["ALL", "VALID", "RISKY", "INVALID", "UNKNOWN"].map((filterKey) => (
                  <button
                    key={filterKey}
                    onClick={() => setStatusFilter(filterKey)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                      statusFilter === filterKey
                        ? "bg-slate-900 text-white"
                        : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-100"
                    }`}
                  >
                    {filterKey === "ALL" ? `All (${results.length})` : filterKey}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search email or reason..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Results Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-[11px] uppercase tracking-wider text-slate-500 font-semibold">
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Confidence %</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredResults.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400 text-xs">
                      No results matching current filters.
                    </td>
                  </tr>
                ) : (
                  filteredResults.map((r, idx) => {
                    // Color code rows as requested:
                    // green = Valid, red = Invalid, yellow = Risky / Unknown
                    const rowBg = {
                      Valid: "bg-emerald-50/40 hover:bg-emerald-50/70",
                      Invalid: "bg-rose-50/40 hover:bg-rose-50/70",
                      Risky: "bg-amber-50/40 hover:bg-amber-50/70",
                      Unknown: "bg-yellow-50/40 hover:bg-yellow-50/70",
                    }[r.status] || "hover:bg-slate-50";

                    return (
                      <tr
                        key={idx}
                        className={`transition-colors cursor-pointer ${rowBg}`}
                        onClick={() => onInspect(r)}
                      >
                        <td className="py-3 px-4 font-mono font-medium text-slate-900 break-all">
                          {r.email}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <StatusBadge status={r.status} size="sm" />
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-800 text-xs">
                              {r.confidence}%
                            </span>
                            <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden hidden sm:block">
                              <div
                                className={`h-full rounded-full ${
                                  r.confidence >= 70
                                    ? "bg-emerald-500"
                                    : r.confidence >= 40
                                    ? "bg-amber-500"
                                    : "bg-rose-500"
                                }`}
                                style={{ width: `${r.confidence}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600 max-w-xs md:max-w-md">
                          {r.reason}
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onInspect(r);
                            }}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-white hover:bg-indigo-50 px-2.5 py-1 rounded-md border border-slate-200 transition-colors shadow-2xs"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Inspect</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
