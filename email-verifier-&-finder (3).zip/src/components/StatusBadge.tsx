import React from "react";
import { VerificationStatus } from "../types";
import { CheckCircle2, XCircle, AlertTriangle, HelpCircle } from "lucide-react";

interface StatusBadgeProps {
  status: VerificationStatus;
  size?: "sm" | "md";
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = "md" }) => {
  const config = {
    Valid: {
      bg: "bg-emerald-50 text-emerald-800 border-emerald-300",
      icon: CheckCircle2,
      dot: "bg-emerald-500",
    },
    Invalid: {
      bg: "bg-rose-50 text-rose-800 border-rose-300",
      icon: XCircle,
      dot: "bg-rose-500",
    },
    Risky: {
      bg: "bg-amber-50 text-amber-800 border-amber-300",
      icon: AlertTriangle,
      dot: "bg-amber-500",
    },
    Unknown: {
      bg: "bg-yellow-50 text-yellow-800 border-yellow-300",
      icon: HelpCircle,
      dot: "bg-yellow-500",
    },
  }[status] || {
    bg: "bg-slate-100 text-slate-700 border-slate-300",
    icon: HelpCircle,
    dot: "bg-slate-400",
  };

  const Icon = config.icon;
  const sizeClasses = size === "sm" ? "px-2 py-0.5 text-xs gap-1" : "px-2.5 py-1 text-xs sm:text-sm gap-1.5 font-semibold";

  return (
    <span
      id={`status-badge-${status.toLowerCase()}`}
      className={`inline-flex items-center rounded-full border ${config.bg} ${sizeClasses}`}
    >
      <Icon className={size === "sm" ? "w-3.5 h-3.5 shrink-0" : "w-4 h-4 shrink-0"} />
      <span>{status}</span>
    </span>
  );
};
