import React, { useState } from "react";
import { ShieldCheck, Info, ChevronDown, ChevronUp, Server, Check } from "lucide-react";

interface HeaderProps {
  relayUrl: string;
  onRelayUrlChange: (value: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  relayUrl,
  onRelayUrlChange,
}) => {
  const [showNetworkNotice, setShowNetworkNotice] = useState(false);

  return (
    <header className="mb-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Email Verifier & Finder
            </h1>
          </div>
          <p className="text-sm text-slate-500 max-w-2xl">
            Internal team utility for mail deliverability verification, domain health analysis,
            and corporate email permutation discovery. 100% free and native checks.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Internal Team Edition
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
            Native Network Checks
          </span>
          <button
            onClick={() => setShowNetworkNotice(!showNetworkNotice)}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 transition-colors"
          >
            <Info className="w-3.5 h-3.5 text-amber-600" />
            <span>Network Notice</span>
            {showNetworkNotice ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <div className="mt-4 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
        <label
          htmlFor="relay-server-url"
          className="block text-xs font-bold text-slate-700 mb-1.5"
        >
          SMTP Relay Server URL{" "}
          <span className="font-normal text-slate-400">
            (optional)
          </span>
        </label>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            id="relay-server-url"
            type="url"
            value={relayUrl}
            onChange={(e) =>
              onRelayUrlChange(e.target.value)
            }
            placeholder="http://your-relay-host:8787/api/check"
            className="flex-1 px-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/40"
          />

          {relayUrl && (
            <button
              type="button"
              onClick={() => onRelayUrlChange("")}
              className="px-3 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
            >
              Disable Relay
            </button>
          )}
        </div>

        <p className="mt-1.5 text-[11px] text-slate-500">
          When set, SMTP and catch-all probes are performed by
          this relay instead of the AI Studio host. Leave blank
          to use native checks and the normal Unknown / port-25
          fallback.
        </p>
      </div>

      {showNetworkNotice && (
        <div
          id="cloud-network-notice"
          className="mt-4 p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-slate-800 text-xs sm:text-sm leading-relaxed"
        >
          <div className="flex items-start gap-3">
            <Server className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1.5">
              <p className="font-bold text-amber-900">
                Notice regarding Cloud Hosting Environments & SMTP Port 25:
              </p>
              <p className="text-amber-950/90">
                Outbound connections to TCP port 25 are blocked by standard cloud container environments
                (including Google Cloud Run and AWS) to prevent spam transmission.
              </p>
              <p className="text-amber-950/90">
                In this cloud environment, the tool executes <strong>RFC Syntax Validation</strong>, <strong>Live DNS MX Resolution</strong>, <strong>Disposable Provider Blocklist (150+ domains)</strong>, and <strong>Role-Based Account Detection</strong> at 100% fidelity. If the mail server port 25 is blocked, it gracefully reports <strong>Unknown (port 25 blocked)</strong> rather than crashing. When run on a server with open outbound SMTP ports, live mailbox handshakes and catch-all probes run without restriction.
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
