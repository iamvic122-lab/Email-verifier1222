import React from "react";
import { VerificationResult } from "../types";
import { StatusBadge } from "./StatusBadge";
import {
  X,
  CheckCircle,
  XCircle,
  AlertCircle,
  Server,
  FileCheck,
  ShieldAlert,
  Users,
  Radio,
  Copy,
  Check,
} from "lucide-react";

interface DetailedInspectionModalProps {
  result: VerificationResult | null;
  onClose: () => void;
}

export const DetailedInspectionModal: React.FC<DetailedInspectionModalProps> = ({
  result,
  onClose,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!result) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(result.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const { details } = result;

  return (
    <div
      id="detailed-inspection-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="detailed-inspection-dialog"
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-100 bg-slate-50/70">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-slate-900 break-all">
                {result.email}
              </h2>
              <button
                onClick={handleCopy}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-200/60 transition-colors"
                title="Copy email"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center gap-3 mt-2">
              <StatusBadge status={result.status} />
              <span className="text-sm font-semibold text-slate-700">
                {result.confidence}% Confidence
              </span>
            </div>
          </div>
          <button
            id="close-inspection-modal"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Reason Banner */}
        <div className="p-4 bg-slate-100/70 border-b border-slate-200/60">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
            Primary Verdict & Reason
          </p>
          <p className="text-sm text-slate-800 font-medium">{result.reason}</p>
        </div>

        {/* 6-Step Breakdown */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
            6-Step Verification Breakdown
          </h3>

          {/* Step 1: Syntax */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  1. Syntax Format Check
                </span>
                {details.syntax?.valid ? (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    <CheckCircle className="w-3.5 h-3.5" /> Pass
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                    <XCircle className="w-3.5 h-3.5" /> Fail
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.syntax?.reason || "RFC 5322 syntax validation"}
              </p>
              {details.syntax?.localPart && (
                <div className="mt-2 text-xs text-slate-500 font-mono bg-slate-50 p-2 rounded border border-slate-100">
                  User: {details.syntax.localPart} | Domain: {details.syntax.domain}
                </div>
              )}
            </div>
          </div>

          {/* Step 2: MX Records */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600 shrink-0">
              <Server className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  2. MX Record / DNS Check
                </span>
                {details.mx ? (
                  details.mx.valid ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" /> Pass
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                      <XCircle className="w-3.5 h-3.5" /> Fail
                    </span>
                  )
                ) : (
                  <span className="text-xs text-slate-400">Skipped</span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.mx?.reason || "Not executed"}
              </p>
              {details.mx && details.mx.records.length > 0 && (
                <div className="mt-2 text-xs font-mono bg-slate-50 p-2 rounded border border-slate-100 space-y-1">
                  {details.mx.records.slice(0, 3).map((rec, i) => (
                    <div key={i} className="text-slate-600">
                      Priority {rec.priority}: {rec.exchange}
                    </div>
                  ))}
                  {details.mx.records.length > 3 && (
                    <div className="text-slate-400 italic">
                      + {details.mx.records.length - 3} more MX records
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Step 3: Disposable Domain */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-purple-50 text-purple-600 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  3. Disposable / Burner Domain Check
                </span>
                {details.disposable ? (
                  details.disposable.disposable ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                      <AlertCircle className="w-3.5 h-3.5" /> Disposable
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" /> Clean
                    </span>
                  )
                ) : (
                  <span className="text-xs text-slate-400">Skipped</span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.disposable?.reason || "Not executed"}
              </p>
            </div>
          </div>

          {/* Step 4: Role-Based Account */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  4. Role-Based Address Check
                </span>
                {details.roleBased ? (
                  details.roleBased.roleBased ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                      <AlertCircle className="w-3.5 h-3.5" /> Team / Role
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" /> Individual
                    </span>
                  )
                ) : (
                  <span className="text-xs text-slate-400">Skipped</span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.roleBased?.reason || "Not executed"}
              </p>
            </div>
          </div>

          {/* Step 5: SMTP Handshake */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700 shrink-0">
              <Radio className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  5. SMTP Handshake Check (Port 25)
                </span>
                {details.smtp ? (
                  details.smtp.status === "accepted" ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" /> Mailbox Accepted
                    </span>
                  ) : details.smtp.status === "rejected" ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                      <XCircle className="w-3.5 h-3.5" /> Mailbox Rejected
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                      <AlertCircle className="w-3.5 h-3.5" /> Unknown / Blocked
                    </span>
                  )
                ) : (
                  <span className="text-xs text-slate-400">Skipped</span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.smtp?.reason || "Not executed"}
              </p>
              {details.smtp?.code && (
                <div className="mt-1 text-xs font-mono text-slate-500">
                  SMTP Response Code: {details.smtp.code}
                </div>
              )}
            </div>
          </div>

          {/* Step 6: Catch-All Detection */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600 shrink-0">
              <Server className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900">
                  6. Catch-All Mailbox Detection
                </span>
                {details.catchAll ? (
                  details.catchAll.catchAll === true ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                      <AlertCircle className="w-3.5 h-3.5" /> Catch-All Active
                    </span>
                  ) : details.catchAll.catchAll === false ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle className="w-3.5 h-3.5" /> Not Catch-All
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400">Inconclusive</span>
                  )
                ) : (
                  <span className="text-xs text-slate-400">Skipped</span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                {details.catchAll?.reason || "Not executed"}
              </p>
              {details.catchAll?.testAddress && (
                <div className="mt-1 text-xs font-mono text-slate-400 truncate">
                  Probe target: {details.catchAll.testAddress}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
