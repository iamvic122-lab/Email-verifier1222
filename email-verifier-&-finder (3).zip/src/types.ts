export type VerificationStatus = "Valid" | "Invalid" | "Risky" | "Unknown";

export interface SyntaxCheckResult {
  valid: boolean;
  localPart?: string;
  domain?: string;
  reason: string;
}

export interface MxCheckResult {
  valid: boolean;
  records: Array<{ exchange: string; priority: number }>;
  primaryExchange?: string;
  reason: string;
}

export interface DisposableCheckResult {
  disposable: boolean;
  reason: string;
}

export interface RoleBasedCheckResult {
  roleBased: boolean;
  role?: string;
  reason: string;
}

export interface SmtpCheckResult {
  status: "accepted" | "rejected" | "deferred" | "unknown";
  accepted: boolean | null;
  code: number | null;
  mxHost?: string;
  reason: string;
}

export interface CatchAllCheckResult {
  catchAll: boolean | null;
  testAddress?: string;
  reason: string;
}

export interface DetailedChecks {
  syntax: SyntaxCheckResult;
  mx: MxCheckResult | null;
  disposable: DisposableCheckResult | null;
  roleBased: RoleBasedCheckResult | null;
  smtp: SmtpCheckResult | null;
  catchAll: CatchAllCheckResult | null;
}

export interface VerificationResult {
  email: string;
  status: VerificationStatus;
  confidence: number;
  reason: string;
  details: DetailedChecks;
  timestamp: string;
}

export interface FinderCandidateResult {
  email: string;
  pattern: string;
  status: VerificationStatus;
  confidence: number;
  reason: string;
  details: DetailedChecks;
}

export interface FinderResponse {
  success: boolean;
  message: string;
  name: string;
  domain: string;
  totalTested: number;
  results: FinderCandidateResult[];
}
