import { VerificationResult, FinderCandidateResult } from "../types";

function escapeCsvField(val: string | number | boolean | null | undefined): string {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

export function downloadVerificationCsv(results: VerificationResult[], filename = "email-verification-results.csv") {
  if (!results.length) return;

  const headers = [
    "Email",
    "Status",
    "Confidence %",
    "Reason",
    "Syntax Valid",
    "MX Valid",
    "Primary MX",
    "Disposable",
    "Role-Based",
    "SMTP Status",
    "SMTP Code",
    "Catch-All Status",
    "Checked At",
  ];

  const rows = results.map((r) => [
    escapeCsvField(r.email),
    escapeCsvField(r.status),
    escapeCsvField(r.confidence),
    escapeCsvField(r.reason),
    escapeCsvField(r.details.syntax?.valid ? "Yes" : "No"),
    escapeCsvField(r.details.mx ? (r.details.mx.valid ? "Yes" : "No") : "Skipped"),
    escapeCsvField(r.details.mx?.primaryExchange || "N/A"),
    escapeCsvField(r.details.disposable ? (r.details.disposable.disposable ? "Yes" : "No") : "Skipped"),
    escapeCsvField(r.details.roleBased ? (r.details.roleBased.roleBased ? "Yes" : "No") : "Skipped"),
    escapeCsvField(r.details.smtp?.status || "Skipped"),
    escapeCsvField(r.details.smtp?.code || "N/A"),
    escapeCsvField(r.details.catchAll?.catchAll === true ? "Yes" : r.details.catchAll?.catchAll === false ? "No" : "Unknown"),
    escapeCsvField(r.timestamp),
  ]);

  const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\r\n");
  triggerBlobDownload(csvContent, filename);
}

export function downloadFinderCsv(results: FinderCandidateResult[], name: string, domain: string, filename = "email-finder-results.csv") {
  if (!results.length) return;

  const headers = [
    "Candidate Email",
    "Pattern Format",
    "Status",
    "Confidence %",
    "Reason",
    "Person Name",
    "Company Domain",
  ];

  const rows = results.map((r) => [
    escapeCsvField(r.email),
    escapeCsvField(r.pattern),
    escapeCsvField(r.status),
    escapeCsvField(r.confidence),
    escapeCsvField(r.reason),
    escapeCsvField(name),
    escapeCsvField(domain),
  ]);

  const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\r\n");
  triggerBlobDownload(csvContent, filename);
}

function triggerBlobDownload(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
