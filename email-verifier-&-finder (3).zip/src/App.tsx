import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { VerifyTab } from "./components/VerifyTab";
import { FindTab } from "./components/FindTab";
import { DetailedInspectionModal } from "./components/DetailedInspectionModal";
import { VerificationResult } from "./types";
import { CheckCircle2, UserSearch, ShieldCheck, Database, Server } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"verify" | "find">("verify");
  const [inspectResult, setInspectResult] = useState<VerificationResult | null>(null);
  const [disposableCount, setDisposableCount] = useState<number>(150);

  const [relayUrl, setRelayUrl] = useState<string>(() => {
    return localStorage.getItem(
      "emailVerifierRelayUrl"
    ) || "";
  });

  useEffect(() => {
    localStorage.setItem(
      "emailVerifierRelayUrl",
      relayUrl
    );
  }, [relayUrl]);

  useEffect(() => {
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => {
        if (data.disposableDomainsLoaded) {
          setDisposableCount(data.disposableDomainsLoaded);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 antialiased">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 md:py-12">
        {/* Main Header */}
        <Header
          relayUrl={relayUrl}
          onRelayUrlChange={setRelayUrl}
        />

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 mb-8">
          <button
            id="tab-verify-email"
            onClick={() => setActiveTab("verify")}
            className={`inline-flex items-center gap-2 px-5 py-3 text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === "verify"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Verify Email</span>
          </button>

          <button
            id="tab-find-email"
            onClick={() => setActiveTab("find")}
            className={`inline-flex items-center gap-2 px-5 py-3 text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === "find"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <UserSearch className="w-4 h-4" />
            <span>Find Email</span>
          </button>
        </div>

        {/* Tab Content */}
        <main>
          {activeTab === "verify" ? (
            <VerifyTab
              onInspect={(result) => setInspectResult(result)}
              relayUrl={relayUrl}
            />
          ) : (
            <FindTab
              onInspect={(result) => setInspectResult(result)}
              relayUrl={relayUrl}
            />
          )}
        </main>

        {/* Footer info & stats */}
        <footer className="mt-16 pt-8 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>
              Internal Team Deliverability Engine • 6-Step Verification Pipeline
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5" />
              {disposableCount}+ Disposable Domains Blocked
            </span>
            <span>•</span>
            <span className="inline-flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5" />
              Native Node.js DNS/SMTP
            </span>
          </div>
        </footer>
      </div>

      {/* Detailed Modal */}
      {inspectResult && (
        <DetailedInspectionModal
          result={inspectResult}
          onClose={() => setInspectResult(null)}
        />
      )}
    </div>
  );
}
