import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import {
  verifyEmail,
  findEmail,
  sleep,
  DEFAULT_BULK_DELAY_MS,
  MAX_BULK_LIMIT,
  type VerificationResult,
} from "./server/verifierEngine";
import { DISPOSABLE_DOMAINS } from "./server/disposableDomains";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Standard middleware
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ extended: true }));

  // --------------------------------------------------------------------------
  // API Routes
  // --------------------------------------------------------------------------

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      service: "Email Verifier & Finder Engine",
      disposableDomainsLoaded: DISPOSABLE_DOMAINS.size,
      timestamp: new Date().toISOString(),
    });
  });

  // Bulk / Single Email Verification endpoint
  app.post("/api/verify", async (req, res) => {
    try {
      const { emails, delayMs, relayUrl } = req.body;

      let emailList: string[] = [];

      if (Array.isArray(emails)) {
        emailList = emails
          .map((e) => String(e || "").trim())
          .filter(Boolean);
      } else if (typeof emails === "string") {
        emailList = emails
          .split(/\r?\n/)
          .map((e) => e.trim())
          .filter(Boolean);
      }

      if (emailList.length === 0) {
        return res.status(400).json({
          error: "No email addresses provided. Please submit one or more emails.",
        });
      }

      if (emailList.length > MAX_BULK_LIMIT) {
        return res.status(400).json({
          error: `Batch exceeds the maximum limit of ${MAX_BULK_LIMIT} emails per request.`,
        });
      }

      const pacing = typeof delayMs === "number" && delayMs >= 0
        ? Math.min(delayMs, 3000)
        : DEFAULT_BULK_DELAY_MS;

      const results: VerificationResult[] = [];

      for (let i = 0; i < emailList.length; i++) {
        const email = emailList[i];
        try {
          const result = await verifyEmail(
            email,
            typeof relayUrl === "string"
              ? relayUrl
              : undefined
          );
          results.push(result);
        } catch (err: any) {
          // Individual check failure must never crash the entire batch
          results.push({
            email,
            status: "Unknown",
            confidence: 0,
            reason: `Internal verification error: ${err?.message || "Unknown error"}`,
            details: {
              syntax: { valid: false, reason: "Unhandled error during check" },
              mx: null,
              disposable: null,
              roleBased: null,
              smtp: null,
              catchAll: null,
            },
            timestamp: new Date().toISOString(),
          });
        }

        // Polite rate-limit delay between checks if more than one item
        if (i < emailList.length - 1 && pacing > 0) {
          await sleep(pacing);
        }
      }

      return res.json({
        success: true,
        count: results.length,
        results,
      });
    } catch (err: any) {
      console.error("API /api/verify fatal error:", err);
      return res.status(500).json({
        error: "Server encountered an error while processing email verification.",
        details: err?.message,
      });
    }
  });

  // Email Finder endpoint
  app.post("/api/find", async (req, res) => {
    try {
      const { name, domain, relayUrl } = req.body;

      if (!name || typeof name !== "string" || !name.trim()) {
        return res.status(400).json({
          error: "Person's name is required (e.g. 'Jane Doe').",
        });
      }

      if (!domain || typeof domain !== "string" || !domain.trim()) {
        return res.status(400).json({
          error: "Company domain is required (e.g. 'acme.com').",
        });
      }

      const finderResult = await findEmail(
        name,
        domain,
        typeof relayUrl === "string"
          ? relayUrl
          : undefined
      );
      return res.json(finderResult);
    } catch (err: any) {
      console.error("API /api/find fatal error:", err);
      return res.status(500).json({
        error: "Server encountered an error while running the email finder.",
        details: err?.message,
      });
    }
  });

  // --------------------------------------------------------------------------
  // Vite Middleware & Static Serving
  // --------------------------------------------------------------------------

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
