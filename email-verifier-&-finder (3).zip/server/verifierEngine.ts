/**
 * ============================================================================
 * INTERNAL EMAIL VERIFIER & FINDER ENGINE
 * ============================================================================
 * 
 * README & ARCHITECTURE OVERVIEW:
 * ----------------------------------------------------------------------------
 * This module provides an internal, enterprise-grade verification and discovery
 * engine designed for internal team use. It relies solely on free, native network
 * and DNS checks without any paid APIs or third-party subscription keys.
 * 
 * VERIFICATION PIPELINE (Ordered execution with early-exit optimization):
 * 1. Syntax Check: Validates RFC 5322 compliance, local/domain length, and characters.
 * 2. MX Record Check: Resolves DNS Mail Exchange records for the destination domain.
 * 3. Disposable Domain Check: Flags known temporary/throwaway email providers.
 * 4. Role-Based Check: Flags generic organizational mailboxes (info@, sales@, etc.).
 * 5. SMTP Handshake Check: Connects to the primary MX server on TCP port 25,
 *    issues EHLO, MAIL FROM, and RCPT TO to test mailbox existence WITHOUT sending email.
 * 6. Catch-All Detection: Tests a randomized non-existent mailbox to verify if
 *    the mail server accepts all incoming addresses unconditionally.
 * 
 * IMPORTANT CLOUD ENVIRONMENT NOTICE (SMTP PORT 25 LIMITATION):
 * ----------------------------------------------------------------------------
 * Outbound connections to TCP port 25 are intentionally blocked or firewalled
 * by major cloud hosting platforms (including Google Cloud Run, AWS, Azure, and DigitalOcean)
 * as an industry-standard anti-spam countermeasure.
 * 
 * When running in such environments, the SMTP handshake will typically result in a
 * timeout or network unreachable error. This engine is deliberately architected to catch
 * all socket and network errors gracefully, returning a status of "Unknown" with the reason:
 * "Could not connect to mail server (SMTP port 25 restricted on cloud network)", rather than
 * crashing or failing the request. In local or non-firewalled VPS environments, raw port 25
 * handshakes will execute against public mail transfer agents normally.
 * 
 * RATE LIMITING:
 * ----------------------------------------------------------------------------
 * To prevent IP throttling or blacklisting by destination mail servers, bulk and
 * candidate checks incorporate an asynchronous pacing delay between requests.
 * ============================================================================
 */

import dns from "node:dns/promises";
import net from "node:net";
import crypto from "node:crypto";
import { DISPOSABLE_DOMAINS } from "./disposableDomains";

// ----------------------------------------------------------------------------
// Types & Interfaces
// ----------------------------------------------------------------------------

export type VerificationStatus = "Valid" | "Invalid" | "Risky" | "Unknown";

export interface SyntaxCheckResult {
  valid: boolean;
  localPart?: string;
  domain?: string;
  reason: string;
}

export interface MxCheckResult {
  valid: boolean;
  records: Array<{ exchange: string; priority: number }>;
  primaryExchange?: string;
  reason: string;
}

export interface DisposableCheckResult {
  disposable: boolean;
  reason: string;
}

export interface RoleBasedCheckResult {
  roleBased: boolean;
  role?: string;
  reason: string;
}

export interface SmtpCheckResult {
  status: "accepted" | "rejected" | "deferred" | "unknown";
  accepted: boolean | null;
  code: number | null;
  mxHost?: string;
  reason: string;
}

export interface RelayCheckResult {
  smtp: SmtpCheckResult;
  catchAll: CatchAllCheckResult;
}

export interface CatchAllCheckResult {
  catchAll: boolean | null;
  testAddress?: string;
  reason: string;
}

export interface DetailedChecks {
  syntax: SyntaxCheckResult;
  mx: MxCheckResult | null;
  disposable: DisposableCheckResult | null;
  roleBased: RoleBasedCheckResult | null;
  smtp: SmtpCheckResult | null;
  catchAll: CatchAllCheckResult | null;
}

export interface VerificationResult {
  email: string;
  status: VerificationStatus;
  confidence: number;
  reason: string;
  details: DetailedChecks;
  timestamp: string;
}

export interface FinderCandidateResult {
  email: string;
  pattern: string;
  status: VerificationStatus;
  confidence: number;
  reason: string;
  details: DetailedChecks;
}

export interface FinderResponse {
  success: boolean;
  message: string;
  name: string;
  domain: string;
  totalTested: number;
  results: FinderCandidateResult[];
}

// ----------------------------------------------------------------------------
// Configuration Constants
// ----------------------------------------------------------------------------

const SMTP_TIMEOUT_MS = 3500;
export const DEFAULT_BULK_DELAY_MS = 600;
export const MAX_BULK_LIMIT = 200;

// Common role-based administrative and organizational prefixes
const ROLE_PREFIXES = new Set([
  "admin",
  "administrator",
  "billing",
  "contact",
  "customerservice",
  "customercare",
  "editor",
  "enquiries",
  "finance",
  "general",
  "hello",
  "help",
  "hr",
  "info",
  "inquiries",
  "jobs",
  "legal",
  "mail",
  "marketing",
  "media",
  "office",
  "operations",
  "orders",
  "postmaster",
  "press",
  "privacy",
  "reception",
  "sales",
  "security",
  "service",
  "support",
  "team",
  "tech",
  "webmaster",
  "welcome",
  "noreply",
  "no-reply",
]);

// Helper for polite pacing delays
export const sleep = (ms: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Normalizes an email string (trims whitespace, converts to lowercase)
 */
export function normalizeEmail(email: string): string {
  return String(email || "").trim().toLowerCase();
}

/**
 * Normalizes a company domain or website string
 */
export function normalizeDomain(domain: string): string {
  return String(domain || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//i, "")
    .replace(/^www\./i, "")
    .split("/")[0]
    .split(":")[0];
}

// ----------------------------------------------------------------------------
// Step 1: Syntax Check
// ----------------------------------------------------------------------------

/**
 * Validates the email against standard RFC 5322 syntax rules, character sets,
 * and length boundaries (local <= 64 chars, total <= 254 chars).
 */
export function checkSyntax(email: string): SyntaxCheckResult {
  const normalized = normalizeEmail(email);

  if (!normalized) {
    return {
      valid: false,
      reason: "Email address cannot be empty",
    };
  }

  if (normalized.length > 254) {
    return {
      valid: false,
      reason: "Email exceeds maximum RFC limit of 254 characters",
    };
  }

  // RFC 5322 compliant regex for practical internet mail validation
  const regex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

  if (!regex.test(normalized)) {
    return {
      valid: false,
      reason: "Invalid email syntax format (failed RFC 5322 regex)",
    };
  }

  const parts = normalized.split("@");
  if (parts.length !== 2) {
    return {
      valid: false,
      reason: "Email must contain exactly one '@' character",
    };
  }

  const [localPart, domain] = parts;

  if (!localPart || localPart.length > 64) {
    return {
      valid: false,
      reason: "Local username part exceeds 64 characters or is empty",
    };
  }

  if (!domain || domain.length > 255 || !domain.includes(".")) {
    return {
      valid: false,
      reason: "Domain part is missing, invalid, or lacks a top-level domain",
    };
  }

  return {
    valid: true,
    localPart,
    domain,
    reason: "Valid email syntax",
  };
}

// ----------------------------------------------------------------------------
// Step 2: MX Record / Domain Check
// ----------------------------------------------------------------------------

/**
 * Resolves DNS Mail Exchange (MX) records for the domain.
 * Sorts them by numerical priority (lowest number = highest preference).
 */
export async function checkMX(domain: string): Promise<MxCheckResult> {
  const cleanDomain = normalizeDomain(domain);

  if (!cleanDomain) {
    return {
      valid: false,
      records: [],
      reason: "Domain name is empty",
    };
  }

  try {
    const rawRecords = await dns.resolveMx(cleanDomain);

    if (!rawRecords || rawRecords.length === 0) {
      return {
        valid: false,
        records: [],
        reason: "Domain has no MX (Mail Exchange) DNS records configured",
      };
    }

    // Sort by priority ascending (priority 10 before priority 20)
    const records = [...rawRecords].sort((a, b) => a.priority - b.priority);
    const primary = records[0].exchange.replace(/\.$/, "");

    return {
      valid: true,
      records,
      primaryExchange: primary,
      reason: `MX records found (${records.length} host${records.length > 1 ? "s" : ""}, primary: ${primary})`,
    };
  } catch (err: any) {
    const code = err?.code || "DNS_ERROR";
    let message = "Domain has no valid MX records";

    if (code === "ENOTFOUND" || code === "ENODATA") {
      message = "Domain does not exist or has no mail exchange records (NXDOMAIN)";
    } else if (code === "ETIMEOUT") {
      message = "DNS MX lookup timed out";
    }

    return {
      valid: false,
      records: [],
      reason: `${message} (${code})`,
    };
  }
}

// ----------------------------------------------------------------------------
// Step 3: Disposable / Temporary Email Check
// ----------------------------------------------------------------------------

/**
 * Checks whether the domain belongs to a known disposable, temporary,
 * or burner email service provider.
 */
export function checkDisposable(domain: string): DisposableCheckResult {
  const cleanDomain = normalizeDomain(domain);

  if (DISPOSABLE_DOMAINS.has(cleanDomain)) {
    return {
      disposable: true,
      reason: `Disposable/temporary email service detected (${cleanDomain})`,
    };
  }

  return {
    disposable: false,
    reason: "Domain is not on the disposable email blocklist",
  };
}

// ----------------------------------------------------------------------------
// Step 4: Role-Based Address Check
// ----------------------------------------------------------------------------

/**
 * Flags shared or organizational mailbox prefixes (admin, support, sales, etc.)
 * Note: Role-based emails can be completely deliverable, but represent a team
 * rather than an individual person.
 */
export function checkRoleBased(localPart: string): RoleBasedCheckResult {
  const normalized = String(localPart || "")
    .trim()
    .toLowerCase()
    .replace(/[._-]/g, "");

  // Check direct prefix or normalized token
  if (ROLE_PREFIXES.has(normalized)) {
    return {
      roleBased: true,
      role: normalized,
      reason: `Role-based address detected ('${localPart}@' is typically a team mailbox)`,
    };
  }

  // Also check if local part starts with a known role prefix followed by digit or delimiter
  for (const prefix of ROLE_PREFIXES) {
    if (normalized.startsWith(prefix) && normalized.length <= prefix.length + 3) {
      return {
        roleBased: true,
        role: prefix,
        reason: `Role-based address detected ('${localPart}@')`,
      };
    }
  }

  return {
    roleBased: false,
    reason: "Individual / personal-style mailbox name",
  };
}

// ----------------------------------------------------------------------------
// SMTP Handshake Socket Helpers
// ----------------------------------------------------------------------------

function parseSmtpCode(line: string): number | null {
  const match = line.match(/^(\d{3})[ -]/);
  return match ? Number(match[1]) : null;
}

function readSmtpResponse(
  socket: net.Socket,
  timeoutMs = SMTP_TIMEOUT_MS
): Promise<{ code: number | null; line: string; raw: string }> {
  return new Promise((resolve, reject) => {
    let buffer = "";

    const timer = setTimeout(() => {
      cleanup();
      reject(new Error("SMTP socket read timed out"));
    }, timeoutMs);

    function cleanup() {
      clearTimeout(timer);
      socket.removeListener("data", onData);
      socket.removeListener("error", onError);
      socket.removeListener("close", onClose);
    }

    function finish(code: number | null, line: string, raw: string) {
      cleanup();
      resolve({ code, line, raw });
    }

    function onError(err: Error) {
      cleanup();
      reject(err);
    }

    function onClose() {
      cleanup();
      if (!buffer) {
        reject(new Error("SMTP connection closed abruptly by server"));
      }
    }

    function onData(chunk: Buffer) {
      buffer += chunk.toString("utf8");

      // In SMTP, multiline responses have '-' after the code (e.g. '250-SIZE').
      // The concluding line has a space after the 3-digit code (e.g. '250 OK').
      const lines = buffer.split(/\r?\n/);
      for (const line of lines) {
        if (/^\d{3} /.test(line)) {
          finish(parseSmtpCode(line), line.trim(), buffer);
          return;
        }
      }
    }

    socket.on("data", onData);
    socket.once("error", onError);
    socket.once("close", onClose);
  });
}

function sendSmtpCommand(socket: net.Socket, cmd: string): Promise<void> {
  return new Promise((resolve, reject) => {
    socket.write(`${cmd}\r\n`, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

function connectSmtpSocket(host: string, port = 25): Promise<net.Socket> {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        socket.destroy();
        reject(new Error("SMTP connection establishment timed out"));
      }
    }, SMTP_TIMEOUT_MS);

    socket.setTimeout(SMTP_TIMEOUT_MS);

    socket.once("connect", () => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(socket);
      }
    });

    socket.once("error", (err) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        socket.destroy();
        reject(err);
      }
    });

    socket.once("timeout", () => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        socket.destroy();
        reject(new Error("SMTP socket connection timed out"));
      }
    });

    socket.connect(port, host);
  });
}

// ----------------------------------------------------------------------------
// Step 5: SMTP Handshake Check
// ----------------------------------------------------------------------------

// Cache for unreachable hosts on port 25 to prevent repeated timeouts on identical mail hosts
const unreachableHostsCache = new Map<string, number>();

/**
 * Calls an external SMTP relay running on a machine where outbound
 * TCP port 25 is available.
 *
 * The relay performs both the real mailbox RCPT check and the catch-all
 * probe, returning both results in one JSON response.
 *
 * If the relay cannot be reached, we deliberately return Unknown rather
 * than allowing the verification request to fail.
 */
async function checkViaRelay(
  email: string,
  mxHost: string,
  relayUrl: string
): Promise<RelayCheckResult> {
  const controller = new AbortController();

  const timer = setTimeout(
    () => controller.abort(),
    SMTP_TIMEOUT_MS + 5000
  );

  try {
    const response = await fetch(relayUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        mxHost,
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(
        `Relay returned HTTP ${response.status}`
      );
    }

    const data =
      await response.json() as Partial<RelayCheckResult>;

    if (!data.smtp || !data.catchAll) {
      throw new Error(
        "Relay response is missing smtp or catchAll results"
      );
    }

    return {
      smtp: data.smtp,
      catchAll: data.catchAll,
    };
  } catch (err: any) {
    const reason =
      err?.name === "AbortError"
        ? "Relay request timed out"
        : `Relay request failed (${err?.message || "unknown error"})`;

    return {
      smtp: {
        status: "unknown",
        accepted: null,
        code: null,
        mxHost,
        reason,
      },

      catchAll: {
        catchAll: null,
        reason:
          `Catch-all probe unavailable because relay could not be reached (${reason})`,
      },
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Connects to the primary MX mail server on port 25, issues HELO/EHLO,
 * MAIL FROM, and RCPT TO to test if the recipient mailbox exists without sending an email.
 * 
 * IMPORTANT: Cloud platforms block outbound port 25. This function gracefully
 * catches connection errors and returns status: "unknown" instead of throwing.
 */
export async function checkSMTP(
  email: string,
  mxRecords: Array<{ exchange: string; priority: number }>,
  relayUrl?: string
): Promise<SmtpCheckResult> {
  if (!mxRecords || mxRecords.length === 0) {
    return {
      status: "unknown",
      accepted: null,
      code: null,
      reason: "No MX servers available for SMTP handshake",
    };
  }

  const mxHost = mxRecords[0].exchange.replace(/\.$/, "");

  // Relay Mode: perform the port-25 operation on the configured relay host.
  if (relayUrl?.trim()) {
    const relayResult = await checkViaRelay(
      email,
      mxHost,
      relayUrl.trim()
    );

    return relayResult.smtp;
  }

  // If this host was recently determined to be unreachable on port 25, return immediately
  const cachedUnreachable = unreachableHostsCache.get(mxHost);
  if (cachedUnreachable && Date.now() - cachedUnreachable < 5 * 60 * 1000) {
    return {
      status: "unknown",
      accepted: null,
      code: null,
      mxHost,
      reason: "Could not connect to mail server on port 25 (outbound port 25 blocked on cloud network)",
    };
  }

  let socket: net.Socket | null = null;

  try {
    socket = await connectSmtpSocket(mxHost, 25);

    // 1. Read greeting banner (expected 220)
    const greeting = await readSmtpResponse(socket);
    if (!greeting.code || greeting.code >= 400) {
      socket.destroy();
      return {
        status: "unknown",
        accepted: null,
        code: greeting.code,
        mxHost,
        reason: `Mail server rejected connection greeting: ${greeting.line}`,
      };
    }

    // 2. HELO / EHLO handshake
    await sendSmtpCommand(socket, "EHLO verifier.internal.net");
    const heloResponse = await readSmtpResponse(socket);

    // 3. Envelope sender probe (no email is ever sent)
    await sendSmtpCommand(socket, "MAIL FROM:<verify-probe@internal.net>");
    const mailFromResp = await readSmtpResponse(socket);

    if (!mailFromResp.code || mailFromResp.code >= 400) {
      await sendSmtpCommand(socket, "QUIT").catch(() => {});
      socket.destroy();
      return {
        status: "unknown",
        accepted: null,
        code: mailFromResp.code,
        mxHost,
        reason: `Mail server rejected MAIL FROM envelope probe (${mailFromResp.code})`,
      };
    }

    // 4. Test recipient address
    await sendSmtpCommand(socket, `RCPT TO:<${email}>`);
    const rcptResp = await readSmtpResponse(socket);

    // Gracefully send QUIT before closing
    await sendSmtpCommand(socket, "QUIT").catch(() => {});
    socket.end();

    const code = rcptResp.code;

    // 250 / 251: Mailbox accepted
    if (code !== null && code >= 200 && code < 300) {
      return {
        status: "accepted",
        accepted: true,
        code,
        mxHost,
        reason: `SMTP server accepted mailbox (${code} OK)`,
      };
    }

    // 550 / 551 / 552 / 553 / 554: Mailbox does not exist
    if (code !== null && code >= 500 && code < 600) {
      return {
        status: "rejected",
        accepted: false,
        code,
        mxHost,
        reason: `SMTP server rejected mailbox (${code} User Unknown)`,
      };
    }

    // 450 / 451 / 452 / 4xx: Greylisting or temporary server throttling
    if (code !== null && code >= 400 && code < 500) {
      return {
        status: "deferred",
        accepted: null,
        code,
        mxHost,
        reason: `SMTP server temporarily deferred recipient (${code} Greylisted/Rate-limited)`,
      };
    }

    return {
      status: "unknown",
      accepted: null,
      code,
      mxHost,
      reason: `Unexpected SMTP response code: ${code}`,
    };
  } catch (err: any) {
    if (socket) {
      try {
        socket.destroy();
      } catch {}
    }

    // Typical error codes when port 25 is restricted by cloud host (AI Studio / GCP / AWS):
    // ETIMEDOUT, ECONNREFUSED, EHOSTUNREACH, ENETUNREACH
    unreachableHostsCache.set(mxHost, Date.now());

    const errCode = err?.code || err?.message || "CONN_FAILED";
    return {
      status: "unknown",
      accepted: null,
      code: null,
      mxHost,
      reason: `Could not connect to mail server on port 25 (${errCode} - typical on cloud hosting environments)`,
    };
  }
}

// ----------------------------------------------------------------------------
// Step 6: Catch-All Detection
// ----------------------------------------------------------------------------

/**
 * Checks if the destination domain operates in "catch-all" mode by attempting
 * an SMTP handshake against a deliberately random, non-existent mailbox.
 * If the server accepts the fake address, the domain is catch-all.
 */
export async function checkCatchAll(
  domain: string,
  mxRecords: Array<{ exchange: string; priority: number }>,
  relayUrl?: string,
  relayResult?: RelayCheckResult
): Promise<CatchAllCheckResult> {
  const cleanDomain = normalizeDomain(domain);

  // Relay Mode already performed the catch-all test.
  if (relayResult) {
    return relayResult.catchAll;
  }

  const randomMailbox = `verify-catchall-${crypto.randomBytes(6).toString("hex")}@${cleanDomain}`;

  const smtpProbe = await checkSMTP(
    randomMailbox,
    mxRecords,
    relayUrl
  );

  if (smtpProbe.accepted === true) {
    return {
      catchAll: true,
      testAddress: randomMailbox,
      reason:
        "Domain is catch-all: mail server accepts arbitrary non-existent addresses",
    };
  }

  if (smtpProbe.accepted === false) {
    return {
      catchAll: false,
      testAddress: randomMailbox,
      reason:
        "Domain is not catch-all: random test address was rejected by server",
    };
  }

  return {
    catchAll: null,
    testAddress: randomMailbox,
    reason:
      "Could not determine catch-all status (SMTP handshake unavailable)",
  };
}

// ----------------------------------------------------------------------------
// Confidence & Status Determination
// ----------------------------------------------------------------------------

export function calculateMetrics(
  syntax: SyntaxCheckResult,
  mx: MxCheckResult | null,
  disposable: DisposableCheckResult | null,
  roleBased: RoleBasedCheckResult | null,
  smtp: SmtpCheckResult | null,
  catchAll: CatchAllCheckResult | null
): { status: VerificationStatus; confidence: number; primaryReason: string } {
  // 1. Syntax failure
  if (!syntax.valid) {
    return {
      status: "Invalid",
      confidence: 0,
      primaryReason: syntax.reason,
    };
  }

  // 2. MX failure
  if (!mx || !mx.valid) {
    return {
      status: "Invalid",
      confidence: 5,
      primaryReason: mx?.reason || "Domain has no valid MX records",
    };
  }

  // 3. Disposable provider
  if (disposable?.disposable) {
    return {
      status: "Risky",
      confidence: 15,
      primaryReason: disposable.reason,
    };
  }

  // 4. SMTP rejected mailbox
  if (smtp?.status === "rejected") {
    return {
      status: "Invalid",
      confidence: 5,
      primaryReason: smtp.reason,
    };
  }

  // 5. Catch-all domain with accepted mailbox
  if (catchAll?.catchAll === true && smtp?.status === "accepted") {
    return {
      status: "Risky",
      confidence: 60,
      primaryReason:
        "Domain is catch-all: mail server accepts all addresses, deliverability not guaranteed",
    };
  }

  // 6. SMTP accepted mailbox and verified not catch-all
  if (smtp?.status === "accepted" && catchAll?.catchAll === false) {
    const isRole = roleBased?.roleBased;
    return {
      status: isRole ? "Risky" : "Valid",
      confidence: isRole ? 80 : 98,
      primaryReason: isRole
        ? "Mailbox exists, but address is role-based (team mailbox)"
        : "Mailbox verified active by mail server",
    };
  }

  // 7. SMTP accepted mailbox but catch-all was unknown
  if (smtp?.status === "accepted") {
    const isRole = roleBased?.roleBased;
    return {
      status: isRole ? "Risky" : "Valid",
      confidence: isRole ? 75 : 90,
      primaryReason: isRole
        ? "Mailbox accepted, address is role-based"
        : "Mailbox accepted by mail server",
    };
  }

  // 8. SMTP deferred (greylisted)
  if (smtp?.status === "deferred") {
    return {
      status: "Risky",
      confidence: 55,
      primaryReason: "Mail server returned temporary deferral/greylisting",
    };
  }

  // 9. SMTP handshake unknown / port 25 blocked (cloud environment fallback)
  // When DNS and syntax are 100% valid but SMTP port 25 cannot connect:
  if (smtp?.status === "unknown") {
    const isRole = roleBased?.roleBased;
    return {
      status: isRole ? "Risky" : "Unknown",
      confidence: isRole ? 45 : 55,
      primaryReason: isRole
        ? `Valid MX records found; role-based mailbox (${smtp.reason})`
        : `Valid domain and MX records found (${smtp.reason})`,
    };
  }

  return {
    status: "Unknown",
    confidence: 50,
    primaryReason: "Verification checks completed with inconclusive result",
  };
}

// ----------------------------------------------------------------------------
// Combined Verification Function
// ----------------------------------------------------------------------------

/**
 * Runs the full 6-step email verification sequence:
 * Syntax -> MX Records -> Disposable Domain -> Role-Based -> SMTP Handshake -> Catch-All.
 * Stops early if syntax or MX records fail.
 */
export async function verifyEmail(
  email: string,
  relayUrl?: string
): Promise<VerificationResult> {
  const original = String(email || "").trim();
  const timestamp = new Date().toISOString();

  // 1. Syntax check (stops early if invalid)
  const syntax = checkSyntax(original);
  if (!syntax.valid) {
    const metrics = calculateMetrics(syntax, null, null, null, null, null);
    return {
      email: original,
      status: metrics.status,
      confidence: metrics.confidence,
      reason: metrics.primaryReason,
      details: {
        syntax,
        mx: null,
        disposable: null,
        roleBased: null,
        smtp: null,
        catchAll: null,
      },
      timestamp,
    };
  }

  const normalizedEmail = `${syntax.localPart}@${syntax.domain}`;

  // 2. MX records check (stops early if domain has no MX)
  const mx = await checkMX(syntax.domain!);
  if (!mx.valid) {
    const metrics = calculateMetrics(syntax, mx, null, null, null, null);
    return {
      email: normalizedEmail,
      status: metrics.status,
      confidence: metrics.confidence,
      reason: metrics.primaryReason,
      details: {
        syntax,
        mx,
        disposable: null,
        roleBased: null,
        smtp: null,
        catchAll: null,
      },
      timestamp,
    };
  }

  // 3. Disposable domain check
  const disposable = checkDisposable(syntax.domain!);
  if (disposable.disposable) {
    const metrics = calculateMetrics(syntax, mx, disposable, null, null, null);
    return {
      email: normalizedEmail,
      status: metrics.status,
      confidence: metrics.confidence,
      reason: metrics.primaryReason,
      details: {
        syntax,
        mx,
        disposable,
        roleBased: null,
        smtp: null,
        catchAll: null,
      },
      timestamp,
    };
  }

  // 4. Role-based check
  const roleBased = checkRoleBased(syntax.localPart!);

  // 5. SMTP handshake.
  //
  // Without Relay Mode, this uses the current native TCP/25 implementation.
  // With Relay Mode, the relay performs the SMTP and catch-all operations
  // from a machine where outbound TCP/25 is available.
  let smtp: SmtpCheckResult;
  let catchAll: CatchAllCheckResult | null = null;

  if (relayUrl?.trim()) {
    const relayResult = await checkViaRelay(
      normalizedEmail,
      mx.primaryExchange ||
        mx.records[0].exchange.replace(/\.$/, ""),
      relayUrl.trim()
    );

    smtp = relayResult.smtp;

    // The relay performs the catch-all probe together with the SMTP probe.
    catchAll =
      smtp.status === "accepted"
        ? relayResult.catchAll
        : null;
  } else {
    smtp = await checkSMTP(
      normalizedEmail,
      mx.records
    );

    // Native catch-all probe.
    if (smtp.status === "accepted") {
      catchAll = await checkCatchAll(
        syntax.domain!,
        mx.records
      );
    } else if (smtp.status === "unknown") {
      catchAll = {
        catchAll: null,
        reason: "Skipped catch-all probe: SMTP mail server connection was unavailable",
      };
    }
  }

  const metrics = calculateMetrics(
    syntax,
    mx,
    disposable,
    roleBased,
    smtp,
    catchAll
  );

  return {
    email: normalizedEmail,
    status: metrics.status,
    confidence: metrics.confidence,
    reason: metrics.primaryReason,
    details: {
      syntax,
      mx,
      disposable,
      roleBased,
      smtp,
      catchAll,
    },
    timestamp,
  };
}

// ----------------------------------------------------------------------------
// Feature 2: Email Finder Engine
// ----------------------------------------------------------------------------

function sanitizeNamePart(part: string): string {
  return part
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove accents/diacritics
    .replace(/[^a-zA-Z0-9]/g, "") // remove punctuation
    .toLowerCase();
}

/**
 * Generates common corporate email permutations from a person's name and domain.
 */
export function generateEmailPatterns(
  name: string,
  domain: string
): Array<{ email: string; pattern: string }> {
  const cleanDomain = normalizeDomain(domain);
  const cleanName = String(name || "").trim().replace(/\s+/g, " ");

  const parts = cleanName
    .split(" ")
    .map(sanitizeNamePart)
    .filter(Boolean);

  if (parts.length < 2) {
    return [];
  }

  const first = parts[0];
  const last = parts[parts.length - 1];
  const firstInitial = first.charAt(0);
  const lastInitial = last.charAt(0);

  const patterns = [
    { email: `${first}.${last}@${cleanDomain}`, pattern: "first.last@" },
    { email: `${first}${last}@${cleanDomain}`, pattern: "firstlast@" },
    { email: `${first}@${cleanDomain}`, pattern: "first@" },
    { email: `${firstInitial}${last}@${cleanDomain}`, pattern: "flast@" },
    { email: `${firstInitial}.${last}@${cleanDomain}`, pattern: "f.last@" },
    { email: `${first}_${last}@${cleanDomain}`, pattern: "first_last@" },
    { email: `${first}-${last}@${cleanDomain}`, pattern: "first-last@" },
    { email: `${first}${lastInitial}@${cleanDomain}`, pattern: "firstl@" },
    { email: `${first}.${lastInitial}@${cleanDomain}`, pattern: "first.l@" },
    { email: `${last}.${first}@${cleanDomain}`, pattern: "last.first@" },
    { email: `${last}${first}@${cleanDomain}`, pattern: "lastfirst@" },
    { email: `${last}@${cleanDomain}`, pattern: "last@" },
  ];

  // Deduplicate in case first name and last name produce overlapping permutations
  const seen = new Set<string>();
  const uniquePatterns: Array<{ email: string; pattern: string }> = [];

  for (const item of patterns) {
    if (!seen.has(item.email)) {
      seen.add(item.email);
      uniquePatterns.push(item);
    }
  }

  return uniquePatterns;
}

/**
 * Finds likely corporate emails by generating candidate patterns, checking domain MX,
 * verifying each pattern through verifyEmail(), and ranking by confidence.
 */
export async function findEmail(
  name: string,
  domain: string,
  relayUrl?: string
): Promise<FinderResponse> {
  const cleanDomain = normalizeDomain(domain);
  const cleanName = String(name || "").trim();

  if (!cleanName) {
    return {
      success: false,
      message: "Please enter the person's full name (first and last name).",
      name: cleanName,
      domain: cleanDomain,
      totalTested: 0,
      results: [],
    };
  }

  if (!cleanDomain) {
    return {
      success: false,
      message: "Please enter the company domain or website.",
      name: cleanName,
      domain: cleanDomain,
      totalTested: 0,
      results: [],
    };
  }

  const candidates = generateEmailPatterns(cleanName, cleanDomain);

  if (candidates.length === 0) {
    return {
      success: false,
      message:
        "Could not generate email permutations. Ensure both a first and last name are provided.",
      name: cleanName,
      domain: cleanDomain,
      totalTested: 0,
      results: [],
    };
  }

  // First verify MX records once for the company domain
  const mxCheck = await checkMX(cleanDomain);
  if (!mxCheck.valid) {
    return {
      success: false,
      message: `The domain '${cleanDomain}' does not have valid MX records (${mxCheck.reason}). No valid email can exist on this domain.`,
      name: cleanName,
      domain: cleanDomain,
      totalTested: 0,
      results: [],
    };
  }

  const results: FinderCandidateResult[] = [];

  for (let i = 0; i < candidates.length; i++) {
    const candidate = candidates[i];
    try {
      const verified = await verifyEmail(
        candidate.email,
        relayUrl
      );
      results.push({
        email: verified.email,
        pattern: candidate.pattern,
        status: verified.status,
        confidence: verified.confidence,
        reason: verified.reason,
        details: verified.details,
      });
    } catch (err: any) {
      results.push({
        email: candidate.email,
        pattern: candidate.pattern,
        status: "Unknown",
        confidence: 0,
        reason: `Verification error: ${err?.message || "Unknown error"}`,
        details: {
          syntax: { valid: true, reason: "Generated pattern" },
          mx: mxCheck,
          disposable: null,
          roleBased: null,
          smtp: null,
          catchAll: null,
        },
      });
    }

    // Delay between candidate tests to avoid rate limits
    if (i < candidates.length - 1) {
      await sleep(DEFAULT_BULK_DELAY_MS);
    }
  }

  // Sort candidates: Valid first, then high confidence to low confidence
  const statusRank: Record<VerificationStatus, number> = {
    Valid: 4,
    Risky: 3,
    Unknown: 2,
    Invalid: 1,
  };

  results.sort((a, b) => {
    const diff = (statusRank[b.status] || 0) - (statusRank[a.status] || 0);
    if (diff !== 0) return diff;
    return b.confidence - a.confidence;
  });

  const validCandidates = results.filter(
    (r) => r.status === "Valid" || (r.status === "Risky" && r.confidence >= 60)
  );

  let message = "";

  if (validCandidates.length > 0) {
    message =
      `Found ${validCandidates.length} potential email pattern(s) ranked by confidence.`;
  } else {
    const unknownCount =
      results.filter((r) => r.status === "Unknown").length;

    const invalidCount =
      results.filter((r) => r.status === "Invalid").length;

    if (unknownCount === results.length) {
      message = relayUrl?.trim()
        ? "No high-confidence candidate was verified because the configured relay could not confirm the mailboxes."
        : "No high-confidence candidate was verified because this host could not reach mail servers on SMTP port 25.";
    } else if (invalidCount === results.length) {
      message =
        "No candidate passed verification: the generated mailbox patterns were rejected or otherwise failed verification.";
    } else {
      message =
        "No high-confidence candidate was verified: some patterns were rejected and others could not be confirmed.";
    }
  }

  return {
    success: true,
    message,
    name: cleanName,
    domain: cleanDomain,
    totalTested: results.length,
    results,
  };
}
