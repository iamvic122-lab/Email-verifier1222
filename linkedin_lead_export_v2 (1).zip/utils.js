/*
 * utils.js
 * -----------------------------------------------------------
 * Shared helpers: URL normalization, text cleanup, CSV/TSV
 * escaping, and the column schema used by the table + exports.
 * -----------------------------------------------------------
 */

if (typeof self !== 'undefined' && self.__LX_UTILS_LOADED__) {
  // already loaded
} else {
if (typeof self !== 'undefined') self.__LX_UTILS_LOADED__ = true;

const LX = (typeof window !== 'undefined' && window.LX) || (typeof self !== 'undefined' && self.LX) || {};
(function attach(root) {

  // Sales Navigator lead links look like /sales/lead/ACoAxxxxx,NAME_SEARCH
  // Convert them to a normal, shareable /in/ profile URL.
  root.convertLeadUrl = function convertLeadUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let url = String(rawUrl).trim();
      if (url.startsWith('/')) url = 'https://www.linkedin.com' + url;
      url = url.split('?')[0].split('#')[0];
      url = url.replace('/sales/lead/', '/in/');
      const commaIdx = url.indexOf(',');
      if (commaIdx !== -1) url = url.substring(0, commaIdx);
      return url;
    } catch (e) {
      return rawUrl;
    }
  };

  root.convertCompanyUrl = function convertCompanyUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let url = String(rawUrl).trim();
      if (url.startsWith('/')) url = 'https://www.linkedin.com' + url;
      url = url.split('?')[0].split('#')[0];
      url = url.replace('/sales/company/', '/company/');
      const commaIdx = url.indexOf(',');
      if (commaIdx !== -1) url = url.substring(0, commaIdx);
      return url;
    } catch (e) {
      return rawUrl;
    }
  };

  root.extractLeadId = function extractLeadId(inUrl) {
    if (!inUrl) return '';
    const m = String(inUrl).match(/\/in\/([^/?#,]+)/);
    return m ? m[1] : '';
  };

  root.extractCompanyId = function extractCompanyId(companyUrl) {
    if (!companyUrl) return '';
    const m = String(companyUrl).match(/\/company\/([^/?#,]+)/);
    return m ? m[1] : '';
  };

  root.cleanText = function cleanText(txt) {
    if (txt == null) return '';
    return String(txt).replace(/\s+/g, ' ').trim();
  };

  root.csvEscape = function csvEscape(val) {
    const s = val == null ? '' : String(val);
    if (/[",\n\r]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  };

  root.tsvEscape = function tsvEscape(val) {
    const s = val == null ? '' : String(val);
    return s.replace(/[\t\r\n]+/g, ' ').trim();
  };

  root.COLUMNS = [
    { key: 'personName',         label: 'Person Name' },
    { key: 'jobTitle',           label: 'Job Title' },
    { key: 'personLinkedInUrl',  label: 'Person LinkedIn URL' },
    { key: 'companyName',        label: 'Company Name' },
    { key: 'companyLinkedInUrl', label: 'Company LinkedIn URL' },
    { key: 'location',           label: 'Location' },
    { key: 'employeeCount',      label: 'Employee Count' },
    { key: 'connectionDegree',   label: 'Connection Degree' },
    { key: 'yearsInRole',        label: 'Years in Role' },
    { key: 'yearsInCompany',     label: 'Years in Company' },
    { key: 'about',              label: 'About' }
  ];

  root.log = function log(...args) {
    try { console.log('%c[LX]', 'color:#0A66C2;font-weight:bold;', ...args); } catch (_) {}
  };

  root.clone = (v) => JSON.parse(JSON.stringify(v));

  if (typeof window !== 'undefined') window.LX = root;
  if (typeof self   !== 'undefined') self.LX   = root;
  if (typeof globalThis !== 'undefined') globalThis.LX = root;

})(LX);

} // end guard
