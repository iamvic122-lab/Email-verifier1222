/*
 * background.js
 * -----------------------------------------------------------
 * Background service worker for the extension.
 * Handles installation and basic lifecycle events.
 * -----------------------------------------------------------
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[LX] Extension installed');
});

// Basic message relay if needed in the future
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  return false;
});
