(function () {
  // ---- Guard against double injection ----
  if (window.__LX_CONTENT_LOADED__) {
    window.LX && window.LX.log && window.LX.log('content script already loaded, skipping re-init');
    return;
  }
  window.__LX_CONTENT_LOADED__ = true;

  const U = window.LX; // utils
  const S = window.LXStorage; // storage
  if (!U || !S) {
    console.warn('[LX] utils or storage not loaded', { utils: !!U, storage: !!S });
    window.__LX_CONTENT_LOADED__ = false;
    return;
  }

  // ============================================================
  // 1. Logger
  // ============================================================
  const Logger = {
    _timestamp() {
      return new Date().toISOString();
    },
    info(...args)    { console.info('[LX][' + this._timestamp() + '][INFO]', ...args); },
    warning(...args) { console.warn('[LX][' + this._timestamp() + '][WARN]', ...args); },
    error(...args)   { console.error('[LX][' + this._timestamp() + '][ERROR]', ...args); }
  };

  // ============================================================
  // 2. Selectors (all in one place)
  // ============================================================
  const SEL = {
    resultRow: [
      'li.artdeco-list__item[data-x-search-result="LEAD"]',
      'li[data-x-search-result="LEAD"]',
      'li.artdeco-list__item.pl3.pv3',
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'div.artdeco-entity-lockup__content'
    ],
    personLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a.ember-view[href*="/sales/lead/"]'
    ],
    personName: [
      '[data-anonymize="person-name"]',
      'span[data-anonymize="person-name"]',
      '.artdeco-entity-lockup__title a',
      '.artdeco-entity-lockup__title span'
    ],
    jobTitle: [
      '[data-anonymize="title"]',
      '[data-anonymize="job-title"]',
      '.artdeco-entity-lockup__subtitle span[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle'
    ],
    companyLink: [
      'a[data-anonymize="company-name"]',
      'a[href*="/sales/company/"]'
    ],
    companyName: [
      '[data-anonymize="company-name"]',
      'a[data-anonymize="company-name"]'
    ],
    location: [
      '[data-anonymize="location"]',
      '.artdeco-entity-lockup__caption span[data-anonymize="location"]'
    ],
    employeeCount: [
      '[data-anonymize="company-size"]',
      '.artdeco-entity-lockup__metadata span:nth-child(1)',
      '.artdeco-entity-lockup__metadata'
    ],
    connectionDegree: [
      '.artdeco-entity-lockup__degree',
      'span.artdeco-entity-lockup__degree',
      '[data-test-connection-degree]'
    ],
    premiumBadge: [
      'li-icon[type="linkedin-premium-gold-icon"]',
      'svg[data-test-icon="premium-app-medium"]',
      '.premium-icon',
      'img[alt*="Premium"]'
    ],
    about: [
      '[data-anonymize="person-blurb"]',
      '.result-lockup__highlight-keyword',
      '.artdeco-entity-lockup__content p'
    ]
  };

  // ============================================================
  // 3. Extractor — reads whatever is already rendered in the DOM.
  //    No scrolling, no clicking, no waiting for new content: it
  //    only ever looks at the page exactly as you're viewing it.
  // ============================================================
  const Extractor = {
    _q(root, selectors) {
      for (const s of selectors) {
        try {
          const el = root.querySelector(s);
          if (el) return el;
        } catch (_) { /* ignore */ }
      }
      return null;
    },

    _text(el) { return el ? U.cleanText(el.textContent) : ''; },

    _findResultRows() {
      for (const sel of SEL.resultRow) {
        try {
          const list = document.querySelectorAll(sel);
          if (list && list.length > 3) return Array.from(list);
        } catch (_) { /* ignore */ }
      }
      // Fallback: infer rows from anchors
      const anchors = document.querySelectorAll('a[href*="/sales/lead/"]');
      const rows = new Set();
      anchors.forEach((a) => {
        const li = a.closest('li') || a.closest('article') || a.closest('div[class*="lockup"]');
        if (li) rows.add(li);
      });
      return Array.from(rows);
    },

    extractLead(row, index = 0) {
      if (!row) return null;
      const personA = this._q(row, SEL.personLink) || row.querySelector('a[href*="/sales/lead/"]');
      if (!personA) return null;
      const rawPersonUrl = personA.getAttribute('href') || '';
      const personLinkedInUrl = U.convertLeadUrl(rawPersonUrl);
      if (!personLinkedInUrl) return null;

      let personName = this._text(this._q(row, SEL.personName));
      if (!personName) personName = this._text(personA);

      let jobTitle = this._text(this._q(row, SEL.jobTitle));
      if (jobTitle) {
        jobTitle = jobTitle.split(/\d+\s*year|\d+\s*month|in role|in company/i)[0].trim();
        jobTitle = jobTitle.replace(/[,·•]$/, '').trim();
      }

      const companyA = this._q(row, SEL.companyLink);
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      let companyLinkedInUrl = '';
      if (companyA) {
        const rawCo = companyA.getAttribute('href') || '';
        companyLinkedInUrl = U.convertCompanyUrl(rawCo);
      }

      if (jobTitle && companyName) {
        const atIdx = jobTitle.toLowerCase().lastIndexOf(' at ' + companyName.toLowerCase());
        if (atIdx > 0) jobTitle = jobTitle.slice(0, atIdx).trim();
      }

      if (!jobTitle) {
        const candidates = Array.from(row.querySelectorAll('span, div'))
          .map((el) => this._text(el))
          .filter(Boolean)
          .filter((t) => t !== personName && t !== companyName && t.length < 120);
        const skipWords = /^(1st|2nd|3rd|3\+|connect|message|save|premium|open profile|view profile)$/i;
        const guess = candidates.find((t) => !skipWords.test(t) && !/^\d+\s*(year|month|employee)/i.test(t));
        if (guess) jobTitle = guess;
      }

      // Tenure ("2 years 5 months in role", "4 years in company") is
      // rendered as plain text near the title, not behind a stable
      // selector, so it's read off the row's own visible text.
      const rowText = this._text(row);
      const roleMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in role/i);
      const companyTenureMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in company/i);
      const yearsInRole = roleMatch ? U.cleanText(roleMatch[1]) : '';
      const yearsInCompany = companyTenureMatch ? U.cleanText(companyTenureMatch[1]) : '';

      const location = this._text(this._q(row, SEL.location));
      let connectionDegree = this._text(this._q(row, SEL.connectionDegree));
      if (connectionDegree) {
        const dm = connectionDegree.match(/(1st|2nd|3rd|3\+|Out of network|Following|You)/i);
        if (dm) connectionDegree = dm[1];
      }
      const premium = !!this._q(row, SEL.premiumBadge);

      let about = this._text(this._q(row, SEL.about));
      if (!about) {
        const p = row.querySelector('p');
        if (p) about = this._text(p);
      }
      if (about) about = about.replace(/\s*…\s*Show more$/i, '').trim();

      let employeeCount = this._text(this._q(row, SEL.employeeCount));
      if (employeeCount) {
        if (employeeCount.includes('·')) employeeCount = employeeCount.split('·')[0].trim();
        if (!/\d/.test(employeeCount)) employeeCount = '';
      }

      return {
        personName,
        jobTitle,
        companyName,
        location,
        connectionDegree,
        premium,
        about,
        yearsInRole,
        yearsInCompany,
        personLinkedInUrl,
        companyLinkedInUrl,
        employeeCount,
        sourceRow: index + 1,
        leadId: U.extractLeadId(personLinkedInUrl),
        companyId: U.extractCompanyId(companyLinkedInUrl),
        capturedAt: new Date().toISOString(),
        capturedFromUrl: location.href
      };
    },

    extractAll() {
      const rows = this._findResultRows();
      const leads = [];
      rows.forEach((row, i) => {
        try {
          const lead = this.extractLead(row, i);
          if (lead) leads.push(lead);
        } catch (err) {
          Logger.error('Row extraction failed', err);
        }
      });
      return leads;
    }
  };

  // ============================================================
  // 4. Message Bridge — two messages only. No loops, no timers,
  //    nothing runs unless the popup asks for it right now.
  // ============================================================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return false;

    // Ping: let the popup know this tab is a Sales Navigator page
    // and how many result rows are currently visible.
    if (msg.type === 'LX_PING') {
      sendResponse({
        ok: true,
        url: location.href,
        onSearch: /\/sales\/(search|lists|people)/.test(location.pathname),
        rowsVisible: Extractor._findResultRows().length
      });
      return true;
    }

    // Extract exactly what's rendered right now, once, and merge
    // it into storage. Nothing scrolls, clicks, or waits.
    if (msg.type === 'LX_EXTRACT_PAGE') {
      (async () => {
        try {
          const rows = Extractor.extractAll();
          const { all, added } = await S.mergeLeads(rows);
          await S.setMeta({
            lastUpdate: new Date().toISOString(),
            lastUrl: location.href,
            lastCount: all.length
          });
          Logger.info(`Extracted ${rows.length} row(s) on page, ${added.length} new`);
          sendResponse({
            ok: true,
            foundOnPage: rows.length,
            added: added.length,
            totalLeads: all.length,
            leads: all
          });
        } catch (err) {
          Logger.error('Extraction failed', err);
          sendResponse({ ok: false, reason: (err && err.message) || 'Extraction failed' });
        }
      })();
      return true; // keep the message channel open for the async response
    }

    return false;
  });

  Logger.info('content script ready on', location.href);
})();
