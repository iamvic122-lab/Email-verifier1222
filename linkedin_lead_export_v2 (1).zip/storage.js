/*
 * storage.js
 * -----------------------------------------------------------
 * Thin async wrapper around chrome.storage.local for
 * settings + collected leads + session metadata.
 * -----------------------------------------------------------
 */

if (typeof self !== 'undefined' && self.__LX_STORAGE_LOADED__) {
  // already loaded
} else {
if (typeof self !== 'undefined') self.__LX_STORAGE_LOADED__ = true;

const LXStorage = (() => {

  const KEYS = {
    LEADS:    'lx_leads',
    SETTINGS: 'lx_settings',
    META:     'lx_meta'
  };

  const DEFAULT_SETTINGS = {
    autoDownload: false,
    darkMode: true
  };

  function get(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  }
  function set(obj) {
    return new Promise((resolve) => chrome.storage.local.set(obj, resolve));
  }
  function remove(keys) {
    return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
  }

  async function getSettings() {
    const r = await get(KEYS.SETTINGS);
    return { ...DEFAULT_SETTINGS, ...(r[KEYS.SETTINGS] || {}) };
  }

  async function saveSettings(patch) {
    const cur = await getSettings();
    const next = { ...cur, ...patch };
    await set({ [KEYS.SETTINGS]: next });
    return next;
  }

  async function getLeads() {
    const r = await get(KEYS.LEADS);
    return Array.isArray(r[KEYS.LEADS]) ? r[KEYS.LEADS] : [];
  }

  // Merge freshly-extracted leads into storage, de-duped by profile URL.
  async function mergeLeads(newLeads) {
    const existing = await getLeads();
    const seen = new Set(existing.map((l) => l.personLinkedInUrl).filter(Boolean));
    const added = [];
    for (const lead of newLeads) {
      const key = lead.personLinkedInUrl;
      if (!key || seen.has(key)) continue;
      seen.add(key);
      added.push(lead);
    }
    const all = existing.concat(added);
    await set({ [KEYS.LEADS]: all });
    return { all, added };
  }

  async function clearLeads() {
    await remove(KEYS.LEADS);
  }

  async function getMeta() {
    const r = await get(KEYS.META);
    return r[KEYS.META] || {};
  }

  async function setMeta(patch) {
    const cur = await getMeta();
    const next = { ...cur, ...patch };
    await set({ [KEYS.META]: next });
    return next;
  }

  return {
    KEYS,
    DEFAULT_SETTINGS,
    getSettings, saveSettings,
    getLeads, mergeLeads, clearLeads,
    getMeta, setMeta
  };
})();

if (typeof self !== 'undefined') self.LXStorage = LXStorage;
if (typeof window !== 'undefined') window.LXStorage = LXStorage;

} // end guard
