/*
 * popup.js
 * -----------------------------------------------------------
 * Popup UI controller. Every action here happens because the
 * user clicked something right now — there is no background
 * loop, timer, or auto-triggered behavior.
 * -----------------------------------------------------------
 */

(() => {
  const COLUMNS = window.LX.COLUMNS;

  const els = {
    settingsBtn: document.getElementById('settingsBtn'),
    settingsPanel: document.getElementById('settingsPanel'),
    statusPill: document.getElementById('statusPill'),
    statusHint: document.getElementById('statusHint'),
    totalCount: document.getElementById('totalCount'),
    pageCount: document.getElementById('pageCount'),
    extractBtn: document.getElementById('extractBtn'),
    tableRowCount: document.getElementById('tableRowCount'),
    leadTableHead: document.getElementById('leadTableHead'),
    leadTableBody: document.getElementById('leadTableBody'),
    leadTableEmpty: document.getElementById('leadTableEmpty'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    downloadCsvBtn: document.getElementById('downloadCsvBtn'),
    downloadJsonBtn: document.getElementById('downloadJsonBtn'),
    clearBtn: document.getElementById('clearBtn'),
    setAutoDownload: document.getElementById('setAutoDownload'),
    setDarkMode: document.getElementById('setDarkMode'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    urlIndicator: document.getElementById('urlIndicator')
  };

  const uiState = {
    rows: [],
    seenUrls: new Set(),
    activeTabId: null,
    onSalesNav: false
  };

  /* ==================== init ==================== */

  async function init() {
    const settings = await LXStorage.getSettings();
    applyTheme(settings.darkMode);
    els.setAutoDownload.checked = !!settings.autoDownload;
    els.setDarkMode.checked = settings.darkMode !== false;

    await loadExistingRows();
    await refreshActiveTab();

    els.extractBtn.addEventListener('click', onExtractClick);
    els.settingsBtn.addEventListener('click', toggleSettings);
    els.saveSettingsBtn.addEventListener('click', onSaveSettings);
    els.copyAllBtn.addEventListener('click', onCopyAll);
    els.downloadCsvBtn.addEventListener('click', onDownloadCsv);
    els.downloadJsonBtn.addEventListener('click', onDownloadJson);
    els.clearBtn.addEventListener('click', onClear);

    chrome.tabs.onActivated.addListener(refreshActiveTab);
    chrome.tabs.onUpdated.addListener((tabId, info) => {
      if (info.status === 'complete') refreshActiveTab();
    });
  }

  function applyTheme(dark) {
    document.body.classList.toggle('dark', dark !== false);
    document.body.classList.toggle('light', dark === false);
  }

  function toggleSettings() {
    els.settingsPanel.hidden = !els.settingsPanel.hidden;
  }

  async function onSaveSettings() {
    const settings = await LXStorage.saveSettings({
      autoDownload: els.setAutoDownload.checked,
      darkMode: els.setDarkMode.checked
    });
    applyTheme(settings.darkMode);
    els.settingsPanel.hidden = true;
  }

  /* ==================== tab / content-script wiring ==================== */

  async function getActiveTab() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs && tabs[0]));
    });
  }

  function sendToTab(tabId, message) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (chrome.runtime.lastError) {
          resolve(null); // content script not present / not a matching page
        } else {
          resolve(response);
        }
      });
    });
  }

  // If the content script hasn't loaded yet (e.g. page loaded before the
  // extension did), inject it once on demand. This never runs on a timer —
  // only right before we need to talk to the page.
  async function ensureContentScriptReady(tab) {
    if (!tab || !tab.id || !tab.url) return false;
    if (!/linkedin\.com\/sales\//.test(tab.url)) return false;

    let ping = await sendToTab(tab.id, { type: 'LX_PING' });
    if (ping && ping.ok) return ping;

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['utils.js', 'storage.js', 'content.js']
      });
    } catch (err) {
      console.warn('[LX] could not inject content script', err);
      return false;
    }

    ping = await sendToTab(tab.id, { type: 'LX_PING' });
    return ping && ping.ok ? ping : false;
  }

  async function refreshActiveTab() {
    const tab = await getActiveTab();
    uiState.activeTabId = tab ? tab.id : null;

    if (!tab || !tab.url || !/linkedin\.com\/sales\//.test(tab.url)) {
      uiState.onSalesNav = false;
      els.urlIndicator.textContent = tab && tab.url ? new URL(tab.url).hostname : '—';
      els.extractBtn.disabled = true;
      setStatus('idle', 'Open a Sales Navigator people search, then click Extract This Page.');
      return;
    }

    els.urlIndicator.textContent = tab.url.replace(/^https?:\/\//, '').slice(0, 60);
    const ping = await ensureContentScriptReady(tab);

    if (!ping) {
      uiState.onSalesNav = false;
      els.extractBtn.disabled = true;
      setStatus('error', 'Could not reach the page — try refreshing the Sales Navigator tab.');
      return;
    }

    uiState.onSalesNav = true;
    els.extractBtn.disabled = false;
    if (ping.onSearch) {
      setStatus('idle', `${ping.rowsVisible} result${ping.rowsVisible === 1 ? '' : 's'} visible on this page. Click Extract to save them.`);
    } else {
      setStatus('idle', 'This looks like a Sales Navigator page, but not a search/list view. Extract will grab whatever lead cards are visible.');
    }
  }

  function setStatus(kind, hint) {
    els.statusPill.className = 'status-pill ' + kind;
    els.statusPill.textContent = kind === 'idle' ? 'Idle'
      : kind === 'extracting' ? 'Extracting…'
      : kind === 'completed' ? 'Done'
      : 'Error';
    els.statusHint.textContent = hint;
  }

  /* ==================== extract action ==================== */

  async function onExtractClick() {
    if (!uiState.activeTabId || !uiState.onSalesNav) return;

    els.extractBtn.disabled = true;
    setStatus('extracting', 'Reading the current page…');

    const res = await sendToTab(uiState.activeTabId, { type: 'LX_EXTRACT_PAGE' });

    if (!res || !res.ok) {
      setStatus('error', (res && res.reason) || 'Extraction failed — try refreshing the tab and running again.');
      els.extractBtn.disabled = false;
      return;
    }

    uiState.rows = res.leads.slice(-1000);
    uiState.seenUrls = new Set(uiState.rows.map((l) => l.personLinkedInUrl).filter(Boolean));
    renderTable();
    els.totalCount.textContent = String(res.totalLeads);
    els.pageCount.textContent = String(res.foundOnPage);

    setStatus('completed', `Found ${res.foundOnPage} lead${res.foundOnPage === 1 ? '' : 's'} on this page (${res.added} new). Scroll or page forward yourself, then click Extract again.`);
    els.extractBtn.disabled = false;

    const settings = await LXStorage.getSettings();
    if (settings.autoDownload && res.leads.length) {
      LXExport.downloadCsv(res.leads, {});
    }
  }

  /* ==================== data table ==================== */

  async function loadExistingRows() {
    const leads = await LXStorage.getLeads();
    uiState.rows = leads.slice(-1000);
    uiState.seenUrls = new Set(leads.map((l) => l.personLinkedInUrl).filter(Boolean));
    els.totalCount.textContent = String(leads.length);
    renderTable();
  }

  function renderTable() {
    els.tableRowCount.textContent = `${uiState.rows.length} row${uiState.rows.length === 1 ? '' : 's'}`;

    if (!els.leadTableHead.childElementCount) {
      const idxTh = document.createElement('th');
      idxTh.textContent = '#';
      els.leadTableHead.appendChild(idxTh);
      COLUMNS.forEach((c) => {
        const th = document.createElement('th');
        th.dataset.key = c.key;
        th.textContent = c.label;
        els.leadTableHead.appendChild(th);
      });
    }

    els.leadTableBody.innerHTML = '';
    if (!uiState.rows.length) {
      els.leadTableEmpty.querySelector('td').colSpan = COLUMNS.length + 1;
      els.leadTableBody.appendChild(els.leadTableEmpty);
      return;
    }

    const frag = document.createDocumentFragment();
    const rows = uiState.rows.slice().reverse();
    rows.forEach((lead, i) => {
      const tr = document.createElement('tr');

      const idxTd = document.createElement('td');
      idxTd.textContent = String(uiState.rows.length - i);
      tr.appendChild(idxTd);

      COLUMNS.forEach((c) => {
        const td = document.createElement('td');
        const value = lead[c.key];
        if (c.key === 'personLinkedInUrl' || c.key === 'companyLinkedInUrl') {
          if (value) {
            const a = document.createElement('a');
            a.href = value;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            a.textContent = value;
            td.className = 'name-cell';
            td.appendChild(a);
          } else {
            td.textContent = '—';
          }
        } else {
          td.textContent = (value === '' || value == null) ? '—' : String(value);
        }
        tr.appendChild(td);
      });

      frag.appendChild(tr);
    });
    els.leadTableBody.appendChild(frag);
  }

  /* ==================== export actions ==================== */

  async function onCopyAll() {
    const leads = await LXStorage.getLeads();
    if (!leads.length) return;
    await LXExport.copyAll(leads);
    const original = els.copyAllBtn.innerHTML;
    els.copyAllBtn.innerHTML = '<span class="btn-icon">✓</span> Copied';
    setTimeout(() => { els.copyAllBtn.innerHTML = original; }, 1200);
  }

  async function onDownloadCsv() {
    const leads = await LXStorage.getLeads();
    if (!leads.length) return;
    LXExport.downloadCsv(leads, {});
  }

  async function onDownloadJson() {
    const leads = await LXStorage.getLeads();
    if (!leads.length) return;
    const meta = await LXStorage.getMeta();
    LXExport.downloadJson(leads, meta);
  }

  async function onClear() {
    if (!confirm('Clear all collected leads? This cannot be undone.')) return;
    await LXStorage.clearLeads();
    uiState.rows = [];
    uiState.seenUrls = new Set();
    els.totalCount.textContent = '0';
    els.pageCount.textContent = '0';
    renderTable();
    setStatus('idle', 'Data cleared. Open a Sales Navigator search and click Extract This Page.');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
