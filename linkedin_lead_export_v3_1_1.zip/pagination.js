/* pagination.js — action targeting plus verified link/button pagination. */
(function attachPagination(root) {
  const SEL = root.LXSelectors;
  const C = root.LXConstants;
  const Wait = root.LXWait;
  const Logger = root.LXLogger;
  const Extractor = root.LXExtractor;
  const U = root.LX;

  function isVisible(element) {
    if (!element || element.nodeType !== 1) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0;
  }

  function isDisabled(element) {
    if (!element) return true;
    return !!(
      element.disabled ||
      element.getAttribute('aria-disabled') === 'true' ||
      element.getAttribute('disabled') !== null ||
      element.classList.contains('disabled') ||
      element.classList.contains('artdeco-button--disabled') ||
      !isVisible(element)
    );
  }

  function firstMatch(selectors) {
    for (const selector of selectors || []) {
      try {
        const candidate = [...document.querySelectorAll(selector)].find((element) => !isDisabled(element));
        if (candidate) return { element: candidate, selector };
      } catch (_) {
        Logger.debug('Pagination selector failed', selector);
      }
    }
    return null;
  }

  function findByText(kind) {
    const elements = [...document.querySelectorAll(kind === 'link' ? 'a' : 'button')].filter(isVisible);
    return elements.find((element) => {
      const text = U.cleanText(element.textContent || '');
      const label = U.cleanText(element.getAttribute('aria-label') || element.title || '');
      return /\b(next|next page)\b/i.test(`${text} ${label}`) && !isDisabled(element);
    }) || null;
  }

  function findNext(customSelector = '') {
    if (customSelector) {
      const custom = firstMatch([customSelector]);
      if (custom) return custom;
    }
    const result = firstMatch([...SEL.nextButton, ...SEL.nextLink]);
    if (result) return result;
    const link = findByText('link');
    if (link) return { element: link, selector: 'text:next-link' };
    const button = findByText('button');
    if (button) return { element: button, selector: 'text:next-button' };
    return null;
  }

  function findLoadMoreButton(customSelector = '') {
    if (customSelector) {
      try {
        const custom = [...document.querySelectorAll(customSelector)].find((element) => !isDisabled(element));
        if (custom) return { element: custom, selector: customSelector };
      } catch (error) {
        Logger.warning('Custom load-more selector failed', customSelector, error?.message || error);
      }
    }
    const preferred = firstMatch(SEL.loadMoreButton.filter((selector) => selector !== 'button'));
    if (preferred) return preferred;
    const buttons = [...document.querySelectorAll('button')].filter(isVisible);
    const textMatch = buttons.find((button) => /\bload\s+more\b|show\s+more\s+results|more\s+results/i.test(`${U.cleanText(button.textContent)} ${U.cleanText(button.getAttribute('aria-label') || '')}`) && !isDisabled(button));
    return textMatch ? { element: textMatch, selector: 'text:load-more' } : null;
  }

  function hasNext() {
    return !!findNext();
  }

  function hasLoadMore(customSelector = '') {
    return !!findLoadMoreButton(customSelector);
  }

  function getPageDescriptor() {
    return {
      url: window.location.href,
      pageKey: U.pageKey(window.location.href),
      searchKey: U.searchKey(window.location.href),
      signature: Extractor.signature(),
      rowCount: Extractor.findResultRows().length
    };
  }

  function samePageChanged(previous, current) {
    return current.pageKey !== previous.pageKey || (previous.signature && current.signature && current.signature !== previous.signature);
  }

  async function clickAndWaitForPageChange(previous, settings, safety, shouldCancel = () => false) {
    const target = findNext(settings.paginationTargetSelector);
    if (!target) return { ok: false, reason: 'next-not-found', selector: null };

    const before = previous || getPageDescriptor();
    const body = document.body || document.documentElement;
    const budget = safety ? await safety() : null;
    target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
    target.element.click();
    Logger.info('Next page clicked', target.selector);

    try {
      const result = await Wait.waitForCondition(() => samePageChanged(before, getPageDescriptor()), {
        root: body,
        timeoutMs: settings.timeoutMs,
        shouldCancel
      });
      return { ok: true, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget };
    } catch (error) {
      return { ok: false, reason: error.message || 'page-change-timeout', selector: target.selector, budget };
    }
  }

  async function clickNextWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = '';
    for (let attempt = 1; attempt <= settings.pageChangeRetries; attempt += 1) {
      if (shouldCancel()) return { ok: false, reason: 'cancelled', attempt };
      const currentTarget = findNext(settings.paginationTargetSelector);
      if (!currentTarget) return { ok: false, reason: 'next-not-found', attempt };
      if (attempt > 1) {
        try {
          await Wait.waitForCondition(() => {
            const target = findNext(settings.paginationTargetSelector);
            return !!target && !isDisabled(target.element);
          }, { root: document.body, timeoutMs: Math.min(settings.timeoutMs, 10000), shouldCancel });
        } catch (_) {
          // Retry continues to the click path so final failure is actionable.
        }
      }
      const result = await clickAndWaitForPageChange(previous, settings, safety, shouldCancel);
      if (result.ok) return { ...result, attempt };
      lastFailure = result.reason || 'unknown-pagination-failure';
      Logger.warning('Pagination attempt failed', attempt, lastFailure);
    }
    return { ok: false, reason: lastFailure || 'pagination-failed' };
  }

  async function clickLoadMoreWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = '';
    for (let attempt = 1; attempt <= settings.pageChangeRetries; attempt += 1) {
      if (shouldCancel()) return { ok: false, reason: 'cancelled', attempt };
      const target = findLoadMoreButton(settings.paginationTargetSelector);
      if (!target) return { ok: true, finished: true, reason: 'load-more-not-found', attempt };
      const beforeCount = Number(previous?.rowCount || Extractor.findResultRows().length);
      const beforeSignature = previous?.signature || Extractor.signature();
      const beforeHeight = document.body?.scrollHeight || 0;
      const budget = safety ? await safety() : null;
      target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
      target.element.click();
      Logger.info('Load-more button clicked', target.selector);

      try {
        const result = await Wait.waitForCondition(() => {
          const current = getPageDescriptor();
          const grew = current.rowCount > beforeCount;
          const changed = current.signature !== beforeSignature;
          const heightGrew = (document.body?.scrollHeight || 0) > beforeHeight;
          return grew || changed || heightGrew;
        }, { root: document.body, timeoutMs: settings.timeoutMs, shouldCancel });
        return { ok: true, finished: false, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget, attempt };
      } catch (error) {
        lastFailure = error.message || 'load-more-timeout';
        Logger.warning('Load-more attempt failed', attempt, lastFailure);
      }
    }
    return { ok: false, reason: lastFailure || 'load-more-failed' };
  }

  function verifyTarget(mode, selector = '') {
    if (mode === C.PAGINATION_MODES.CLICK_LINK) {
      const target = selector ? firstMatch([selector]) : findNext();
      return {
        ok: !!target,
        mode,
        selector: target?.selector || selector || null,
        visible: !!target && isVisible(target.element),
        disabled: !target || isDisabled(target.element),
        text: target ? U.cleanText(`${target.element.textContent} ${target.element.getAttribute('aria-label') || ''}`) : ''
      };
    }
    if (mode === C.PAGINATION_MODES.CLICK_BUTTON) {
      const target = findLoadMoreButton(selector);
      return {
        ok: !!target,
        mode,
        selector: target?.selector || selector || null,
        visible: !!target && isVisible(target.element),
        disabled: !target || isDisabled(target.element),
        text: target ? U.cleanText(`${target.element.textContent} ${target.element.getAttribute('aria-label') || ''}`) : ''
      };
    }
    return { ok: true, mode, selector: null, visible: true, disabled: false, text: '' };
  }

  root.LXPagination = {
    findNext: (selector = '') => findNext(selector)?.element || null,
    hasNext,
    findLoadMoreButton: (selector = '') => findLoadMoreButton(selector)?.element || null,
    hasLoadMore,
    getPageDescriptor,
    clickNextWithRetry,
    clickLoadMoreWithRetry,
    verifyTarget
  };
})(typeof window !== 'undefined' ? window : globalThis);
