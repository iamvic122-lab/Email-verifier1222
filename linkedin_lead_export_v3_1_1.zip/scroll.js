/* scroll.js — variable scroll engine for lazy-loaded result lists. */
(function attachScroll(root) {
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;

  function isScrollable(el) {
    if (!el || el.nodeType !== 1) return false;
    const style = getComputedStyle(el);
    const overflowY = style.overflowY;
    return (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && el.scrollHeight > el.clientHeight + 40;
  }

  function findContainer(rows) {
    const sample = rows && rows[0];
    let node = sample ? sample.parentElement : null;
    while (node && node !== document.body) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function progressOf(container) {
    const max = Math.max(1, container.scrollHeight - container.clientHeight);
    const top = Number(container.scrollTop || 0);
    return Math.min(100, Math.round((top / max) * 100));
  }

  function atBottom(container, threshold = 48) {
    return container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
  }

  function restorePosition(container, scrollTop) {
    const value = Number(scrollTop);
    if (!container || !Number.isFinite(value) || value < 0) return false;
    const max = Math.max(0, container.scrollHeight - container.clientHeight);
    container.scrollTop = Math.min(value, max);
    return true;
  }

  function rowSignature(findRows) {
    return findRows().map((row) => row.__lxSig || '').filter(Boolean).join('|');
  }

  async function scrollToBottom({ findRows, settings, shouldPause, onProgress }) {
    const firstRows = findRows();
    const container = findContainer(firstRows);
    let passes = 0;
    let noGrowth = 0;
    let lastHeight = container.scrollHeight;
    let lastTop = container.scrollTop;
    let lastCount = firstRows.length;

    while (passes < settings.maxScrollPasses) {
      if (shouldPause()) return { paused: true, progress: progressOf(container), scrollTop: container.scrollTop, passes };
      passes += 1;

      const beforeCount = findRows().length;
      const beforeHeight = container.scrollHeight;
      const beforeTop = container.scrollTop;
      const distance = U.randomBetween(settings.scrollMinPx, settings.scrollMaxPx);
      container.scrollBy({ top: distance, left: 0, behavior: settings.humanMode ? 'smooth' : 'auto' });

      try {
        await Wait.waitForCondition(() => {
          const moved = Math.abs(container.scrollTop - beforeTop) > 8;
          const grew = container.scrollHeight > beforeHeight;
          const countGrew = findRows().length > beforeCount;
          return moved || grew || countGrew || atBottom(container);
        }, { root: container, timeoutMs: Math.min(settings.timeoutMs, 5000), shouldCancel: shouldPause });
      } catch (_) {
        // The next pass evaluates whether progress actually occurred.
      }

      if (settings.humanMode) {
        const pause = U.randomBetween(settings.scrollPauseMinMs, settings.scrollPauseMaxMs);
        if (pause > 0) await Wait.wait(pause);
      }

      const currentCount = findRows().length;
      const currentHeight = container.scrollHeight;
      const currentTop = container.scrollTop;
      const progressed = currentCount > beforeCount || currentHeight > beforeHeight || currentTop > beforeTop + 8;

      if (!progressed) noGrowth += 1;
      else noGrowth = 0;

      if (currentHeight === lastHeight && currentTop === lastTop && currentCount === lastCount) noGrowth += 1;
      lastHeight = currentHeight;
      lastTop = currentTop;
      lastCount = currentCount;

      const progress = progressOf(container);
      Logger.debug('Scroll pass', passes, 'progress', progress, 'rows', currentCount, 'height', currentHeight);
      if (typeof onProgress === 'function') {
        await onProgress({ progress, scrollTop: currentTop, scrollHeight: currentHeight, rows: currentCount, passes });
      }

      if (atBottom(container)) {
        try {
          await Wait.waitForCondition(() => {
            const nowCount = findRows().length;
            return nowCount > currentCount || container.scrollHeight > currentHeight;
          }, { root: container, timeoutMs: 2500, shouldCancel: shouldPause });
          noGrowth = 0;
          continue;
        } catch (_) {
          // No growth at bottom is a normal finish signal.
        }
      }

      if (noGrowth >= 3) break;
    }

    if (passes >= settings.maxScrollPasses) Logger.warning('Maximum scroll passes reached', settings.maxScrollPasses);
    return {
      paused: false,
      progress: progressOf(container),
      scrollTop: container.scrollTop,
      scrollHeight: container.scrollHeight,
      passes
    };
  }

  root.LXScroll = { findContainer, restorePosition, progressOf, atBottom, scrollToBottom };
})(typeof window !== 'undefined' ? window : globalThis);
