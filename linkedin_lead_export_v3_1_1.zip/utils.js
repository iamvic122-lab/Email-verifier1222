/* utils.js — shared URL, text, selector, timing and export helpers. */
(function attachUtils(root) {
  const NA = 'N/A';

  function cleanText(value) {
    if (value == null) return '';
    return String(value).replace(/[\u00a0\u200b]+/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function normalizeUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let candidate = String(rawUrl).trim();
      if (!candidate) return '';
      if (candidate.startsWith('/')) candidate = `https://www.linkedin.com${candidate}`;
      const url = new URL(candidate, window.location.origin);
      if (!/linkedin\.com$/i.test(url.hostname)) return '';
      url.protocol = 'https:';
      url.hostname = 'www.linkedin.com';
      url.search = '';
      url.hash = '';
      url.pathname = url.pathname.replace(/\/+/g, '/').replace(/\/$/, '');
      return url.toString();
    } catch (_) {
      return String(rawUrl).split(/[?#]/, 1)[0].replace(/,$/, '').trim();
    }
  }

  function convertLeadUrl(rawUrl) {
    const url = normalizeUrl(rawUrl);
    if (!url) return '';
    return url.replace('/sales/lead/', '/in/');
  }

  function convertCompanyUrl(rawUrl) {
    const url = normalizeUrl(rawUrl);
    if (!url) return '';
    return url.replace('/sales/company/', '/company/');
  }

  function extractLeadId(inUrl) {
    const url = convertLeadUrl(inUrl);
    const match = url.match(/\/in\/([^/?#,]+)/i);
    return match ? decodeURIComponent(match[1]) : '';
  }

  function extractCompanyId(inUrl) {
    const url = convertCompanyUrl(inUrl);
    const match = url.match(/\/company\/([^/?#,]+)/i);
    return match ? decodeURIComponent(match[1]) : '';
  }

  function displayValue(value) {
    if (value == null || String(value).trim() === '') return NA;
    return String(value).trim();
  }

  function calculateDataQuality(lead) {
    const required = [
      'personName', 'jobTitle', 'companyName', 'location',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount',
      'connectionDegree', 'yearsInRole', 'yearsInCompany', 'about'
    ];
    const present = required.reduce((count, key) => count + (lead && String(lead[key] ?? '').trim() ? 1 : 0), 0);
    const percent = Math.round((present / required.length) * 100);
    return { percent, status: percent >= 80 ? 'complete' : percent >= 50 ? 'partial' : 'weak' };
  }

  function normalizeLead(rawLead) {
    const next = { ...(rawLead || {}) };
    const textFields = [
      'personName', 'jobTitle', 'companyName', 'location',
      'connectionDegree', 'about', 'yearsInRole', 'yearsInCompany',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount', 'capturedFromUrl'
    ];
    textFields.forEach((key) => { next[key] = cleanText(next[key]); });
    next.personLinkedInUrl = convertLeadUrl(next.personLinkedInUrl);
    next.companyLinkedInUrl = convertCompanyUrl(next.companyLinkedInUrl);
    next.leadId = next.leadId || extractLeadId(next.personLinkedInUrl);
    next.companyId = next.companyId || extractCompanyId(next.companyLinkedInUrl);
    next.premium = !!next.premium;
    next.sourceRow = Number.isFinite(Number(next.sourceRow)) ? Number(next.sourceRow) : 0;
    next.capturedAt = next.capturedAt || new Date().toISOString();
    next.lastSeenAt = next.lastSeenAt || next.capturedAt;
    next.dataQuality = calculateDataQuality(next);
    return next;
  }

  function leadKey(lead) {
    const normalized = normalizeLead(lead);
    return (normalized.personLinkedInUrl || normalized.leadId || '').toLowerCase();
  }

  function pageKey(url = window.location.href) {
    try {
      const parsed = new URL(url);
      parsed.hash = '';
      return parsed.toString();
    } catch (_) {
      return String(url || '');
    }
  }

  function searchKey(url = window.location.href) {
    try {
      const parsed = new URL(url);
      parsed.hash = '';
      parsed.searchParams.delete('page');
      parsed.searchParams.delete('start');
      parsed.searchParams.delete('cursor');
      return parsed.toString();
    } catch (_) {
      return String(url || '');
    }
  }


  function isExtensionContextInvalidated(error) {
    const message = cleanText(error?.message || error || '');
    return /extension context invalidated/i.test(message);
  }


  function randomBetween(min, max) {
    const low = Math.min(Number(min) || 0, Number(max) || 0);
    const high = Math.max(Number(min) || 0, Number(max) || 0);
    return Math.round(low + Math.random() * (high - low));
  }

  function csvEscape(value) {
    const s = value == null ? '' : String(value);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  function tsvEscape(value) {
    return String(value == null ? '' : value).replace(/[\t\r\n]+/g, ' ').trim();
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(Number(value) || min, min), max);
  }

  function escapeCss(value) {
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function buildStableSelector(element) {
    if (!element || element.nodeType !== 1) return '';
    const tag = element.tagName.toLowerCase();
    const testAttrs = ['data-test-pagination-next', 'data-test-load-more', 'data-test-id', 'data-test'];
    for (const attr of testAttrs) {
      const value = element.getAttribute(attr);
      if (value) return `${tag}[${attr}="${value.replace(/"/g, '\\"')}"]`;
    }
    const aria = cleanText(element.getAttribute('aria-label') || '');
    if (aria) return `${tag}[aria-label="${aria.replace(/"/g, '\\"')}"]`;
    const title = cleanText(element.getAttribute('title') || '');
    if (title) return `${tag}[title="${title.replace(/"/g, '\\"')}"]`;
    const href = element.getAttribute('href');
    if (tag === 'a' && href) {
      const normalized = String(href).split(/[?#]/, 1)[0];
      return `a[href="${normalized.replace(/"/g, '\\"')}"]`;
    }
    const classes = [...element.classList].filter((name) => name && !/^ember|^css-|^sc-|^artdeco/i.test(name)).slice(0, 3);
    if (classes.length) return `${tag}${classes.map((name) => `.${escapeCss(name)}`).join('')}`;
    return buildNthChildSelector(element);
  }

  function buildNthChildSelector(element) {
    const parts = [];
    let node = element;
    let guard = 0;
    while (node && node.nodeType === 1 && node !== document.body && guard < 5) {
      let part = node.tagName.toLowerCase();
      const siblings = node.parentElement ? [...node.parentElement.children].filter((child) => child.tagName === node.tagName) : [];
      const index = siblings.indexOf(node);
      if (index >= 0) part += `:nth-of-type(${index + 1})`;
      parts.unshift(part);
      node = node.parentElement;
      guard += 1;
    }
    return parts.join(' > ');
  }

  const rootUtils = root.LX || {};
  root.LX = Object.assign(rootUtils, {
    NA, cleanText, normalizeUrl, convertLeadUrl, convertCompanyUrl,
    extractLeadId, extractCompanyId, displayValue, calculateDataQuality,
    normalizeLead, leadKey, pageKey, searchKey, randomBetween, csvEscape,
    tsvEscape, clamp, buildStableSelector, isExtensionContextInvalidated,
    COLUMNS: [
      { key: 'personName', label: 'Person Name' },
      { key: 'jobTitle', label: 'Job Title' },
      { key: 'personLinkedInUrl', label: 'Person LinkedIn URL' },
      { key: 'companyName', label: 'Company Name' },
      { key: 'companyLinkedInUrl', label: 'Company LinkedIn URL' },
      { key: 'location', label: 'Location' },
      { key: 'employeeCount', label: 'Employee Count' },
      { key: 'connectionDegree', label: 'Connection Degree' },
      { key: 'yearsInRole', label: 'Years in Role' },
      { key: 'yearsInCompany', label: 'Years in Company' },
      { key: 'about', label: 'About' },
      { key: 'dataQuality', label: 'Data Quality' }
    ],
    exportValue(lead, key) {
      if (key === 'dataQuality') {
        const q = lead && lead.dataQuality;
        return q ? `${q.percent}% ${q.status}` : NA;
      }
      return displayValue(lead && lead[key]);
    },
    clone(value) {
      return value == null ? value : JSON.parse(JSON.stringify(value));
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
