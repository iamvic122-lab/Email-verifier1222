/* controller.js — persistent state-machine orchestrator for scraping and page/load-more actions. */
(function attachController(root) {
  const C = root.LXConstants;
  const S = root.LXStorage;
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;
  const Extractor = root.LXExtractor;
  const Scroll = root.LXScroll;
  const Pagination = root.LXPagination;
  const Safety = root.LXSafety;

  function isContextInvalidated(error) {
    return !!U.isExtensionContextInvalidated?.(error);
  }

  const ACTIVE_STATES = new Set([
    C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
    C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE
  ]);

  class Controller {
    constructor() {
      this.settings = { ...C.DEFAULTS };
      this.state = C.STATES.IDLE;
      this.meta = {};
      this.runPromise = null;
      this.pauseRequested = false;
      this.stopRequested = false;
      this.autoSaveTimer = null;
      this.startedAtMs = 0;
      this.lastProgressAt = 0;
    }

    async init() {
      this.settings = await S.getSettings();
      Logger.setDebug(this.settings.debugMode);
      this.meta = await S.getMeta();
      this.state = this.meta.state || C.STATES.IDLE;
      if (!this.meta.state) await this._persist({ state: C.STATES.IDLE });
      return this.getSnapshot();
    }

    getSnapshot() {
      return U.clone({ state: this.state, settings: this.settings, ...this.meta });
    }

    async refreshSettings() {
      this.settings = Safety.validateSettings(await S.getSettings());
      Logger.setDebug(this.settings.debugMode);
      return this.settings;
    }

    _baseMeta() {
      const now = new Date().toISOString();
      return {
        state: this.state,
        currentUrl: window.location.href,
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        lastActivityAt: now,
        updatedAt: now
      };
    }

    async _persist(patch = {}) {
      this.meta = { ...this.meta, ...this._baseMeta(), ...patch };
      this.meta = await S.setMeta(this.meta);
      return this.meta;
    }

    async _transition(nextState, patch = {}) {
      const valid = Object.values(C.STATES).includes(nextState) ? nextState : C.STATES.ERROR;
      this.state = valid;
      Logger.info('State →', valid, patch.reason || '');
      await this._persist({ currentStateReason: patch.reason || '', ...patch });
      return this.state;
    }

    _getPageNumber() {
      try {
        const page = Number(new URL(window.location.href).searchParams.get('page'));
        return Number.isFinite(page) && page > 0 ? page : Number(this.meta.currentPage) || 1;
      } catch (_) {
        return Number(this.meta.currentPage) || 1;
      }
    }

    _shouldPause() { return this.pauseRequested || this.state === C.STATES.PAUSED; }
    _shouldStop() { return this.stopRequested || this.state === C.STATES.STOPPED; }

    async _checkSafety(context) {
      if (!this.settings.safetyMode) return { risky: false };
      const result = Safety.detect();
      await this._persist({ lastSafetyCheckAt: new Date().toISOString(), safetyContext: context });
      if (result.risky && this.settings.stopOnSecurityPrompt) {
        Logger.error('Safety guard triggered', result.reason);
        this.stopRequested = true;
        await this._transition(C.STATES.STOPPED, {
          currentStateReason: 'Safety guard stopped the run.',
          lastError: result.reason,
          safetyEvent: result,
          stoppedAt: new Date().toISOString()
        });
        this._stopAutoSave();
        return result;
      }
      return result;
    }

    async _beforeAction(context) {
      if (this._shouldStop() || this._shouldPause()) return false;
      const safety = await this._checkSafety(context);
      if (safety.risky && this.settings.stopOnSecurityPrompt) return false;
      if (!this.settings.safetyMode) return true;
      const budget = await Safety.waitForActionBudget(this.meta, this.settings, Wait);
      await this._persist(budget);
      return !this._shouldStop() && !this._shouldPause();
    }

    _startAutoSave() {
      this._stopAutoSave();
      if (!this.settings.autoSave) return;
      const schedule = () => {
        this.autoSaveTimer = setTimeout(async () => {
          this.autoSaveTimer = null;
          if (this.state === C.STATES.FINISHED || this.state === C.STATES.STOPPED || this.state === C.STATES.ERROR) return;
          try {
            await this._persist({ lastAutosaveAt: new Date().toISOString() });
          } catch (error) {
            Logger.warning('Autosave failed', error?.message || error);
          }
          schedule();
        }, this.settings.autoSaveMs);
      };
      schedule();
    }

    _stopAutoSave() {
      if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }

    async start({ resume = true, currentPage = true } = {}) {
      if (this.runPromise) return this.getSnapshot();
      await this.refreshSettings();

      const existing = await S.getMeta();
      const sameSearch = existing.searchKey && existing.searchKey === U.searchKey(window.location.href);
      const resumable = [
        C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE,
        C.STATES.PAUSED, C.STATES.STOPPED, C.STATES.ERROR
      ].includes(existing.state);

      if (resume && this.settings.autoResume && sameSearch && resumable && existing.runId) {
        this.meta = existing;
        this.state = existing.state === C.STATES.PAUSED ? C.STATES.PAUSED : C.STATES.STARTING;
        Logger.info('Resuming run', existing.runId, 'page', existing.currentPage);
      } else {
        this.meta = {
          runId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          searchKey: U.searchKey(window.location.href),
          startedAt: new Date().toISOString(),
          pagesProcessed: 0,
          currentPage: currentPage ? this._getPageNumber() : 1,
          collectedThisRun: 0,
          duplicates: 0,
          errors: 0,
          visitedPages: [],
          lastError: '',
          currentStateReason: 'Run started',
          paginationMode: this.settings.paginationMode,
          paginationTargetSelector: this.settings.paginationTargetSelector,
          actionsInWindow: 0,
          actionWindowStartedAt: Date.now(),
          debug: {}
        };
        this.state = C.STATES.STARTING;
      }

      this.pauseRequested = false;
      this.stopRequested = false;
      this.startedAtMs = Date.now();
      this.lastProgressAt = Date.now();
      const currentLeadCount = await S.getLeadCount();
      this.meta.totalLeads = currentLeadCount;
      await this._persist({
        totalLeads: currentLeadCount,
        paginationMode: this.settings.paginationMode,
        paginationTargetSelector: this.settings.paginationTargetSelector
      });
      this._startAutoSave();
      this.runPromise = this._runLoop().finally(() => { this.runPromise = null; });
      return this.getSnapshot();
    }

    async pause() {
      this.pauseRequested = true;
      if (![C.STATES.FINISHED, C.STATES.STOPPED].includes(this.state)) {
        this.state = C.STATES.PAUSED;
        await this._persist({ state: C.STATES.PAUSED, currentStateReason: 'Paused by user' });
      }
      return this.getSnapshot();
    }

    async resume() {
      await this.refreshSettings();
      this.pauseRequested = false;
      this.stopRequested = false;
      const safety = await this._checkSafety('resume');
      if (safety.risky && this.settings.stopOnSecurityPrompt) return this.getSnapshot();
      if (!this.runPromise) return this.start({ resume: true });
      if (this.state === C.STATES.PAUSED) {
        this.state = C.STATES.STARTING;
        await this._persist({ state: C.STATES.STARTING, currentStateReason: 'Resumed by user' });
      }
      return this.getSnapshot();
    }

    async stop() {
      this.stopRequested = true;
      this.pauseRequested = false;
      this._stopAutoSave();
      this.state = C.STATES.STOPPED;
      await this._persist({ state: C.STATES.STOPPED, currentStateReason: 'Stopped by user', stoppedAt: new Date().toISOString() });
      return this.getSnapshot();
    }

    async resetRun() {
      this.pauseRequested = false;
      this.stopRequested = true;
      this._stopAutoSave();
      this.runPromise = null;
      await S.setMeta({
        state: C.STATES.IDLE,
        currentStateReason: 'Run reset',
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        pagesProcessed: 0,
        collectedThisRun: 0,
        duplicates: 0,
        errors: 0,
        visitedPages: [],
        lastError: '',
        actionsInWindow: 0,
        actionWindowStartedAt: Date.now(),
        paginationMode: this.settings.paginationMode,
        paginationTargetSelector: this.settings.paginationTargetSelector,
        debug: {}
      });
      this.meta = await S.getMeta();
      this.state = C.STATES.IDLE;
      this.stopRequested = false;
      return this.getSnapshot();
    }

    async extractCurrentPage() {
      await this.refreshSettings();
      const readiness = await this.waitForReady();
      if (!readiness.ready) return { ok: false, reason: readiness.reason, readiness };
      return this.collectAndSavePage();
    }

    async waitForReady() {
      const stableMs = U.clamp(this.settings.stableMs, C.LIMITS.stableMs.min, C.LIMITS.stableMs.max);
      const timeoutMs = U.clamp(this.settings.timeoutMs, C.LIMITS.timeoutMs.min, C.LIMITS.timeoutMs.max);
      const body = document.body || document.documentElement;
      const startedAt = Date.now();
      let lastSignature = '';
      let stableSince = 0;
      let mutations = 0;
      let currentRows = 0;
      let evaluateQueued = false;

      return new Promise((resolve) => {
        let observer = null;
        let stableTimer = null;
        let timeoutTimer = null;
        let finished = false;

        const cleanup = () => {
          observer?.disconnect();
          if (stableTimer) clearTimeout(stableTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
        };
        const finish = (result) => {
          if (finished) return;
          finished = true;
          cleanup();
          resolve({ ...result, waitedMs: Date.now() - startedAt, rowsVisible: currentRows, mutations });
        };
        const evaluate = () => {
          if (finished || evaluateQueued) return;
          evaluateQueued = true;
          queueMicrotask(() => {
            evaluateQueued = false;
            if (finished) return;
            if (this._shouldStop()) return finish({ ready: false, reason: 'cancelled' });
            currentRows = Extractor.findResultRows().length;
            const signature = Extractor.signature();
            const blocked = Extractor.hasBlockingLoader();
            if (signature !== lastSignature || blocked) {
              lastSignature = signature;
              stableSince = blocked || !signature ? 0 : Date.now();
              if (stableTimer) clearTimeout(stableTimer);
            }
            if (currentRows > 0 && signature && !blocked) {
              if (!stableSince) stableSince = Date.now();
              const remaining = stableMs - (Date.now() - stableSince);
              if (remaining <= 0) return finish({ ready: true, reason: 'stable' });
              if (stableTimer) clearTimeout(stableTimer);
              stableTimer = setTimeout(evaluate, remaining);
            }
          });
        };

        try {
          observer = new MutationObserver((changes) => {
            mutations += changes.length;
            evaluate();
          });
          observer.observe(body, { subtree: true, childList: true, attributes: true, characterData: true });
        } catch (error) {
          Logger.warning('Readiness observer unavailable', error?.message || error);
        }

        evaluate();
        timeoutTimer = setTimeout(() => finish({
          ready: false,
          reason: currentRows ? 'timeout-unstable' : 'timeout-no-results'
        }), timeoutMs);
      });
    }

    async collectAndSavePage() {
      const extraction = Extractor.extractAll({ retryCount: this.settings.retryCount });
      await this._transition(C.STATES.SAVING, {
        currentPage: this._getPageNumber(),
        currentSelector: extraction.selector || 'resultRow/personLink',
        failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
        rowsFound: extraction.rowsFound,
        rowFailures: extraction.failures.length,
        debug: {
          currentSelector: extraction.selector || 'resultRow/personLink',
          failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
          rowsFound: extraction.rowsFound,
          failedRows: extraction.failures
        }
      });

      let added = 0;
      let updated = 0;
      let duplicates = 0;
      const retryCount = Math.max(1, Math.min(6, Number(this.settings.retryCount) || 3));

      for (const lead of extraction.leads) {
        if (this._shouldStop()) break;
        while (this._shouldPause()) {
          if (this._shouldStop()) return { ok: false, stopped: true };
          await Wait.wait(300);
        }

        let saved = false;
        let lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try {
            await this._persist({ retryCount: attempt, debug: { currentSelector: 'storage.upsertLead', retryCount: attempt, leadKey: U.leadKey(lead) } });
            const result = await S.upsertLead(lead);
            if (result.added) added += 1;
            else if (result.updated) updated += 1;
            else duplicates += 1;
            saved = true;
            this.lastProgressAt = Date.now();
            const totalLeads = await S.getLeadCount();
            await this._persist({
              totalLeads,
              collectedThisRun: Number(this.meta.collectedThisRun || 0) + (result.added ? 1 : 0),
              duplicates: Number(this.meta.duplicates || 0) + (!result.added && !result.updated ? 1 : 0),
              lastSavedLead: U.leadKey(lead),
              lastSavedAt: new Date().toISOString()
            });
            break;
          } catch (error) {
            lastError = error;
            Logger.warning('Lead save attempt failed', attempt, error?.message || error);
            if (attempt < retryCount) await Wait.wait(Math.min(1000, 200 * attempt));
          }
        }

        if (!saved) {
          const errors = Number(this.meta.errors || 0) + 1;
          await this._persist({
            errors,
            lastError: lastError?.message || 'Lead save failed',
            debug: { currentSelector: 'storage.upsertLead', failedLead: U.leadKey(lead), retryCount }
          });
          Logger.error('Lead skipped after retries', lastError);
        }
      }

      await this._persist({
        pagesProcessed: Number(this.meta.pagesProcessed || 0) + 1,
        lastPageSavedAt: new Date().toISOString(),
        lastPageStats: { rowsFound: extraction.rowsFound, added, updated, duplicates, rowFailures: extraction.failures.length }
      });

      if (this.settings.autoDownload && extraction.leads.length && root.LXExport?.downloadCsv) {
        try { root.LXExport.downloadCsv(await S.getLeads()); }
        catch (error) { Logger.warning('Auto-download failed', error?.message || error); }
      }
      return { ok: !this._shouldStop(), extraction, added, updated, duplicates };
    }

    async _processScroll() {
      await this._transition(C.STATES.SCROLLING, { currentPage: this._getPageNumber(), paginationMode: C.PAGINATION_MODES.SCROLL });
      const container = Scroll.findContainer(Extractor.findResultRows());
      const resumeSamePage = this.meta.resumePageKey === U.pageKey(window.location.href);
      if (resumeSamePage && Number.isFinite(Number(this.meta.scrollTop))) Scroll.restorePosition(container, Number(this.meta.scrollTop));
      const result = await Scroll.scrollToBottom({
        findRows: () => Extractor.findResultRows(true),
        settings: this.settings,
        shouldPause: () => this._shouldPause() || this._shouldStop(),
        onProgress: async (progress) => {
          await this._persist({
            scrollProgress: progress.progress,
            scrollTop: progress.scrollTop,
            resumePageKey: U.pageKey(window.location.href),
            loadedRows: progress.rows
          });
        }
      });
      await this._persist({ scrollProgress: result.progress, scrollTop: result.scrollTop, resumePageKey: U.pageKey(window.location.href) });
      if (result.paused) {
        await this.pause();
        this._stopAutoSave();
        return false;
      }
      return !this._shouldStop();
    }

    async _processLoadMoreButtons() {
      let iterations = 0;
      const maxIterations = Math.min(this.settings.maxScrollPasses, 200);
      while (!this._shouldStop() && !this._shouldPause() && iterations < maxIterations) {
        const target = Pagination.findLoadMoreButton(this.settings.paginationTargetSelector);
        if (!target) return true;
        if (!(await this._beforeAction('load-more-button'))) return false;
        iterations += 1;
        await this._transition(C.STATES.NEXT_PAGE, {
          currentPage: this._getPageNumber(),
          currentStateReason: `Loading more results (${iterations})`
        });
        const before = Pagination.getPageDescriptor();
        const result = await Pagination.clickLoadMoreWithRetry(
          before,
          this.settings,
          null,
          () => this._shouldStop() || this._shouldPause()
        );
        await this._persist({ lastLoadMoreAttempt: { iteration: iterations, ...result } });
        if (!result.ok) throw new Error(`Load more failed: ${result.reason}`);
        if (result.finished) return true;
        await this._transition(C.STATES.WAITING_PAGE, {
          currentPage: this._getPageNumber(),
          currentUrl: window.location.href,
          pageChangeWaitMs: result.waitedMs || 0
        });
        const ready = await this.waitForReady();
        await this._persist({ lastReadiness: ready });
        if (!ready.ready && ready.reason !== 'cancelled') throw new Error('Loaded results did not become ready before timeout.');
      }
      if (iterations >= maxIterations) throw new Error('Load-more loop guard reached its maximum iterations.');
      return !this._shouldStop();
    }

    async _runLoop() {
      try {
        const pageGuard = await this._validateSearchContext();
        if (!pageGuard.ok) {
          await this._transition(C.STATES.ERROR, { lastError: pageGuard.reason, errors: Number(this.meta.errors || 0) + 1 });
          return;
        }

        const mode = Object.values(C.PAGINATION_MODES).includes(this.settings.paginationMode)
          ? this.settings.paginationMode : C.PAGINATION_MODES.CLICK_LINK;
        const maxPages = Math.max(1, Number(this.settings.maxPages) || 1000);
        const visited = new Set(Array.isArray(this.meta.visitedPages) ? this.meta.visitedPages : []);

        while (!this._shouldStop()) {
          if (this._shouldPause()) {
            await this.pause();
            this._stopAutoSave();
            return;
          }

          if (Number(this.meta.pagesProcessed || 0) >= maxPages) {
            await this._transition(C.STATES.FINISHED, { currentStateReason: 'Maximum page limit reached' });
            break;
          }

          const safety = await this._checkSafety('page-start');
          if (safety.risky && this.settings.stopOnSecurityPrompt) return;

          await this._transition(C.STATES.STARTING, { currentPage: this._getPageNumber(), paginationMode: mode });
          const ready = await this.waitForReady();
          await this._persist({ lastReadiness: ready, scrollProgress: 0 });
          if (!ready.ready) {
            if (ready.reason === 'cancelled') return;
            throw new Error(ready.reason === 'timeout-no-results'
              ? 'No lead rows became available before timeout.'
              : `Result rows did not stabilize before timeout (${this.settings.timeoutMs}ms).`);
          }

          if (mode === C.PAGINATION_MODES.SCROLL || (mode === C.PAGINATION_MODES.CLICK_LINK && this.settings.autoScroll)) {
            if (!(await this._processScroll())) return;
          }

          if (mode === C.PAGINATION_MODES.CLICK_BUTTON) {
            if (!(await this._processLoadMoreButtons())) return;
          }

          await this._transition(C.STATES.COLLECTING, { currentPage: this._getPageNumber(), paginationMode: mode });
          const descriptor = Pagination.getPageDescriptor();
          const pageId = `${descriptor.searchKey}|${descriptor.pageKey}|${descriptor.signature}`;
          if (visited.has(pageId)) throw new Error('Pagination loop detected: this result page was already processed.');
          visited.add(pageId);
          await this._persist({ visitedPages: Array.from(visited).slice(-maxPages), currentSignature: descriptor.signature });

          const result = await this.collectAndSavePage();
          if (!result.ok || this._shouldStop()) {
            await this.stop();
            return;
          }

          if (mode !== C.PAGINATION_MODES.CLICK_LINK || !this.settings.autoNextPage || !Pagination.hasNext()) {
            await this._transition(C.STATES.FINISHED, { currentStateReason: mode === C.PAGINATION_MODES.CLICK_LINK ? 'No next page available' : 'Selected load-more mode completed' });
            break;
          }

          if (!(await this._beforeAction('next-page-link'))) return;
          const previous = Pagination.getPageDescriptor();
          await this._transition(C.STATES.NEXT_PAGE, {
            currentPage: this._getPageNumber(),
            navigationPending: true,
            navigationStartedAt: new Date().toISOString(),
            navigationFromUrl: previous.url,
            navigationFromPageKey: previous.pageKey,
            currentSignature: previous.signature
          });
          const next = await Pagination.clickNextWithRetry(previous, this.settings, null, () => this._shouldStop() || this._shouldPause());
          if (!next.ok) throw new Error(`Next page failed: ${next.reason}`);

          const nextPageNumber = Math.max(this._getPageNumber(), Number(this.meta.currentPage || 1) + 1);
          await this._transition(C.STATES.WAITING_PAGE, {
            currentPage: nextPageNumber,
            currentUrl: next.descriptor.url,
            pageChangeWaitMs: next.waitedMs,
            scrollTop: 0,
            scrollProgress: 0,
            resumePageKey: U.pageKey(next.descriptor.url),
            navigationPending: false,
            navigationCompletedAt: new Date().toISOString()
          });

          if (U.searchKey(window.location.href) !== this.meta.searchKey) {
            throw new Error('Search context changed during pagination; run stopped to prevent mixing datasets.');
          }
        }

        if (![C.STATES.PAUSED, C.STATES.ERROR, C.STATES.STOPPED].includes(this.state)) {
          await this._persist({ finishedAt: new Date().toISOString() });
        }
      } catch (error) {
        if (isContextInvalidated(error)) {
          this.pauseRequested = false;
          this.stopRequested = false;
          // Do not call chrome.storage or other extension APIs here. Once a
          // content-script context is invalidated, those calls can throw again.
          // The run state was checkpointed before navigation/action boundaries;
          // a new content-script instance can safely resume from that checkpoint.
          try { console.warn('[LX] Extension context invalidated; ending this controller instance so a new context can resume safely.'); } catch (_) {}
          return;
        }

        Logger.error('Controller failed', error?.message || error);
        const errors = Number(this.meta.errors || 0) + 1;
        try {
          await this._transition(C.STATES.ERROR, {
            lastError: error?.message || 'Unknown controller error',
            errors,
            debug: {
              currentState: this.state,
              currentUrl: window.location.href,
              lastError: error?.message || 'Unknown controller error'
            }
          });
        } catch (persistError) {
          if (isContextInvalidated(persistError)) return;
          try { Logger.error('Failed to persist controller error state', persistError?.message || persistError); } catch (_) {}
        }
      } finally {
        this._stopAutoSave();
      }
    }

    async _validateSearchContext() {
      const path = window.location.pathname;
      if (!/\/sales\/(search|lists|people)/i.test(path)) {
        return { ok: false, reason: 'Open a Sales Navigator search/list/people view before starting.' };
      }
      const existing = await S.getMeta();
      if (existing.searchKey && existing.searchKey !== U.searchKey(window.location.href) && existing.state && ![C.STATES.IDLE, C.STATES.STOPPED, C.STATES.FINISHED].includes(existing.state)) {
        return { ok: false, reason: 'The current search does not match the saved run. Reset the run before starting a different search.' };
      }
      return { ok: true };
    }
  }

  root.LXController = new Controller();
})(typeof window !== 'undefined' ? window : globalThis);
