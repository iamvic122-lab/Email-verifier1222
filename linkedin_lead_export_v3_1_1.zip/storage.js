/* storage.js — resilient local persistence with serialized writes and indexed lead upserts. */
(function attachStorage(root) {
  const C = root.LXConstants;
  const U = root.LX;
  const Logger = root.LXLogger || console;
  const KEYS = C.STORAGE_KEYS;
  const cache = {
    loaded: false,
    leads: [],
    byKey: new Map(),
    leadsWriteChain: Promise.resolve(),
    metaWriteChain: Promise.resolve()
  };

  function storageTimeoutMs() {
    return Number(C.DEFAULTS.storageTimeoutMs) || 10000;
  }

  function contextError(error) {
    const message = String(error?.message || error || 'Storage operation failed');
    return U.isExtensionContextInvalidated?.(error)
      ? new Error('Extension context invalidated')
      : new Error(message);
  }

  function chromeGet(keys) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        reject(new Error(`Storage get timed out after ${storageTimeoutMs()}ms`));
      }, storageTimeoutMs());
      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        fn(value);
      };
      try {
        chrome.storage.local.get(keys, (result) => {
          try {
            const error = chrome.runtime?.lastError;
            if (error) finish(reject, contextError(error));
            else finish(resolve, result || {});
          } catch (error) {
            finish(reject, contextError(error));
          }
        });
      } catch (error) {
        finish(reject, contextError(error));
      }
    });
  }

  function chromeSet(value) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        reject(new Error(`Storage set timed out after ${storageTimeoutMs()}ms`));
      }, storageTimeoutMs());
      const finish = (fn, data) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        fn(data);
      };
      try {
        chrome.storage.local.set(value, () => {
          try {
            const error = chrome.runtime?.lastError;
            if (error) finish(reject, contextError(error));
            else finish(resolve);
          } catch (error) {
            finish(reject, contextError(error));
          }
        });
      } catch (error) {
        finish(reject, contextError(error));
      }
    });
  }

  function chromeRemove(keys) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        reject(new Error(`Storage remove timed out after ${storageTimeoutMs()}ms`));
      }, storageTimeoutMs());
      const finish = (fn, data) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        fn(data);
      };
      try {
        chrome.storage.local.remove(keys, () => {
          try {
            const error = chrome.runtime?.lastError;
            if (error) finish(reject, contextError(error));
            else finish(resolve);
          } catch (error) {
            finish(reject, contextError(error));
          }
        });
      } catch (error) {
        finish(reject, contextError(error));
      }
    });
  }

  function enqueue(chainKey, task) {
    const previous = cache[chainKey];
    const next = previous.then(task, task);
    cache[chainKey] = next.catch(() => {});
    return next;
  }

  async function getSettings() {
    const result = await chromeGet(KEYS.SETTINGS);
    return { ...C.DEFAULTS, ...(result[KEYS.SETTINGS] || {}) };
  }

  async function saveSettings(patch) {
    return enqueue('metaWriteChain', async () => {
      const current = await getSettings();
      const next = { ...current, ...(patch || {}) };
      next.paginationMode = Object.values(C.PAGINATION_MODES).includes(next.paginationMode) ? next.paginationMode : C.DEFAULTS.paginationMode;
      await chromeSet({ [KEYS.SETTINGS]: next });
      return next;
    });
  }

  function rebuildIndex() {
    cache.byKey.clear();
    cache.leads.forEach((lead, index) => {
      const key = U.leadKey(lead);
      if (key && !cache.byKey.has(key)) cache.byKey.set(key, index);
    });
  }

  async function loadLeads(force = false) {
    if (cache.loaded && !force) return cache.leads;
    const result = await chromeGet(KEYS.LEADS);
    const raw = Array.isArray(result[KEYS.LEADS]) ? result[KEYS.LEADS] : [];
    cache.leads = raw.map(U.normalizeLead);
    rebuildIndex();
    cache.loaded = true;
    return cache.leads;
  }

  async function getLeads() {
    return U.clone(await loadLeads());
  }

  async function getLeadCount() {
    await loadLeads();
    return cache.leads.length;
  }

  function mergeField(oldValue, newValue) {
    const oldText = String(oldValue ?? '').trim();
    const newText = String(newValue ?? '').trim();
    if (!newText) return oldValue || '';
    if (!oldText) return newValue;
    if (newText === oldText) return oldValue;
    if (newText.length > oldText.length + 8) return newValue;
    return oldValue;
  }

  function mergeLead(existing, incoming) {
    const merged = { ...existing };
    const fields = [
      'personName', 'jobTitle', 'companyName', 'location', 'connectionDegree',
      'about', 'yearsInRole', 'yearsInCompany', 'personLinkedInUrl',
      'companyLinkedInUrl', 'employeeCount'
    ];
    fields.forEach((key) => { merged[key] = mergeField(existing[key], incoming[key]); });
    merged.premium = !!(existing.premium || incoming.premium);
    merged.sourceRow = incoming.sourceRow || existing.sourceRow || 0;
    merged.capturedFromUrl = incoming.capturedFromUrl || existing.capturedFromUrl || '';
    merged.capturedAt = existing.capturedAt || incoming.capturedAt || new Date().toISOString();
    merged.lastSeenAt = incoming.capturedAt || existing.lastSeenAt || merged.capturedAt;
    merged.leadId = merged.leadId || incoming.leadId || U.extractLeadId(merged.personLinkedInUrl);
    merged.companyId = merged.companyId || incoming.companyId || U.extractCompanyId(merged.companyLinkedInUrl);
    return U.normalizeLead(merged);
  }

  async function persistLeads() {
    return enqueue('leadsWriteChain', async () => {
      await chromeSet({ [KEYS.LEADS]: cache.leads });
    });
  }

  async function upsertLead(rawLead) {
    const incoming = U.normalizeLead(rawLead);
    if (!U.leadKey(incoming)) return { added: false, updated: false, lead: null };
    return enqueue('leadsWriteChain', async () => {
      await loadLeads();
      const key = U.leadKey(incoming);
      const existingIndex = cache.byKey.get(key);
      if (existingIndex == null) {
        cache.leads.push(incoming);
        cache.byKey.set(key, cache.leads.length - 1);
        await chromeSet({ [KEYS.LEADS]: cache.leads });
        return { added: true, updated: false, lead: incoming };
      }
      const current = cache.leads[existingIndex];
      const merged = mergeLead(current, incoming);
      const changed = JSON.stringify(merged) !== JSON.stringify(current);
      cache.leads[existingIndex] = merged;
      if (changed) await chromeSet({ [KEYS.LEADS]: cache.leads });
      return { added: false, updated: changed, lead: merged };
    });
  }

  async function mergeLeads(rawLeads) {
    await loadLeads();
    const result = { all: null, added: [], updated: [], duplicates: 0 };
    for (const rawLead of Array.isArray(rawLeads) ? rawLeads : []) {
      const upserted = await upsertLead(rawLead);
      if (!upserted.lead) continue;
      if (upserted.added) result.added.push(upserted.lead);
      else if (upserted.updated) result.updated.push(upserted.lead);
      else result.duplicates += 1;
    }
    result.all = U.clone(cache.leads);
    return result;
  }

  async function clearLeads() {
    return enqueue('leadsWriteChain', async () => {
      await chromeRemove(KEYS.LEADS);
      cache.loaded = true;
      cache.leads = [];
      cache.byKey.clear();
    });
  }

  async function getMeta() {
    const result = await chromeGet(KEYS.META);
    return result[KEYS.META] || {};
  }

  async function setMeta(patch) {
    return enqueue('metaWriteChain', async () => {
      const current = await getMeta();
      const next = { ...current, ...(patch || {}) };
      await chromeSet({ [KEYS.META]: next });
      return next;
    });
  }

  async function clearMeta() {
    return enqueue('metaWriteChain', async () => {
      try { await chromeRemove(KEYS.META); } catch (error) { Logger.warning('Failed to clear metadata', error); }
    });
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes[KEYS.LEADS]) return;
      cache.loaded = false;
      cache.leads = [];
      cache.byKey.clear();
    });
  } catch (_) {
    // Storage wrapper remains usable in restricted/test contexts.
  }

  root.LXStorage = {
    KEYS,
    DEFAULT_SETTINGS: C.DEFAULTS,
    getSettings,
    saveSettings,
    getLeads,
    getLeadCount,
    loadLeads,
    mergeLeads,
    upsertLead,
    clearLeads,
    getMeta,
    setMeta,
    clearMeta
  };
})(typeof window !== 'undefined' ? window : globalThis);
