/* wait.js — mutation/condition driven synchronization with bounded polling fallback. */
(function attachWait(root) {
  const Logger = root.LXLogger || console;

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
  }

  function waitForCondition(predicate, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 30000;
    const rootNode = options.root || document;
    const observeAttributes = options.observeAttributes !== false;
    const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : () => false;
    const startedAt = Date.now();

    return new Promise((resolve, reject) => {
      let settled = false;
      let observer = null;
      let fallbackTimer = null;
      let pollTimer = null;
      let evaluateQueued = false;

      const cleanup = () => {
        if (observer) observer.disconnect();
        if (fallbackTimer) clearTimeout(fallbackTimer);
        if (pollTimer) clearTimeout(pollTimer);
      };

      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        cleanup();
        if (error) reject(error); else resolve(value);
      };

      const schedulePoll = () => {
        if (settled || pollTimer) return;
        const elapsed = Date.now() - startedAt;
        const remaining = Math.max(50, timeoutMs - elapsed);
        pollTimer = setTimeout(() => {
          pollTimer = null;
          evaluate();
        }, Math.min(300, remaining));
      };

      const evaluate = () => {
        if (settled || evaluateQueued) return;
        evaluateQueued = true;
        queueMicrotask(() => {
          evaluateQueued = false;
          if (settled) return;
          if (shouldCancel()) {
            finish(new Error('Wait cancelled'));
            return;
          }
          try {
            const value = predicate();
            if (value) {
              finish(null, { value, waitedMs: Date.now() - startedAt });
              return;
            }
          } catch (error) {
            Logger.debug('Wait predicate failed; retrying', error?.message || error);
          }
          schedulePoll();
        });
      };

      try {
        observer = new MutationObserver(() => evaluate());
        observer.observe(rootNode, {
          subtree: true,
          childList: true,
          attributes: observeAttributes,
          characterData: true
        });
      } catch (error) {
        Logger.warning('MutationObserver unavailable; using bounded polling', error);
      }

      fallbackTimer = setTimeout(() => finish(new Error(`Wait timed out after ${timeoutMs}ms`)), timeoutMs);
      evaluate();
    });
  }

  function waitForMutation(rootNode, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 5000;
    const observeAttributes = options.observeAttributes !== false;
    return new Promise((resolve, reject) => {
      let done = false;
      const observer = new MutationObserver((mutations) => {
        if (done) return;
        done = true;
        observer.disconnect();
        clearTimeout(timer);
        resolve({ mutations });
      });
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        observer.disconnect();
        reject(new Error(`Mutation wait timed out after ${timeoutMs}ms`));
      }, timeoutMs);
      observer.observe(rootNode || document.body, {
        subtree: true,
        childList: true,
        attributes: observeAttributes,
        characterData: true
      });
    });
  }

  root.LXWait = { wait, waitForCondition, waitForMutation };
})(typeof window !== 'undefined' ? window : globalThis);
