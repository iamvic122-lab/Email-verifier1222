/* safety.js — detects visible security/challenge signals and enforces conservative pacing. */
(function attachSafety(root) {
  const C = root.LXConstants;
  const SEL = root.LXSelectors;
  const U = root.LX;
  const Logger = root.LXLogger;

  const TEXT_PATTERNS = [
    /verify (your|the) identity/i,
    /verify it'?s you/i,
    /security verification/i,
    /security check/i,
    /unusual (activity|sign-in|login)/i,
    /security checkpoint/i,
    /account checkpoint/i,
    /verification checkpoint/i,
    /security challenge/i,
    /captcha/i,
    /temporarily restricted/i,
    /account restricted/i
  ];

  function visible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function detect() {
    for (const selector of SEL.securityMarkers || []) {
      try {
        const match = [...document.querySelectorAll(selector)].find(visible);
        if (match) return { risky: true, reason: `Security marker: ${selector}`, selector };
      } catch (_) {
        // Ignore selector drift and continue with text signals.
      }
    }

    const text = U.cleanText(document.body?.innerText || '').slice(0, 120000);
    for (const pattern of TEXT_PATTERNS) {
      if (pattern.test(text)) return { risky: true, reason: `Security text matched: ${pattern}` };
    }
    return { risky: false };
  }

  function validateSettings(settings) {
    const min = U.clamp(settings.actionDelayMinMs, C.LIMITS.actionDelayMinMs.min, C.LIMITS.actionDelayMinMs.max);
    const max = U.clamp(settings.actionDelayMaxMs, C.LIMITS.actionDelayMaxMs.min, C.LIMITS.actionDelayMaxMs.max);
    return {
      ...settings,
      actionDelayMinMs: Math.min(min, max),
      actionDelayMaxMs: Math.max(min, max),
      maxActionsPerMinute: U.clamp(settings.maxActionsPerMinute, C.LIMITS.maxActionsPerMinute.min, C.LIMITS.maxActionsPerMinute.max)
    };
  }

  async function waitForActionBudget(meta, settings, Wait) {
    const now = Date.now();
    const windowStart = Number(meta.actionWindowStartedAt || now);
    const count = Number(meta.actionsInWindow || 0);
    const oneMinute = 60000;
    const normalized = validateSettings(settings);
    let started = windowStart;
    let used = count;
    if (now - started >= oneMinute) {
      started = now;
      used = 0;
    }
    if (used >= normalized.maxActionsPerMinute) {
      const remaining = oneMinute - (now - started);
      Logger.warning('Safety pacing limit reached; waiting for action window', remaining);
      await Wait.wait(Math.max(1000, remaining));
      started = Date.now();
      used = 0;
    }
    const delay = U.randomBetween(normalized.actionDelayMinMs, normalized.actionDelayMaxMs);
    if (delay > 0) await Wait.wait(delay);
    return { actionWindowStartedAt: started, actionsInWindow: used + 1, lastActionAt: new Date().toISOString() };
  }

  root.LXSafety = { detect, validateSettings, waitForActionBudget };
})(typeof window !== 'undefined' ? window : globalThis);
