/* content.js — runtime message bridge and automatic resume boot. */
(function boot() {
  if (window.__LX_CONTENT_BOOTED__) return;
  window.__LX_CONTENT_BOOTED__ = true;

  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const Logger = window.LXLogger;
  const E = window.LXExtractor;
  const Controller = window.LXController;
  const Pagination = window.LXPagination;
  const Safety = window.LXSafety;

  const isContextInvalidated = (error) => !!U.isExtensionContextInvalidated?.(error);

  async function bootController() {
    try {
      await Controller.init();
      const settings = await S.getSettings();
      Logger.setDebug(settings.debugMode);
      const meta = await S.getMeta();
      const sameSearch = meta.searchKey === U.searchKey(window.location.href);
      const currentMode = E.detectMode();
      const sameMode = !meta.recordType || meta.recordType === currentMode;
      const resumable = [
        C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE
      ].includes(meta.state);
      if (settings.autoResume && sameSearch && sameMode && resumable && meta.runId) {
        Logger.info('Resuming saved run', meta.runId || 'unknown', 'mode', currentMode || 'unknown');
        await Controller.start({ resume: true });
      }
    } catch (error) {
      if (isContextInvalidated(error)) return;
      Logger.error('Controller boot failed', error?.message || error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    (async () => {
      try {
        switch (message.type) {
          case 'LX_PING': {
            const settings = await S.getSettings();
            const safety = Safety.detect();
            const mode = E.detectMode();
            const rows = mode ? E.findResultRows(mode) : [];
            sendResponse({
              ok: true,
              url: window.location.href,
              mode,
              recordType: mode,
              onSearch: !!mode,
              rowsVisible: rows.length,
              loading: E.hasBlockingLoader(),
              safetyRisk: safety,
              pagination: Pagination.verifyTarget(),
              state: (await S.getMeta()).state || C.STATES.IDLE,
              page: Number(new URL(window.location.href).searchParams.get('page')) || 1,
              expectedResultsPerPage: settings.expectedResultsPerPage
            });
            return;
          }
          case 'LX_GET_STATE':
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_START':
            await Controller.start({ resume: true });
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_PAUSE':
            await Controller.pause();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESUME':
            await Controller.resume();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_STOP':
            await Controller.stop();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESET_RUN':
            await Controller.resetRun();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_EXTRACT_PAGE': {
            const result = await Controller.extractCurrentPage();
            if (!result.ok) {
              sendResponse({ ok: false, reason: result.reason || 'Extraction failed' });
              return;
            }
            const allRecords = await S.getLeads();
            const records = allRecords.filter((record) => (record.recordType || C.RECORD_TYPES.PERSON) === result.mode);
            sendResponse({
              ok: true,
              mode: result.mode,
              foundOnPage: result.foundOnPage,
              added: Number(result.live?.added || 0),
              updated: Number(result.live?.updated || 0),
              duplicates: Number(result.live?.duplicates || 0),
              totalLeads: records.length,
              leads: records,
              records
            });
            return;
          }
          case 'LX_VERIFY_TARGET':
            sendResponse({ ok: true, result: Pagination.verifyTarget() });
            return;
          case 'LX_GET_NEXT':
            sendResponse({ ok: true, hasNext: Pagination.hasNext() });
            return;
          default:
            sendResponse({ ok: false, reason: 'Unknown message' });
        }
      } catch (error) {
        if (isContextInvalidated(error)) return;
        Logger.error('Message operation failed', message.type, error?.message || error);
        sendResponse({ ok: false, reason: error?.message || 'Operation failed' });
      }
    })();

    return true;
  });

  void bootController();
})();
