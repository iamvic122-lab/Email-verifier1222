/* extractor.js — automatic person/company result discovery and resilient field extraction. */
(function attachExtractor(root) {
  const U = root.LX;
  const C = root.LXConstants;
  const SEL = root.LXSelectors;
  const Logger = root.LXLogger;

  const Extractor = {
    _activeResultSelector: new Map(),
    _lastResultSelector: null,

    _q(node, selectors) {
      for (const selector of selectors || []) {
        try {
          const element = node?.querySelector(selector);
          if (element) return element;
        } catch (error) {
          Logger.debug('Invalid selector ignored', selector, error?.message || error);
        }
      }
      return null;
    },

    _qAll(node, selector) {
      try { return Array.from(node?.querySelectorAll(selector) || []); } catch (_) { return []; }
    },

    _text(element) { return element ? U.cleanText(element.textContent) : ''; },

    detectMode() {
      try {
        const path = window.location.pathname.toLowerCase();
        if (/\/sales\/search\/people(?:\/|$)/i.test(path)) return C.RECORD_TYPES.PERSON;
        if (/\/sales\/search\/(?:company|companies|account|accounts)(?:\/|$)/i.test(path)) return C.RECORD_TYPES.COMPANY;
      } catch (_) {}

      const companyLinks = this._qAll(document, 'a[data-anonymize="company-name"][href*="/sales/company/"], a[href*="/sales/company/"]');
      if (companyLinks.length) return C.RECORD_TYPES.COMPANY;
      const personLinks = this._qAll(document, 'a[data-anonymize="person-name"], a[href*="/sales/lead/"]');
      if (personLinks.length) return C.RECORD_TYPES.PERSON;
      return null;
    },

    _normalizePersonRowCandidate(row) {
      if (!row || row.nodeType !== 1) return null;
      return this._q(row, SEL.personLink) ? row : null;
    },

    _normalizeCompanyRowCandidate(row) {
      if (!row || row.nodeType !== 1) return null;
      return this._q(row, SEL.companySearchLink) ? row : null;
    },

    _dedupeRows(rows, mode) {
      const seen = new Set();
      const result = [];
      for (const row of rows || []) {
        const key = this.rowSignature(row, mode);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        row.__lxSig = key;
        result.push(row);
      }
      return result;
    },

    invalidateCache(mode = null) {
      if (mode) this._activeResultSelector.delete(mode);
      else this._activeResultSelector.clear();
    },

    _querySelectorRows(selector, mode) {
      try {
        const normalizer = mode === C.RECORD_TYPES.COMPANY ? this._normalizeCompanyRowCandidate.bind(this) : this._normalizePersonRowCandidate.bind(this);
        return this._dedupeRows(
          Array.from(document.querySelectorAll(selector)).map(normalizer).filter(Boolean),
          mode
        );
      } catch (error) {
        Logger.debug('Result selector failed', selector, error?.message || error);
        return [];
      }
    },

    _companyRowsFromAnchors() {
      const rows = new Set();
      try {
        this._qAll(document, 'a[data-anonymize="company-name"][href*="/sales/company/"], a[href*="/sales/company/"]').forEach((anchor) => {
          const row = anchor.closest('li') || anchor.closest('article') || anchor.closest('[role="listitem"]') || anchor.parentElement;
          if (row) rows.add(row);
        });
      } catch (_) {}
      return [...rows];
    },

    _personRowsFromAnchors() {
      const rows = new Set();
      try {
        this._qAll(document, 'a[data-anonymize="person-name"], a[href*="/sales/lead/"]').forEach((anchor) => {
          const row = anchor.closest('li') || anchor.closest('article') || anchor.closest('[role="listitem"]') || anchor.parentElement;
          if (row) rows.add(row);
        });
      } catch (_) {}
      return [...rows];
    },

    findResultRows(mode = this.detectMode()) {
      const resolvedMode = mode || C.RECORD_TYPES.PERSON;
      const selectors = resolvedMode === C.RECORD_TYPES.COMPANY ? SEL.companyResultRow : SEL.personResultRow;
      const normalize = resolvedMode === C.RECORD_TYPES.COMPANY ? this._normalizeCompanyRowCandidate.bind(this) : this._normalizePersonRowCandidate.bind(this);

      const cachedSelector = this._activeResultSelector.get(resolvedMode);
      if (cachedSelector) {
        const current = this._querySelectorRows(cachedSelector, resolvedMode);
        if (current.length) {
          this._lastResultSelector = cachedSelector;
          return current;
        }
        this._activeResultSelector.delete(resolvedMode);
      }

      const scored = [];
      for (const selector of selectors) {
        const rows = this._querySelectorRows(selector, resolvedMode);
        if (rows.length) scored.push({ selector, rows });
      }

      const anchorFallback = resolvedMode === C.RECORD_TYPES.COMPANY ? this._companyRowsFromAnchors() : this._personRowsFromAnchors();
      const fallbackRows = this._dedupeRows(anchorFallback.map(normalize).filter(Boolean), resolvedMode);
      if (fallbackRows.length) scored.push({ selector: `fallback:${resolvedMode}-link-anchor`, rows: fallbackRows });

      if (scored.length) {
        scored.sort((a, b) => b.rows.length - a.rows.length);
        this._activeResultSelector.set(resolvedMode, scored[0].selector);
        this._lastResultSelector = scored[0].selector;
        return scored[0].rows;
      }

      this._lastResultSelector = null;
      return [];
    },

    signature(rows = this.findResultRows()) {
      return rows.map((row) => row.__lxSig || this.rowSignature(row)).filter(Boolean).join('|');
    },

    rowSignature(row, mode = this.detectMode()) {
      const resolvedMode = mode || C.RECORD_TYPES.PERSON;
      if (resolvedMode === C.RECORD_TYPES.COMPANY) {
        const company = this._q(row, SEL.companySearchLink);
        const href = company ? U.convertCompanyUrl(company.getAttribute('href') || '') : '';
        return href || this._text(this._q(row, SEL.companyName));
      }
      const person = this._q(row, SEL.personLink);
      const href = person ? U.convertLeadUrl(person.getAttribute('href') || '') : '';
      return href || this._text(this._q(row, SEL.personName));
    },

    hasBlockingLoader() {
      const rootNode = this.observationRoot();
      for (const selector of SEL.loading) {
        try {
          const found = [...rootNode.querySelectorAll(selector)].some((element) => {
            const style = getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
          });
          if (found) return true;
        } catch (_) {}
      }
      return false;
    },

    observationRoot(mode = this.detectMode()) {
      const row = this.findResultRows(mode)[0];
      return row ? (row.closest('main,section,ol,ul') || document.body) : document.body;
    },

    _extractCompanyAbout(row) {
      const expandButton = this._q(row, SEL.companyAboutExpandButton);
      if (!expandButton) return '';
      const parent = expandButton.parentElement;
      if (!parent) return '';
      try {
        const clone = parent.cloneNode(true);
        clone.querySelectorAll('button').forEach((button) => button.remove());
        return this._text(clone).replace(/(?:…|\.\.\.)\s*$/i, '').trim();
      } catch (_) {
        return this._text(parent).replace(/(?:…|\.\.\.)?\s*Show more$/i, '').trim();
      }
    },

    _extractCompanyLogo(row, companyName) {
      const images = this._qAll(row, SEL.companyLogo);
      const target = U.cleanText(companyName).toLowerCase();
      const preferred = images.find((img) => U.cleanText(img.getAttribute('alt') || '').toLowerCase() === target);
      const fallback = images.find((img) => /^https:\/\/(?:[^/]+\.)?licdn\.com\//i.test(img.getAttribute('src') || ''));
      return U.normalizeMediaUrl((preferred || fallback)?.getAttribute('src') || '');
    },

    extractCompany(row, index = 0) {
      if (!row) return null;
      const companyA = this._q(row, SEL.companySearchLink);
      if (!companyA) return null;
      const companyLinkedInUrl = U.convertCompanyUrl(companyA.getAttribute('href') || '');
      if (!companyLinkedInUrl) return null;

      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      if (!companyName) return null;

      const industry = this._text(this._q(row, SEL.industry));
      let employeeCount = this._text(this._q(row, SEL.companySize));
      if (employeeCount && !/\d/.test(employeeCount)) employeeCount = '';

      let revenue = this._text(this._q(row, SEL.revenue));
      if (revenue.toLowerCase() === 'more info') revenue = '';

      const about = this._extractCompanyAbout(row) || (() => {
        const paragraphs = this._qAll(row, 'p').map((element) => this._text(element)).filter(Boolean);
        return paragraphs.find((text) => /\babout\b/i.test(text))?.replace(/^about:\s*/i, '').trim() || '';
      })();

      const companyProfileImageUrl = this._extractCompanyLogo(row, companyName);

      return U.normalizeLead({
        recordType: C.RECORD_TYPES.COMPANY,
        companyName,
        companyLinkedInUrl,
        companyId: U.extractCompanyId(companyLinkedInUrl),
        industry,
        employeeCount,
        revenue,
        about,
        companyProfileImageUrl,
        sourceRow: index + 1,
        capturedAt: new Date().toISOString(),
        capturedFromUrl: window.location.href
      });
    },

    extractPerson(row, index = 0) {
      if (!row) return null;
      const personA = this._q(row, SEL.personLink) || row.querySelector('a[href*="/sales/lead/"]');
      if (!personA) return null;
      const personLinkedInUrl = U.convertLeadUrl(personA.getAttribute('href') || '');
      if (!personLinkedInUrl) return null;

      let personName = this._text(this._q(row, SEL.personName)) || this._text(personA);
      let jobTitle = this._text(this._q(row, SEL.jobTitle));
      const companyA = this._q(row, SEL.companyLink);
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      const companyLinkedInUrl = companyA ? U.convertCompanyUrl(companyA.getAttribute('href') || '') : '';

      if (jobTitle) jobTitle = jobTitle.split(/\d+\s*(?:year|month)|in role|in company/i)[0].replace(/[,·•]$/, '').trim();
      if (jobTitle && companyName) {
        const marker = ` at ${companyName}`.toLowerCase();
        const indexAt = jobTitle.toLowerCase().lastIndexOf(marker);
        if (indexAt > 0) jobTitle = jobTitle.slice(0, indexAt).trim();
      }

      if (!jobTitle) {
        const candidates = Array.from(row.querySelectorAll('span, div'))
          .map((element) => this._text(element))
          .filter(Boolean)
          .filter((text) => text !== personName && text !== companyName && text.length < 120);
        const skip = /^(1st|2nd|3rd|3\+|connect|message|save|premium|open profile|view profile)$/i;
        jobTitle = candidates.find((text) => !skip.test(text) && !/^\d+\s*(year|month|employee)/i.test(text)) || '';
      }

      const rowText = this._text(row);
      const roleMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in role/i);
      const companyTenureMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in company/i);
      const yearsInRole = roleMatch ? U.cleanText(roleMatch[1]) : '';
      const yearsInCompany = companyTenureMatch ? U.cleanText(companyTenureMatch[1]) : '';

      let connectionDegree = this._text(this._q(row, SEL.connectionDegree));
      const degreeMatch = connectionDegree.match(/(1st|2nd|3rd|3\+|Out of network|Following|You)/i);
      if (degreeMatch) connectionDegree = degreeMatch[1];

      let about = this._text(this._q(row, SEL.about));
      if (!about) about = this._text(row.querySelector('p'));
      about = about.replace(/\s*…\s*Show more$/i, '').trim();

      let employeeCount = this._text(this._q(row, SEL.employeeCount));
      if (employeeCount.includes('·')) employeeCount = employeeCount.split('·')[0].trim();
      if (employeeCount && !/\d/.test(employeeCount)) employeeCount = '';

      return U.normalizeLead({
        recordType: C.RECORD_TYPES.PERSON,
        personName,
        jobTitle,
        companyName,
        location: this._text(this._q(row, SEL.location)),
        employeeCount,
        connectionDegree,
        premium: !!this._q(row, SEL.premiumBadge),
        about,
        yearsInRole,
        yearsInCompany,
        personLinkedInUrl,
        companyLinkedInUrl,
        sourceRow: index + 1,
        leadId: U.extractLeadId(personLinkedInUrl),
        companyId: U.extractCompanyId(companyLinkedInUrl),
        capturedAt: new Date().toISOString(),
        capturedFromUrl: window.location.href
      });
    },

    extractLead(row, index = 0, mode = this.detectMode()) {
      return mode === C.RECORD_TYPES.COMPANY ? this.extractCompany(row, index) : this.extractPerson(row, index);
    },

    extractRecord(row, index = 0, mode = this.detectMode()) {
      return this.extractLead(row, index, mode);
    },

    extractAll(options = {}) {
      const mode = options.mode || this.detectMode() || C.RECORD_TYPES.PERSON;
      const rows = this.findResultRows(mode);
      const retryCount = Math.max(1, Math.min(6, Number(options.retryCount) || 3));
      const records = [];
      const seen = new Set();
      const failures = [];

      rows.forEach((row, index) => {
        let record = null;
        let lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try {
            record = this.extractRecord(row, index, mode);
            if (!record) throw new Error(`Required ${mode} identifier was not available.`);
            lastError = null;
            break;
          } catch (error) {
            lastError = error;
            Logger.warning('Row extraction retry', mode, index + 1, attempt, error?.message || error);
          }
        }
        if (lastError) {
          failures.push({ row: index + 1, message: lastError.message || 'Unknown extraction error', attempts: retryCount });
          Logger.error('Row extraction failed after retries', mode, index + 1, lastError);
          return;
        }
        const key = record ? U.leadKey(record) : '';
        if (!record || !key || seen.has(key)) return;
        seen.add(key);
        records.push(record);
      });

      return { mode, records, leads: records, rowsFound: rows.length, failures, selector: this._lastResultSelector };
    }
  };

  root.LXExtractor = Extractor;
})(typeof window !== 'undefined' ? window : globalThis);
