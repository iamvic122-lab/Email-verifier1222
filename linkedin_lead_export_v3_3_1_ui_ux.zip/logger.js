/* logger.js — centralized structured console logger. */
(function attachLogger(root) {
  const Logger = {
    debugEnabled: false,
    setDebug(enabled) {
      this.debugEnabled = !!enabled;
    },
    _write(level, args) {
      const prefix = `[LX][${new Date().toISOString()}][${level}]`;
      try {
        const fn = level === 'ERROR' ? console.error
          : level === 'WARNING' ? console.warn
          : level === 'DEBUG' ? console.debug
          : console.info;
        fn(prefix, ...args);
      } catch (_) {
        // Console failures must never affect extension execution.
      }
    },
    info(...args) { this._write('INFO', args); },
    warning(...args) { this._write('WARNING', args); },
    error(...args) { this._write('ERROR', args); },
    debug(...args) { if (this.debugEnabled) this._write('DEBUG', args); },
    success(...args) { this._write('SUCCESS', args); }
  };

  root.LXLogger = Logger;
})(typeof window !== 'undefined' ? window : globalThis);
