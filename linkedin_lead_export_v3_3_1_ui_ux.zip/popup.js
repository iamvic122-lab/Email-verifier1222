/* popup.js — control panel for automatic people/company extraction. */
(function popup() {
  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const E = window.LXExport;

  const els = {
    settingsBtn: document.getElementById('settingsBtn'),
    settingsPanel: document.getElementById('settingsPanel'),
    statusPill: document.getElementById('statusPill'),
    modePill: document.getElementById('modePill'),
    totalLabel: document.getElementById('totalLabel'),
    statusHint: document.getElementById('statusHint'),
    totalCount: document.getElementById('totalCount'),
    pageCount: document.getElementById('pageCount'),
    duplicateCount: document.getElementById('duplicateCount'),
    errorCount: document.getElementById('errorCount'),
    speedValue: document.getElementById('speedValue'),
    etaValue: document.getElementById('etaValue'),
    progressBar: document.getElementById('progressBar'),
    startBtn: document.getElementById('startBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    resumeBtn: document.getElementById('resumeBtn'),
    stopBtn: document.getElementById('stopBtn'),
    extractBtn: document.getElementById('extractBtn'),
    resetRunBtn: document.getElementById('resetRunBtn'),
    clearBtn: document.getElementById('clearBtn'),
    tableTitle: document.getElementById('tableTitle'),
    tableRowCount: document.getElementById('tableRowCount'),
    leadTableHead: document.getElementById('leadTableHead'),
    leadTableBody: document.getElementById('leadTableBody'),
    leadTableEmpty: document.getElementById('leadTableEmpty'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    downloadCsvBtn: document.getElementById('downloadCsvBtn'),
    downloadJsonBtn: document.getElementById('downloadJsonBtn'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    urlIndicator: document.getElementById('urlIndicator'),
    paginationStatus: document.getElementById('paginationStatus'),
    setAutoScroll: document.getElementById('setAutoScroll'),
    setAutoNext: document.getElementById('setAutoNext'),
    setAutoSave: document.getElementById('setAutoSave'),
    setAutoResume: document.getElementById('setAutoResume'),
    setContinueClosed: document.getElementById('setContinueClosed'),
    setHumanMode: document.getElementById('setHumanMode'),
    setAutoDownload: document.getElementById('setAutoDownload'),
    setSafetyMode: document.getElementById('setSafetyMode'),
    setStopOnSecurity: document.getElementById('setStopOnSecurity'),
    setDebug: document.getElementById('setDebug'),
    setScrollMin: document.getElementById('setScrollMin'),
    setScrollMax: document.getElementById('setScrollMax'),
    setRetry: document.getElementById('setRetry'),
    setTimeout: document.getElementById('setTimeout'),
    setMaxPages: document.getElementById('setMaxPages'),
    setExpected: document.getElementById('setExpected'),
    setAuditPasses: document.getElementById('setAuditPasses'),
    setActionDelayMin: document.getElementById('setActionDelayMin'),
    setActionDelayMax: document.getElementById('setActionDelayMax'),
    setActionsPerMinute: document.getElementById('setActionsPerMinute')
  };

  let activeTabId = null;
  let refreshTimer = null;
  let currentMode = C.RECORD_TYPES.PERSON;

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs?.[0] || null;
  }

  async function sendToTab(message) {
    if (!activeTabId) return null;
    return new Promise((resolve) => {
      try {
        chrome.tabs.sendMessage(activeTabId, message, (response) => {
          try {
            if (chrome.runtime?.lastError) return resolve(null);
            resolve(response || null);
          } catch (_) { resolve(null); }
        });
      } catch (_) { resolve(null); }
    });
  }

  async function ensureContent(tab) {
    if (!tab?.id || !tab.url || !/linkedin\.com\/sales\//i.test(tab.url)) return null;
    let ping = await sendToTab({ type: 'LX_PING' });
    if (ping?.ok) return ping;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [
          'constants.js', 'logger.js', 'selectors.js', 'utils.js', 'safety.js',
          'wait.js', 'storage.js', 'extractor.js', 'scroll.js', 'pagination.js',
          'live_collector.js', 'export.js', 'controller.js', 'content.js'
        ]
      });
    } catch (_) { return null; }
    await new Promise((resolve) => setTimeout(resolve, 0));
    ping = await sendToTab({ type: 'LX_PING' });
    return ping?.ok ? ping : null;
  }

  function modeLabel(mode) { return mode === C.RECORD_TYPES.COMPANY ? 'COMPANY' : mode === C.RECORD_TYPES.PERSON ? 'PEOPLE' : '—'; }
  function normalizeRecordType(record) { return record?.recordType === C.RECORD_TYPES.COMPANY ? C.RECORD_TYPES.COMPANY : C.RECORD_TYPES.PERSON; }

  async function loadData() {
    const records = await S.getLeads();
    const filtered = records.filter((record) => normalizeRecordType(record) === currentMode);
    const visible = filtered.slice(-1000);
    els.totalCount.textContent = String(filtered.length);
    renderTable(visible, Math.max(0, filtered.length - visible.length), currentMode);
  }

  async function refreshTab() {
    const tab = await getActiveTab();
    activeTabId = tab?.id || null;
    const ping = await ensureContent(tab);
    if (!tab?.url) {
      els.urlIndicator.textContent = '—';
      currentMode = C.RECORD_TYPES.PERSON;
      setHint('Open a Sales Navigator people or company search.');
      return;
    }
    try { els.urlIndicator.textContent = new URL(tab.url).pathname.slice(0, 52); }
    catch (_) { els.urlIndicator.textContent = tab.url.slice(0, 52); }
    if (!ping) {
      setHint('Open a Sales Navigator person or company search page to use the engine.');
      return;
    }
    currentMode = ping.mode || C.RECORD_TYPES.PERSON;
    const meta = await S.getMeta();
    renderState(meta, ping);
    renderPagination(ping, meta);
    await loadData();
  }

  function setHint(text) { els.statusHint.textContent = text; }

  function renderState(meta, ping = null) {
    currentMode = ping?.mode || meta?.recordType || currentMode;
    const state = meta?.state || C.STATES.IDLE;
    els.statusPill.textContent = state;
    els.statusPill.className = `status-pill ${state.toLowerCase()}`;
    els.modePill.textContent = modeLabel(currentMode);
    const counts = meta?.totalRecordsByType || {};
    els.totalCount.textContent = String(Number(counts[currentMode] ?? 0));
    els.totalLabel.textContent = currentMode === C.RECORD_TYPES.COMPANY ? 'Companies' : 'People';
    els.pageCount.textContent = String(meta?.currentPage ?? (ping?.page ?? 1));
    els.duplicateCount.textContent = String(meta?.duplicates ?? 0);
    els.errorCount.textContent = String(meta?.errors ?? 0);
    els.progressBar.style.width = `${Math.max(0, Math.min(100, Number(meta?.scrollProgress || 0)))}%`;
    els.speedValue.textContent = formatSpeed(meta);
    els.etaValue.textContent = formatEta(meta);

    const active = [C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE];
    els.pauseBtn.disabled = !active.includes(state);
    els.resumeBtn.disabled = ![C.STATES.PAUSED, C.STATES.STOPPED, C.STATES.ERROR].includes(state);
    els.stopBtn.disabled = !active.includes(state) && state !== C.STATES.PAUSED;
    els.startBtn.disabled = active.includes(state);

    const coverage = meta?.pageCoverage;
    const coverageText = coverage ? `Page ${coverage.page}: ${coverage.uniqueCollected}/${coverage.expected} unique ${currentMode}` : '';
    const risk = ping?.safetyRisk?.risky ? `Safety guard: ${ping.safetyRisk.reason}` : null;
    setHint(risk || coverageText || meta?.lastError || meta?.currentStateReason || (ping?.onSearch ? `${ping.rowsVisible} visible ${currentMode} result rows.` : 'Open a Sales Navigator search.'));
  }

  function renderPagination(ping, meta) {
    const action = ping?.pagination?.action || 'none';
    const labels = {
      'next-page': 'Next page detected',
      'load-more': 'Load more detected',
      none: 'No pagination control detected'
    };
    els.paginationStatus.textContent = `${labels[action] || 'Automatic detection'}${ping?.pagination?.text ? ` — ${ping.pagination.text}` : ''}${meta?.expectedResultsPerPage ? ` · ${meta.expectedResultsPerPage}/page target` : ''}`;
  }

  function formatSpeed(meta) {
    const count = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!started || !count) return '0/min';
    const minutes = Math.max((Date.now() - started) / 60000, 1 / 60);
    return `${Math.round(count / minutes)}/min`;
  }

  function formatEta(meta) {
    const total = Number(meta?.expectedTotal || 0);
    const done = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!total || !started || done >= total) return '—';
    const perMin = done / Math.max((Date.now() - started) / 60000, 1 / 60);
    if (!perMin) return '—';
    const minutes = Math.max((total - done) / perMin, 0);
    return minutes < 60 ? `${Math.ceil(minutes)}m` : `${Math.floor(minutes / 60)}h ${Math.ceil(minutes % 60)}m`;
  }

  function renderTable(records, offset = 0, mode = C.RECORD_TYPES.PERSON) {
    const columns = U.getColumns(mode);
    const label = mode === C.RECORD_TYPES.COMPANY ? 'Companies' : 'People';
    els.tableTitle.firstChild.textContent = `${label} `;
    els.tableRowCount.textContent = `${records.length} visible row${records.length === 1 ? '' : 's'}`;
    els.leadTableHead.replaceChildren();
    const thIndex = document.createElement('th');
    thIndex.textContent = '#';
    els.leadTableHead.appendChild(thIndex);
    columns.forEach((column) => {
      const th = document.createElement('th');
      th.textContent = column.label;
      els.leadTableHead.appendChild(th);
    });

    els.leadTableBody.replaceChildren();
    if (!records.length) {
      const empty = els.leadTableEmpty.cloneNode(true);
      empty.hidden = false;
      empty.querySelector('td').colSpan = columns.length + 1;
      empty.querySelector('td').textContent = `No ${label.toLowerCase()} collected yet.`;
      els.leadTableBody.appendChild(empty);
      return;
    }

    const fragment = document.createDocumentFragment();
    records.forEach((record, index) => {
      const tr = document.createElement('tr');
      const indexCell = document.createElement('td');
      indexCell.textContent = String(offset + index + 1);
      tr.appendChild(indexCell);
      columns.forEach((column) => {
        const td = document.createElement('td');
        if (column.key === 'companyProfileImageUrl' && record[column.key]) {
          const image = document.createElement('img');
          image.className = 'company-logo-thumb';
          image.src = record[column.key];
          image.alt = record.companyName || 'Company logo';
          image.loading = 'lazy';
          image.decoding = 'async';
          const link = document.createElement('a');
          link.href = record[column.key];
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          link.appendChild(image);
          td.appendChild(link);
        } else if (column.key.endsWith('LinkedInUrl') && record[column.key]) {
          const link = document.createElement('a');
          link.href = record[column.key];
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          link.textContent = record[column.key];
          td.appendChild(link);
        } else {
          td.textContent = U.exportValue(record, column.key);
        }
        tr.appendChild(td);
      });
      fragment.appendChild(tr);
    });
    els.leadTableBody.appendChild(fragment);
  }

  function populateSettings(settings) {
    els.setAutoScroll.checked = !!settings.autoScroll;
    els.setAutoNext.checked = !!settings.autoNextPage;
    els.setAutoSave.checked = !!settings.autoSave;
    els.setAutoResume.checked = !!settings.autoResume;
    els.setContinueClosed.checked = !!settings.continueWhenPopupClosed;
    els.setHumanMode.checked = !!settings.humanMode;
    els.setAutoDownload.checked = !!settings.autoDownload;
    els.setSafetyMode.checked = !!settings.safetyMode;
    els.setStopOnSecurity.checked = !!settings.stopOnSecurityPrompt;
    els.setDebug.checked = !!settings.debugMode;
    els.setScrollMin.value = settings.scrollMinPx;
    els.setScrollMax.value = settings.scrollMaxPx;
    els.setRetry.value = settings.retryCount;
    els.setTimeout.value = settings.timeoutMs;
    els.setMaxPages.value = settings.maxPages;
    els.setExpected.value = settings.expectedResultsPerPage;
    els.setAuditPasses.value = settings.pageAuditPasses;
    els.setActionDelayMin.value = settings.actionDelayMinMs;
    els.setActionDelayMax.value = settings.actionDelayMaxMs;
    els.setActionsPerMinute.value = settings.maxActionsPerMinute;
  }

  async function runCommand(type) {
    let response = await sendToTab({ type });
    if (!response?.ok) {
      await refreshTab();
      response = await sendToTab({ type });
    }
    if (!response?.ok) {
      setHint(response?.reason || 'The page did not respond. Refresh it and try again.');
      return;
    }
    currentMode = response.state?.recordType || currentMode;
    renderState(response.state || await S.getMeta());
    await loadData();
  }

  async function init() {
    const settings = await S.getSettings();
    document.body.classList.toggle('light', settings.darkMode === false);
    document.body.classList.toggle('dark', settings.darkMode !== false);
    populateSettings(settings);
    await refreshTab();
    if (currentMode) await loadData();

    els.settingsBtn.addEventListener('click', () => { els.settingsPanel.hidden = !els.settingsPanel.hidden; });
    els.startBtn.addEventListener('click', () => runCommand('LX_START'));
    els.pauseBtn.addEventListener('click', () => runCommand('LX_PAUSE'));
    els.resumeBtn.addEventListener('click', () => runCommand('LX_RESUME'));
    els.stopBtn.addEventListener('click', () => runCommand('LX_STOP'));
    els.resetRunBtn.addEventListener('click', async () => {
      if (confirm('Reset the saved run state? Your collected records will remain.')) await runCommand('LX_RESET_RUN');
    });
    els.extractBtn.addEventListener('click', async () => {
      const response = await sendToTab({ type: 'LX_EXTRACT_PAGE' });
      if (!response?.ok) setHint(response?.reason || 'Current-page extraction failed.');
      else {
        currentMode = response.mode || currentMode;
        setHint(`Live extraction: ${response.foundOnPage} unique ${currentMode} rows detected.`);
        await loadData();
      }
    });
    els.clearBtn.addEventListener('click', async () => {
      if (!confirm('Clear all collected records? This cannot be undone.')) return;
      await S.clearLeads();
      await loadData();
    });
    els.copyAllBtn.addEventListener('click', async () => {
      const records = (await S.getLeads()).filter((record) => normalizeRecordType(record) === currentMode);
      if (records.length) { await E.copyAll(records, currentMode); setHint(`Copied ${records.length} ${currentMode} records.`); }
    });
    els.downloadCsvBtn.addEventListener('click', async () => {
      const records = (await S.getLeads()).filter((record) => normalizeRecordType(record) === currentMode);
      if (records.length) E.downloadCsv(records, currentMode);
    });
    els.downloadJsonBtn.addEventListener('click', async () => {
      const records = (await S.getLeads()).filter((record) => normalizeRecordType(record) === currentMode);
      if (records.length) E.downloadJson(records, { ...(await S.getMeta()), recordType: currentMode });
    });
    els.saveSettingsBtn.addEventListener('click', async () => {
      const patch = {
        autoScroll: els.setAutoScroll.checked,
        autoNextPage: els.setAutoNext.checked,
        autoSave: els.setAutoSave.checked,
        autoResume: els.setAutoResume.checked,
        continueWhenPopupClosed: els.setContinueClosed.checked,
        humanMode: els.setHumanMode.checked,
        autoDownload: els.setAutoDownload.checked,
        safetyMode: els.setSafetyMode.checked,
        stopOnSecurityPrompt: els.setStopOnSecurity.checked,
        debugMode: els.setDebug.checked,
        scrollMinPx: Number(els.setScrollMin.value),
        scrollMaxPx: Number(els.setScrollMax.value),
        retryCount: Number(els.setRetry.value),
        timeoutMs: Number(els.setTimeout.value),
        maxPages: Number(els.setMaxPages.value),
        expectedResultsPerPage: Number(els.setExpected.value),
        pageAuditPasses: Number(els.setAuditPasses.value),
        actionDelayMinMs: Number(els.setActionDelayMin.value),
        actionDelayMaxMs: Number(els.setActionDelayMax.value),
        maxActionsPerMinute: Number(els.setActionsPerMinute.value)
      };
      const saved = await S.saveSettings(patch);
      populateSettings(saved);
      await refreshTab();
      setHint('Settings saved. People and company search modes are automatic.');
    });

    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local') return;
      if (changes.lx_meta) renderState(changes.lx_meta.newValue || {});
      if (changes.lx_leads) await loadData();
      if (changes.lx_settings) populateSettings({ ...C.DEFAULTS, ...(changes.lx_settings.newValue || {}) });
    });
    chrome.tabs.onActivated.addListener(refreshTab);
    chrome.tabs.onUpdated.addListener((tabId, info) => {
      if (tabId === activeTabId && (info.status === 'complete' || info.url)) void refreshTab();
    });

    const scheduleRefresh = () => {
      refreshTimer = setTimeout(async () => {
        refreshTimer = null;
        try {
          const meta = await S.getMeta();
          const tab = await getActiveTab();
          const ping = tab?.id === activeTabId ? await sendToTab({ type: 'LX_PING' }) : null;
          renderState(meta, ping);
          if (ping?.ok) renderPagination(ping, meta);
        } catch (_) {}
        if (!document.hidden) scheduleRefresh();
      }, 1200);
    };
    scheduleRefresh();
  }

  window.addEventListener('unload', () => { if (refreshTimer) clearTimeout(refreshTimer); }, { once: true });
  document.addEventListener('DOMContentLoaded', init, { once: true });
})();
