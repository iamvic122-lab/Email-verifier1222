/* background.js — MV3 lifecycle only; long-running work stays in the page context. */
importScripts('constants.js');

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const C = globalThis.LXConstants;
    const current = await chrome.storage.local.get(C.STORAGE_KEYS.SETTINGS);
    if (!current[C.STORAGE_KEYS.SETTINGS]) {
      await chrome.storage.local.set({ [C.STORAGE_KEYS.SETTINGS]: { ...C.DEFAULTS } });
    }
  } catch (error) {
    console.error('[LX] Install initialization failed', error);
  }
});
