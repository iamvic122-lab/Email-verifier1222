/* pagination.js — automatic Next/load-more detection and verified navigation. */
(function attachPagination(root) {
  const SEL = root.LXSelectors;
  const Wait = root.LXWait;
  const Logger = root.LXLogger;
  const Extractor = root.LXExtractor;
  const U = root.LX;

  function isVisible(element) {
    if (!element || element.nodeType !== 1) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0;
  }

  function isDisabled(element) {
    if (!element) return true;
    return !!(
      element.disabled ||
      element.getAttribute('aria-disabled') === 'true' ||
      element.getAttribute('disabled') !== null ||
      element.classList.contains('disabled') ||
      element.classList.contains('artdeco-button--disabled') ||
      !isVisible(element)
    );
  }

  function controlText(element) {
    return U.cleanText(`${element?.textContent || ''} ${element?.getAttribute?.('aria-label') || ''} ${element?.title || ''}`);
  }

  function exactNextControl() {
    try {
      const spans = [...document.querySelectorAll(SEL.nextTextSpan || 'span.artdeco-button__text')];
      for (const span of spans) {
        if (U.cleanText(span.textContent) !== 'Next') continue;
        const control = span.closest(SEL.paginationControl || 'button, a');
        if (control && !isDisabled(control)) return { element: control, selector: 'span.artdeco-button__text=Next' };
      }
    } catch (error) {
      Logger.debug('Exact Next detector failed', error?.message || error);
    }
    return null;
  }

  function selectorMatch(selectors) {
    for (const selector of selectors || []) {
      try {
        const match = [...document.querySelectorAll(selector)].find((element) => !isDisabled(element));
        if (match) return { element: match, selector };
      } catch (error) {
        Logger.debug('Pagination selector failed', selector, error?.message || error);
      }
    }
    return null;
  }

  function textNextControl() {
    const elements = [...document.querySelectorAll('button, a')].filter(isVisible);
    const match = elements.find((element) => /^next(?: page)?$/i.test(U.cleanText(element.textContent || '')) || /^next(?: page)?$/i.test(U.cleanText(element.getAttribute('aria-label') || '')));
    return match && !isDisabled(match) ? { element: match, selector: 'text:next' } : null;
  }

  function findNext() {
    return exactNextControl() || selectorMatch([...(SEL.nextButton || []), ...(SEL.nextLink || [])]) || textNextControl();
  }

  function findLoadMoreButton() {
    const preferred = selectorMatch((SEL.loadMoreButton || []).filter((selector) => selector !== 'button'));
    if (preferred) return preferred;
    const buttons = [...document.querySelectorAll('button')].filter(isVisible);
    const match = buttons.find((button) => /\bload\s+more\b|show\s+more\s+results|more\s+results/i.test(controlText(button)) && !isDisabled(button));
    return match ? { element: match, selector: 'text:load-more' } : null;
  }

  function findDisabledOrVisibleNext() {
    try {
      const spans = [...document.querySelectorAll(SEL.nextTextSpan || 'span.artdeco-button__text')];
      for (const span of spans) {
        if (U.cleanText(span.textContent) !== 'Next') continue;
        const control = span.closest(SEL.paginationControl || 'button, a');
        if (control && isVisible(control)) return { element: control, selector: 'span.artdeco-button__text=Next', disabled: isDisabled(control) };
      }
    } catch (_) {}
    return null;
  }

  function getPageDescriptor() {
    return {
      url: window.location.href,
      pageKey: U.pageKey(window.location.href),
      searchKey: U.searchKey(window.location.href),
      signature: Extractor.signature(),
      rowCount: Extractor.findResultRows().length
    };
  }

  function pageChanged(previous) {
    if (!previous) return true;
    const current = getPageDescriptor();
    if (current.pageKey !== previous.pageKey) return true;
    if (current.url !== previous.url) return true;
    if (previous.signature && current.signature && current.signature !== previous.signature) return true;
    const first = Extractor.findResultRows()[0];
    const firstKey = first ? Extractor.rowSignature(first) : '';
    return !!(previous.firstKey && firstKey && firstKey !== previous.firstKey);
  }

  function detectAction() {
    const next = findNext();
    if (next) return { type: 'next-page', selector: next.selector, text: controlText(next.element), target: next.element };
    const loadMore = findLoadMoreButton();
    if (loadMore) return { type: 'load-more', selector: loadMore.selector, text: controlText(loadMore.element), target: loadMore.element };
    return { type: 'none', selector: null, text: '', target: null };
  }

  async function clickNextWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = 'next-not-found';
    const retries = Math.max(1, Number(settings.pageChangeRetries) || 3);
    const before = previous || getPageDescriptor();
    if (!before.firstKey) {
      const first = Extractor.findResultRows()[0];
      before.firstKey = first ? Extractor.rowSignature(first) : '';
    }

    for (let attempt = 1; attempt <= retries; attempt += 1) {
      if (shouldCancel()) return { ok: false, reason: 'cancelled', attempt };
      if (pageChanged(before)) return { ok: true, attempt, descriptor: getPageDescriptor(), waitedMs: 0, selector: 'already-changed' };
      const target = findNext();
      if (!target) {
        lastFailure = 'next-not-found';
        break;
      }

      try {
        const budget = safety ? await safety() : null;
        if (shouldCancel()) return { ok: false, reason: 'cancelled', attempt };
        target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.element.click();
        Logger.info('Next page clicked', target.selector);

        const result = await Wait.waitForCondition(() => pageChanged(before), {
          root: document.documentElement || document,
          timeoutMs: Number(settings.timeoutMs) || 30000,
          observeAttributes: true,
          shouldCancel
        });
        return { ok: true, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget, attempt };
      } catch (error) {
        lastFailure = error.message || 'page-change-timeout';
        Logger.warning('Next page attempt failed', attempt, lastFailure);
        if (attempt < retries) {
          try {
            await Wait.waitForCondition(() => !!findNext() || pageChanged(before), {
              root: document.documentElement || document,
              timeoutMs: Math.min(Number(settings.timeoutMs) || 30000, 8000),
              shouldCancel
            });
          } catch (_) {}
        }
      }
    }
    return { ok: false, reason: lastFailure, attempt: retries };
  }

  async function clickLoadMoreWithRetry(previous, settings, safety, shouldCancel = () => false) {
    let lastFailure = 'load-more-not-found';
    const retries = Math.max(1, Number(settings.pageChangeRetries) || 3);
    const before = previous || getPageDescriptor();
    for (let attempt = 1; attempt <= retries; attempt += 1) {
      if (shouldCancel()) return { ok: false, reason: 'cancelled', attempt };
      const target = findLoadMoreButton();
      if (!target) return { ok: true, finished: true, reason: 'load-more-not-found', attempt };
      const beforeCount = Number(before.rowCount || Extractor.findResultRows().length);
      const beforeSignature = before.signature || Extractor.signature();
      try {
        const budget = safety ? await safety() : null;
        target.element.scrollIntoView({ block: 'center', inline: 'nearest' });
        target.element.click();
        Logger.info('Load-more clicked', target.selector);
        const result = await Wait.waitForCondition(() => {
          const current = getPageDescriptor();
          return current.rowCount > beforeCount || (beforeSignature && current.signature && current.signature !== beforeSignature);
        }, {
          root: document.documentElement || document,
          timeoutMs: Number(settings.timeoutMs) || 30000,
          shouldCancel
        });
        return { ok: true, finished: false, descriptor: getPageDescriptor(), waitedMs: result.waitedMs, selector: target.selector, budget, attempt };
      } catch (error) {
        lastFailure = error.message || 'load-more-timeout';
        Logger.warning('Load-more attempt failed', attempt, lastFailure);
      }
    }
    return { ok: false, reason: lastFailure, attempt: retries };
  }

  function verifyTarget() {
    const action = detectAction();
    return {
      ok: action.type !== 'none',
      action: action.type,
      selector: action.selector,
      text: action.text,
      disabled: !!action.target && isDisabled(action.target)
    };
  }

  root.LXPagination = {
    findNext: () => findNext()?.element || null,
    hasNext: () => !!findNext(),
    findLoadMoreButton: () => findLoadMoreButton()?.element || null,
    hasLoadMore: () => !!findLoadMoreButton(),
    getPageDescriptor,
    detectAction,
    clickNextWithRetry,
    clickLoadMoreWithRetry,
    verifyTarget,
    findDisabledOrVisibleNext
  };
})(typeof window !== 'undefined' ? window : globalThis);
