# Sales Navigator Extractor v3.3.0

Production-oriented Manifest V3 extension for Sales Navigator result extraction.

## Supported views

- People / Lead search: `/sales/search/people`
- Company / Account search: `/sales/search/company`, `/sales/search/companies`, `/sales/search/account`, `/sales/search/accounts`
- Automatic DOM fallback detection when the URL is ambiguous.

## Company fields

- Company Name
- Company LinkedIn URL
- Industry
- Employee Count
- Revenue
- About
- Company Profile Image
- Company ID
- Data Quality

Revenue is optional; the UI and exports display `N/A` when it is absent.

## Extraction behavior

Rows are discovered and saved incrementally as they enter the DOM. Person and company records use separate record types and duplicate keys so the same company is not repeatedly stored.

Pagination and lazy-loading use the existing state-machine, coverage audit, retry and safety layers. The extension stops on visible security/challenge signals and does not attempt to bypass them.
