/* export.js — local CSV / JSON / clipboard export for the active record type. */
(function attachExport(root) {
  const U = root.LX;

  function downloadFile(content, fileName, contentType) {
    const blob = new Blob([content], { type: `${contentType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    anchor.rel = 'noopener';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function timestamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }
  function normalizeMode(mode, leads) {
    if (mode === 'company' || mode === 'person') return mode;
    return Array.isArray(leads) && leads.some((record) => record?.recordType === 'company') ? 'company' : 'person';
  }

  function downloadCsv(leads, mode = null) {
    const resolvedMode = normalizeMode(mode, leads);
    const columns = U.getColumns(resolvedMode);
    const header = columns.map((column) => U.csvEscape(column.label)).join(',');
    const rows = (Array.isArray(leads) ? leads : []).map((lead) => columns.map((column) => U.csvEscape(U.exportValue(lead, column.key))).join(','));
    downloadFile([header, ...rows].join('\n'), `${resolvedMode}_export_${timestamp()}.csv`, 'text/csv');
  }

  function downloadJson(leads, meta) {
    const data = {
      meta: { ...(meta || {}), exportedAt: new Date().toISOString(), count: Array.isArray(leads) ? leads.length : 0 },
      records: Array.isArray(leads) ? leads : []
    };
    data.leads = data.records;
    downloadFile(JSON.stringify(data, null, 2), `${meta?.recordType || 'records'}_export_${timestamp()}.json`, 'application/json');
  }

  async function copyAll(leads, mode = null) {
    const resolvedMode = normalizeMode(mode, leads);
    const columns = U.getColumns(resolvedMode);
    const header = columns.map((column) => U.tsvEscape(column.label)).join('\t');
    const rows = (Array.isArray(leads) ? leads : []).map((lead) => columns.map((column) => U.tsvEscape(U.exportValue(lead, column.key))).join('\t'));
    await navigator.clipboard.writeText([header, ...rows].join('\n'));
  }

  root.LXExport = { downloadCsv, downloadJson, copyAll };
})(typeof window !== 'undefined' ? window : globalThis);
