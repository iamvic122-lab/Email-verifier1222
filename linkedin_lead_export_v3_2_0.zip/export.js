/* export.js — local CSV / JSON / clipboard export. */
(function attachExport(root) {
  const U = root.LX;
  const COLUMNS = U.COLUMNS;

  function downloadFile(content, fileName, contentType) {
    const blob = new Blob([content], { type: `${contentType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    anchor.rel = 'noopener';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function timestamp() {
    return new Date().toISOString().replace(/[:.]/g, '-');
  }

  function downloadCsv(leads) {
    const header = COLUMNS.map((column) => U.csvEscape(column.label)).join(',');
    const rows = (Array.isArray(leads) ? leads : []).map((lead) => COLUMNS.map((column) => U.csvEscape(U.exportValue(lead, column.key))).join(','));
    downloadFile([header, ...rows].join('\n'), `leads_export_${timestamp()}.csv`, 'text/csv');
  }

  function downloadJson(leads, meta) {
    const data = {
      meta: { ...(meta || {}), exportedAt: new Date().toISOString(), count: Array.isArray(leads) ? leads.length : 0 },
      leads: Array.isArray(leads) ? leads : []
    };
    downloadFile(JSON.stringify(data, null, 2), `leads_export_${timestamp()}.json`, 'application/json');
  }

  async function copyAll(leads) {
    const header = COLUMNS.map((column) => U.tsvEscape(column.label)).join('\t');
    const rows = (Array.isArray(leads) ? leads : []).map((lead) => COLUMNS.map((column) => U.tsvEscape(U.exportValue(lead, column.key))).join('\t'));
    await navigator.clipboard.writeText([header, ...rows].join('\n'));
  }

  root.LXExport = { downloadCsv, downloadJson, copyAll };
})(typeof window !== 'undefined' ? window : globalThis);
