/* controller.js — user-assisted state-machine orchestrator. Never auto-clicks or auto-scrolls LinkedIn controls. */
(function attachController(root) {
  const C = root.LXConstants;
  const S = root.LXStorage;
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;
  const Extractor = root.LXExtractor;
  const Scroll = root.LXScroll;
  const Pagination = root.LXPagination;
  const Safety = root.LXSafety;

  const RUNNING_STATES = new Set([
    C.STATES.STARTING,
    C.STATES.WAITING_READY,
    C.STATES.SCROLLING,
    C.STATES.COLLECTING,
    C.STATES.SAVING,
    C.STATES.WAITING_PAGE
  ]);

  class Controller {
    constructor() {
      this.settings = { ...C.DEFAULTS };
      this.state = C.STATES.IDLE;
      this.meta = {};
      this.runPromise = null;
      this.pauseRequested = false;
      this.stopRequested = false;
      this.autoSaveTimer = null;
      this.operationToken = 0;
    }

    async init() {
      this.settings = Safety.validateSettings(await S.getSettings());
      Logger.setDebug(this.settings.debugMode);
      this.meta = await S.getMeta();
      this.state = this.meta.state || C.STATES.IDLE;
      if (!this.meta.state) await this._persist({ state: C.STATES.IDLE });
      return this.getSnapshot();
    }

    getSnapshot() {
      return U.clone({ state: this.state, settings: this.settings, ...this.meta });
    }

    async refreshSettings() {
      const raw = await S.getSettings();
      this.settings = Safety.validateSettings(raw);
      Logger.setDebug(this.settings.debugMode);
      if (JSON.stringify(raw) !== JSON.stringify(this.settings)) {
        await S.saveSettings(this.settings);
      }
      return this.settings;
    }

    _baseMeta() {
      const now = new Date().toISOString();
      return {
        state: this.state,
        currentUrl: window.location.href,
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        lastActivityAt: now,
        updatedAt: now
      };
    }

    async _persist(patch = {}) {
      this.meta = { ...this.meta, ...this._baseMeta(), ...patch };
      this.meta = await S.setMeta(this.meta);
      return this.meta;
    }

    async _transition(nextState, patch = {}) {
      const valid = Object.values(C.STATES).includes(nextState) ? nextState : C.STATES.ERROR;
      this.state = valid;
      Logger.info('State →', valid, patch.reason || patch.currentStateReason || '');
      await this._persist({ currentStateReason: patch.reason || patch.currentStateReason || '', ...patch });
      return valid;
    }

    _getPageNumber() {
      try {
        const parsed = new URL(window.location.href);
        const page = Number(parsed.searchParams.get('page'));
        return Number.isFinite(page) && page > 0 ? page : Number(this.meta.currentPage) || 1;
      } catch (_) {
        return Number(this.meta.currentPage) || 1;
      }
    }

    _shouldPause() { return this.pauseRequested || this.state === C.STATES.PAUSED; }
    _shouldStop() { return this.stopRequested || this.state === C.STATES.STOPPED; }

    async _checkSafety(context) {
      const result = Safety.detect();
      await this._persist({
        lastSafetyCheckAt: result.checkedAt,
        safetyContext: context,
        lastSafetyResult: result
      });
      if (result.risky) {
        Logger.error('Safety guard stopped activity', result.code, result.reason);
        this.stopRequested = true;
        await this._transition(C.STATES.STOPPED, {
          currentStateReason: 'Safety guard stopped the run. Resolve the LinkedIn security/session prompt manually before continuing.',
          lastError: result.reason,
          safetyEvent: result,
          lastSafetyEventAt: result.checkedAt,
          stoppedAt: result.checkedAt,
          safetyCooldownUntil: new Date(Date.now() + this.settings.safetyCooldownMs).toISOString(),
          requiresManualRecovery: true
        });
        this._stopAutoSave();
      }
      return result;
    }

    async _beforeUserAssistedAction(context) {
      if (this._shouldStop() || this._shouldPause()) return false;
      const safety = await this._checkSafety(context);
      if (safety.risky) return false;
      const cooldownUntil = Date.parse(this.meta?.safetyCooldownUntil || '');
      if (cooldownUntil > Date.now()) {
        await this._transition(C.STATES.STOPPED, {
          currentStateReason: `Safety cooldown active until ${new Date(cooldownUntil).toLocaleTimeString()}.`,
          requiresManualRecovery: true
        });
        this.stopRequested = true;
        return false;
      }
      const budget = await Safety.waitForActionBudget(this.meta, this.settings, Wait);
      await this._persist(budget);
      return !this._shouldStop() && !this._shouldPause();
    }

    _startAutoSave() {
      this._stopAutoSave();
      if (!this.settings.autoSave) return;
      const tick = () => {
        this.autoSaveTimer = window.setTimeout(async () => {
          this.autoSaveTimer = null;
          try {
            if (!this._shouldStop() && ![C.STATES.FINISHED, C.STATES.ERROR].includes(this.state)) {
              await this._persist({ lastAutosaveAt: new Date().toISOString() });
            }
          } catch (error) {
            Logger.warning('Autosave failed', error?.message || error);
          }
          if (!this._shouldStop() && ![C.STATES.FINISHED, C.STATES.ERROR].includes(this.state)) tick();
        }, this.settings.autoSaveMs);
      };
      tick();
    }

    _stopAutoSave() {
      if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }

    async start() {
      if (this.runPromise) return this.getSnapshot();
      await this.refreshSettings();
      const guard = await this._validateSearchContext();
      if (!guard.ok) {
        await this._transition(C.STATES.ERROR, { lastError: guard.reason, errors: Number(this.meta.errors || 0) + 1 });
        return this.getSnapshot();
      }

      const existing = await S.getMeta();
      const sameSearch = existing.searchKey && existing.searchKey === U.searchKey(window.location.href);
      const canResume = existing.runId && sameSearch && [
        C.STATES.PAUSED, C.STATES.WAITING_USER, C.STATES.WAITING_PAGE,
        C.STATES.STARTING, C.STATES.WAITING_READY, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.ERROR, C.STATES.STOPPED
      ].includes(existing.state);

      if (canResume && existing.state !== C.STATES.ERROR && existing.state !== C.STATES.STOPPED) {
        this.meta = existing;
        this.state = existing.state === C.STATES.PAUSED ? C.STATES.PAUSED : C.STATES.STARTING;
        Logger.info('Continuing saved run', existing.runId, 'page', existing.currentPage);
      } else {
        this.meta = {
          runId: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
          searchKey: U.searchKey(window.location.href),
          startedAt: new Date().toISOString(),
          pagesProcessed: 0,
          currentPage: this._getPageNumber(),
          collectedThisRun: 0,
          duplicates: 0,
          errors: 0,
          visitedPages: [],
          lastError: '',
          currentStateReason: 'Run started.',
          paginationMode: this.settings.paginationMode,
          paginationTargetSelector: this.settings.paginationTargetSelector,
          waitingAction: C.WAITING_ACTIONS.NONE,
          waitingPageKey: '',
          waitingSignature: '',
          waitingRowCount: 0,
          requiresManualRecovery: false,
          debug: {}
        };
        this.state = C.STATES.STARTING;
      }

      this.pauseRequested = false;
      this.stopRequested = false;
      this.operationToken += 1;
      await this._persist({
        paginationMode: this.settings.paginationMode,
        paginationTargetSelector: this.settings.paginationTargetSelector,
        safetyMode: true,
        autoNextPage: false,
        autoScroll: false,
        autoResume: false
      });
      this._startAutoSave();

      this.runPromise = this._processCurrentPage(this.operationToken).finally(() => { this.runPromise = null; });
      return this.getSnapshot();
    }

    async pause() {
      this.pauseRequested = true;
      this.operationToken += 1;
      this.state = C.STATES.PAUSED;
      await this._persist({ state: C.STATES.PAUSED, currentStateReason: 'Paused by user.' });
      return this.getSnapshot();
    }

    async resume() {
      await this.refreshSettings();
      const guard = await this._validateSearchContext();
      if (!guard.ok) {
        await this._transition(C.STATES.ERROR, { lastError: guard.reason, errors: Number(this.meta.errors || 0) + 1 });
        return this.getSnapshot();
      }
      const safety = await this._checkSafety('resume');
      if (safety.risky) return this.getSnapshot();

      if (this.runPromise) return this.getSnapshot();
      this.pauseRequested = false;
      this.stopRequested = false;
      this.operationToken += 1;
      const token = this.operationToken;
      await this._persist({
        state: C.STATES.STARTING,
        currentStateReason: 'Resumed by user.',
        requiresManualRecovery: false
      });
      this._startAutoSave();
      this.runPromise = this._resumeFlow(token).finally(() => { this.runPromise = null; });
      return this.getSnapshot();
    }

    async stop() {
      this.stopRequested = true;
      this.pauseRequested = false;
      this.operationToken += 1;
      this._stopAutoSave();
      await this._transition(C.STATES.STOPPED, {
        currentStateReason: 'Stopped by user.',
        stoppedAt: new Date().toISOString(),
        waitingAction: C.WAITING_ACTIONS.NONE
      });
      return this.getSnapshot();
    }

    async resetRun() {
      this.pauseRequested = false;
      this.stopRequested = false;
      this.operationToken += 1;
      this._stopAutoSave();
      this.state = C.STATES.IDLE;
      this.meta = {};
      await S.setMeta({
        state: C.STATES.IDLE,
        currentStateReason: 'Run reset. Collected leads were preserved.',
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        pagesProcessed: 0,
        collectedThisRun: 0,
        duplicates: 0,
        errors: 0,
        visitedPages: [],
        lastError: '',
        waitingAction: C.WAITING_ACTIONS.NONE,
        requiresManualRecovery: false,
        debug: {}
      });
      this.meta = await S.getMeta();
      return this.getSnapshot();
    }

    async extractCurrentPage() {
      if (this.runPromise) return { ok: false, reason: 'An extraction operation is already running. Wait for it to finish.' };
      await this.refreshSettings();
      const safety = await this._checkSafety('extract-current-page');
      if (safety.risky) return { ok: false, reason: safety.reason };
      return this._processCurrentPage(++this.operationToken, { standalone: true });
    }

    async assistNextPage() {
      await this.refreshSettings();
      const guard = await this._validateSearchContext();
      if (!guard.ok) return { ok: false, reason: guard.reason };
      const safety = await this._checkSafety('next-page-assist');
      if (safety.risky) return { ok: false, reason: safety.reason };
      if (!(await this._beforeUserAssistedAction('next-page-assist'))) return { ok: false, reason: 'Safety guard blocked the action.' };

      const target = Pagination.verifyTarget(C.PAGINATION_MODES.CLICK_LINK, this.settings.paginationTargetSelector);
      if (!target.ok || target.disabled) return { ok: false, reason: 'Next page control was not found or is disabled.' };
      const focused = Pagination.focusTarget(C.PAGINATION_MODES.CLICK_LINK, this.settings.paginationTargetSelector);
      const descriptor = Pagination.getPageDescriptor();
      await this._transition(C.STATES.WAITING_USER, {
        currentStateReason: 'Next page is ready. Click LinkedIn’s Next control manually, then press Resume.',
        waitingAction: C.WAITING_ACTIONS.NEXT_PAGE,
        waitingPageKey: descriptor.pageKey,
        waitingSignature: descriptor.signature,
        waitingRowCount: descriptor.rowCount,
        waitingTarget: focused,
        requiresUserAction: true
      });
      return { ok: true, target: focused, state: this.getSnapshot() };
    }

    async assistLoadMore() {
      await this.refreshSettings();
      const safety = await this._checkSafety('load-more-assist');
      if (safety.risky) return { ok: false, reason: safety.reason };
      if (!(await this._beforeUserAssistedAction('load-more-assist'))) return { ok: false, reason: 'Safety guard blocked the action.' };
      const target = Pagination.verifyTarget(C.PAGINATION_MODES.CLICK_BUTTON, this.settings.paginationTargetSelector);
      if (!target.ok || target.disabled) return { ok: false, reason: 'Load-more control was not found or is disabled.' };
      const focused = Pagination.focusTarget(C.PAGINATION_MODES.CLICK_BUTTON, this.settings.paginationTargetSelector);
      const descriptor = Pagination.getPageDescriptor();
      await this._transition(C.STATES.WAITING_USER, {
        currentStateReason: 'Load more is ready. Click LinkedIn’s Load more control manually, then press Resume.',
        waitingAction: C.WAITING_ACTIONS.LOAD_MORE,
        waitingPageKey: descriptor.pageKey,
        waitingSignature: descriptor.signature,
        waitingRowCount: descriptor.rowCount,
        waitingTarget: focused,
        requiresUserAction: true
      });
      return { ok: true, target: focused, state: this.getSnapshot() };
    }

    async assistScroll() {
      await this.refreshSettings();
      const safety = await this._checkSafety('scroll-assist');
      if (safety.risky) return { ok: false, reason: safety.reason };
      const rows = Extractor.findResultRows();
      const container = Scroll.findContainer(rows);
      try { container.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' }); } catch (_) {}
      const descriptor = Pagination.getPageDescriptor();
      await this._transition(C.STATES.WAITING_USER, {
        currentStateReason: 'Scroll the LinkedIn result list manually to load more rows, then press Resume.',
        waitingAction: C.WAITING_ACTIONS.MANUAL_SCROLL,
        waitingPageKey: descriptor.pageKey,
        waitingSignature: descriptor.signature,
        waitingRowCount: descriptor.rowCount,
        requiresUserAction: true
      });
      return { ok: true, state: this.getSnapshot() };
    }

    async waitForReady() {
      await this._checkSafety('wait-for-ready');
      if (this._shouldStop()) return { ready: false, reason: 'safety-stop' };
      const stableMs = this.settings.stableMs;
      const timeoutMs = this.settings.timeoutMs;
      const body = document.body || document.documentElement;
      const startedAt = Date.now();
      let lastSignature = '';
      let stableSince = 0;
      let currentRows = 0;
      let lastSafetyCheck = 0;
      let mutations = 0;

      return new Promise((resolve) => {
        let observer = null;
        let stableTimer = null;
        let timeoutTimer = null;
        let finished = false;

        const cleanup = () => {
          observer?.disconnect();
          if (stableTimer) clearTimeout(stableTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
        };
        const finish = (result) => {
          if (finished) return;
          finished = true;
          cleanup();
          resolve({ ...result, waitedMs: Date.now() - startedAt, rowsVisible: currentRows, mutations });
        };
        const evaluate = () => {
          if (finished) return;
          if (this._shouldStop()) return finish({ ready: false, reason: 'cancelled' });
          currentRows = Extractor.findResultRows().length;

          if (Date.now() - lastSafetyCheck > 750) {
            lastSafetyCheck = Date.now();
            const safety = Safety.detect();
            if (safety.risky) {
              void this._checkSafety('wait-for-ready-live');
              return finish({ ready: false, reason: 'safety-stop', safety });
            }
          }

          const blocked = Extractor.hasBlockingLoader();
          const signature = Extractor.signature();
          if (blocked || !signature || signature !== lastSignature) {
            lastSignature = signature;
            stableSince = blocked || !signature ? 0 : Date.now();
            if (stableTimer) clearTimeout(stableTimer);
          }

          if (currentRows > 0 && signature && !blocked) {
            if (!stableSince) stableSince = Date.now();
            const remaining = stableMs - (Date.now() - stableSince);
            if (remaining <= 0) return finish({ ready: true, reason: 'stable' });
            if (stableTimer) clearTimeout(stableTimer);
            stableTimer = setTimeout(evaluate, remaining);
          }
        };

        try {
          observer = new MutationObserver((changes) => {
            mutations += changes.length;
            evaluate();
          });
          observer.observe(body, { subtree: true, childList: true, attributes: true, characterData: true });
        } catch (error) {
          Logger.warning('Readiness observer unavailable', error?.message || error);
        }

        evaluate();
        timeoutTimer = setTimeout(() => finish({
          ready: false,
          reason: currentRows ? 'timeout-unstable' : 'timeout-no-results'
        }), timeoutMs);
      });
    }


    async _waitForReadyWithRetry() {
      const attempts = Math.max(1, Math.min(6, Number(this.settings.retryCount) || 3));
      let last = { ready: false, reason: 'not-attempted' };
      for (let attempt = 1; attempt <= attempts; attempt += 1) {
        if (this._shouldStop()) return { ...last, reason: 'cancelled', attempts: attempt };
        await this._persist({ retryCount: attempt, debug: { ...(this.meta.debug || {}), currentSelector: 'waitForReady', retryCount: attempt } });
        last = await this.waitForReady();
        last.attempt = attempt;
        if (last.ready || last.reason === 'safety-stop' || last.reason === 'cancelled') return last;
        if (attempt < attempts) {
          Logger.warning('Readiness retry', attempt, last.reason);
          await Wait.wait(Math.min(1500, 300 * attempt));
        }
      }
      return last;
    }

    async _processCurrentPage(token, { standalone = false } = {}) {
      if (this.runPromise && token !== this.operationToken && !standalone) return { ok: false, reason: 'operation-superseded' };
      if (!standalone && this._shouldStop()) return { ok: false, reason: 'stopped' };

      const guard = await this._validateSearchContext();
      if (!guard.ok) throw new Error(guard.reason);
      const safety = await this._checkSafety('page-start');
      if (safety.risky) return { ok: false, reason: safety.reason };

      await this._transition(C.STATES.WAITING_READY, {
        waitingAction: C.WAITING_ACTIONS.NONE,
        currentPage: this._getPageNumber(),
        currentStateReason: 'Waiting for the visible result list to stabilize.'
      });

      const readiness = await this._waitForReadyWithRetry();
      await this._persist({ lastReadiness: readiness });
      if (!readiness.ready) {
        if (readiness.reason === 'safety-stop') return { ok: false, reason: readiness.safety?.reason || 'Safety signal detected.' };
        throw new Error(readiness.reason === 'timeout-no-results'
          ? 'No visible lead rows became available before timeout.'
          : `Visible result rows did not stabilize before timeout (${this.settings.timeoutMs}ms).`);
      }

      await this._transition(C.STATES.COLLECTING, {
        currentPage: this._getPageNumber(),
        currentSelector: Extractor._lastResultSelector || 'resultRow/personLink'
      });

      const descriptor = Pagination.getPageDescriptor();
      const pageId = `${descriptor.searchKey}|${descriptor.pageKey}|${descriptor.signature}`;
      const visited = new Set(Array.isArray(this.meta.visitedPages) ? this.meta.visitedPages : []);
      const alreadyVisited = visited.has(pageId);
      if (!alreadyVisited) visited.add(pageId);
      await this._persist({
        visitedPages: Array.from(visited).slice(-this.settings.maxPages),
        currentSignature: descriptor.signature,
        currentRowCount: descriptor.rowCount
      });

      const result = await this.collectAndSavePage();
      if (!result.ok && !standalone) return result;

      if (standalone) {
        await this._transition(C.STATES.FINISHED, { currentStateReason: 'Current page extraction completed.' });
        this._stopAutoSave();
        return result;
      }

      const pagesProcessed = Number(this.meta.pagesProcessed || 0);
      if (pagesProcessed >= this.settings.maxPages) {
        await this._transition(C.STATES.FINISHED, { currentStateReason: 'Configured maximum page limit reached.' });
        this._stopAutoSave();
        return result;
      }

      return this._prepareNextAction();
    }

    async _resumeFlow(token) {
      const action = this.meta.waitingAction || C.WAITING_ACTIONS.NONE;
      const previousPageKey = this.meta.waitingPageKey || '';
      const previousSignature = this.meta.waitingSignature || '';
      const previousRows = Number(this.meta.waitingRowCount || 0);
      const current = Pagination.getPageDescriptor();

      if (action === C.WAITING_ACTIONS.NEXT_PAGE) {
        if (current.searchKey !== this.meta.searchKey) throw new Error('Search context changed. Run stopped to prevent mixing datasets.');
        if (current.pageKey === previousPageKey && current.signature === previousSignature && current.rowCount <= previousRows) {
          await this._transition(C.STATES.WAITING_USER, {
            currentStateReason: 'No page change detected. Click LinkedIn’s Next control manually, then press Resume.',
            requiresUserAction: true
          });
          return this.getSnapshot();
        }
      } else if (action === C.WAITING_ACTIONS.LOAD_MORE || action === C.WAITING_ACTIONS.MANUAL_SCROLL) {
        const changed = current.pageKey !== previousPageKey || current.signature !== previousSignature || current.rowCount > previousRows;
        if (!changed) {
          await this._transition(C.STATES.WAITING_USER, {
            currentStateReason: 'No new results detected. Perform the selected LinkedIn action manually, then press Resume.',
            requiresUserAction: true
          });
          return this.getSnapshot();
        }
      }

      await this._persist({ waitingAction: C.WAITING_ACTIONS.NONE, requiresUserAction: false });
      return this._processCurrentPage(token);
    }

    async _prepareNextAction() {
      const mode = this.settings.paginationMode;
      if (mode === C.PAGINATION_MODES.NONE) {
        await this._transition(C.STATES.FINISHED, { currentStateReason: 'Current page completed; pagination is disabled.' });
        this._stopAutoSave();
        return this.getSnapshot();
      }

      if (mode === C.PAGINATION_MODES.CLICK_LINK) {
        const target = Pagination.verifyTarget(C.PAGINATION_MODES.CLICK_LINK, this.settings.paginationTargetSelector);
        if (!target.ok || target.disabled) {
          await this._transition(C.STATES.FINISHED, { currentStateReason: 'No usable Next page control is available.' });
          this._stopAutoSave();
          return this.getSnapshot();
        }
        const focused = Pagination.focusTarget(C.PAGINATION_MODES.CLICK_LINK, this.settings.paginationTargetSelector);
        const descriptor = Pagination.getPageDescriptor();
        await this._transition(C.STATES.WAITING_USER, {
          currentStateReason: 'Click LinkedIn’s Next control manually, then press Resume.',
          waitingAction: C.WAITING_ACTIONS.NEXT_PAGE,
          waitingPageKey: descriptor.pageKey,
          waitingSignature: descriptor.signature,
          waitingRowCount: descriptor.rowCount,
          waitingTarget: focused,
          requiresUserAction: true
        });
        return this.getSnapshot();
      }

      if (mode === C.PAGINATION_MODES.CLICK_BUTTON) {
        const target = Pagination.verifyTarget(C.PAGINATION_MODES.CLICK_BUTTON, this.settings.paginationTargetSelector);
        if (!target.ok || target.disabled) {
          await this._transition(C.STATES.FINISHED, { currentStateReason: 'No usable Load more control is available.' });
          this._stopAutoSave();
          return this.getSnapshot();
        }
        const focused = Pagination.focusTarget(C.PAGINATION_MODES.CLICK_BUTTON, this.settings.paginationTargetSelector);
        const descriptor = Pagination.getPageDescriptor();
        await this._transition(C.STATES.WAITING_USER, {
          currentStateReason: 'Click LinkedIn’s Load more control manually, then press Resume.',
          waitingAction: C.WAITING_ACTIONS.LOAD_MORE,
          waitingPageKey: descriptor.pageKey,
          waitingSignature: descriptor.signature,
          waitingRowCount: descriptor.rowCount,
          waitingTarget: focused,
          requiresUserAction: true
        });
        return this.getSnapshot();
      }

      if (mode === C.PAGINATION_MODES.SCROLL) {
        const rows = Extractor.findResultRows();
        const container = Scroll.findContainer(rows);
        try { container.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' }); } catch (_) {}
        const descriptor = Pagination.getPageDescriptor();
        await this._transition(C.STATES.WAITING_USER, {
          currentStateReason: 'Scroll the LinkedIn result list manually to load more items, then press Resume.',
          waitingAction: C.WAITING_ACTIONS.MANUAL_SCROLL,
          waitingPageKey: descriptor.pageKey,
          waitingSignature: descriptor.signature,
          waitingRowCount: descriptor.rowCount,
          requiresUserAction: true
        });
        return this.getSnapshot();
      }

      await this._transition(C.STATES.ERROR, { lastError: `Unsupported pagination mode: ${mode}` });
      this._stopAutoSave();
      return this.getSnapshot();
    }

    async collectAndSavePage() {
      const extraction = Extractor.extractAll({ retryCount: this.settings.retryCount });
      await this._transition(C.STATES.SAVING, {
        currentPage: this._getPageNumber(),
        currentSelector: extraction.selector || 'resultRow/personLink',
        failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
        rowsFound: extraction.rowsFound,
        rowFailures: extraction.failures.length,
        debug: {
          currentSelector: extraction.selector || 'resultRow/personLink',
          failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
          rowsFound: extraction.rowsFound,
          failedRows: extraction.failures,
          extractedAt: new Date().toISOString()
        }
      });

      let added = 0;
      let updated = 0;
      let duplicates = 0;
      const retryCount = Math.max(1, Math.min(6, Number(this.settings.retryCount) || 3));

      for (const lead of extraction.leads) {
        if (this._shouldStop()) break;
        while (this._shouldPause()) {
          if (this._shouldStop()) return { ok: false, stopped: true, extraction, added, updated, duplicates };
          await Wait.wait(250);
        }

        let saved = false;
        let lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try {
            await this._persist({ retryCount: attempt, debug: { ...(this.meta.debug || {}), currentSelector: 'storage.upsertLead', retryCount: attempt, leadKey: U.leadKey(lead) } });
            const result = await S.upsertLead(lead);
            if (result.added) added += 1;
            else if (result.updated) updated += 1;
            else duplicates += 1;
            saved = true;

            const totalLeads = await S.getLeadCount();
            await this._persist({
              totalLeads,
              collectedThisRun: Number(this.meta.collectedThisRun || 0) + (result.added ? 1 : 0),
              duplicates: Number(this.meta.duplicates || 0) + (!result.added && !result.updated ? 1 : 0),
              lastSavedLead: U.leadKey(lead),
              lastSavedAt: new Date().toISOString(),
              lastError: ''
            });
            break;
          } catch (error) {
            lastError = error;
            Logger.warning('Lead save retry', attempt, error?.message || error);
            if (attempt < retryCount) await Wait.wait(Math.min(1200, 250 * attempt));
          }
        }

        if (!saved) {
          const errors = Number(this.meta.errors || 0) + 1;
          await this._persist({ errors, lastError: lastError?.message || 'Lead save failed', debug: { ...(this.meta.debug || {}), currentSelector: 'storage.upsertLead', failedLead: U.leadKey(lead), retryCount } });
          Logger.error('Lead skipped after storage retries', lastError?.message || lastError);
        }
      }

      await this._persist({
        pagesProcessed: Number(this.meta.pagesProcessed || 0) + 1,
        lastPageSavedAt: new Date().toISOString(),
        lastPageStats: { rowsFound: extraction.rowsFound, added, updated, duplicates, rowFailures: extraction.failures.length }
      });

      if (this.settings.autoDownload && extraction.leads.length && root.LXExport?.downloadCsv) {
        try { root.LXExport.downloadCsv(await S.getLeads()); }
        catch (error) { Logger.warning('Auto-download failed', error?.message || error); }
      }

      return { ok: !this._shouldStop(), extraction, added, updated, duplicates };
    }

    async _validateSearchContext() {
      const path = window.location.pathname;
      if (!/\/sales\/(search|lists|people)/i.test(path)) {
        return { ok: false, reason: 'Open a Sales Navigator search/list/people view before starting.' };
      }
      const currentSearch = U.searchKey(window.location.href);
      const existing = await S.getMeta();
      if (existing.searchKey && existing.searchKey !== currentSearch && existing.state && ![C.STATES.IDLE, C.STATES.STOPPED, C.STATES.FINISHED].includes(existing.state)) {
        return { ok: false, reason: 'The current search does not match the saved run. Reset the run before starting a different search.' };
      }
      return { ok: true };
    }
  }

  root.LXController = new Controller();
})(typeof window !== 'undefined' ? window : globalThis);
