/* picker.js — user-driven selector picker and verifier for pagination controls. */
(function attachPicker(root) {
  const U = root.LX;
  const C = root.LXConstants;
  const S = root.LXStorage;
  const Logger = root.LXLogger;

  let active = false;
  let mode = C.PAGINATION_MODES.CLICK_LINK;
  let previousOutline = null;
  let overlay = null;
  let listeners = null;

  function cleanup() {
    if (!active) return;
    active = false;
    if (previousOutline?.element) previousOutline.element.style.outline = previousOutline.outline;
    previousOutline = null;
    overlay?.remove();
    overlay = null;
    if (listeners) {
      document.removeEventListener('mouseover', listeners.over, true);
      document.removeEventListener('click', listeners.click, true);
      document.removeEventListener('keydown', listeners.key, true);
    }
    listeners = null;
  }

  function eligible(element) {
    if (!element || element.nodeType !== 1) return false;
    const tag = element.tagName.toLowerCase();
    if (mode === C.PAGINATION_MODES.CLICK_LINK) return tag === 'a' || !!element.closest('a');
    if (mode === C.PAGINATION_MODES.CLICK_BUTTON) return tag === 'button' || !!element.closest('button');
    return false;
  }

  function resolveTarget(element) {
    if (!element) return null;
    return mode === C.PAGINATION_MODES.CLICK_LINK ? (element.closest('a') || element) : (element.closest('button') || element);
  }

  function setHighlight(element) {
    const target = resolveTarget(element);
    if (!target || !eligible(target)) return;
    if (previousOutline?.element && previousOutline.element !== target) previousOutline.element.style.outline = previousOutline.outline;
    if (previousOutline?.element !== target) previousOutline = { element: target, outline: target.style.outline };
    target.style.outline = '3px solid #0a66c2';
  }

  function createOverlay() {
    overlay = document.createElement('div');
    overlay.id = '__lx_picker_hint';
    overlay.textContent = `LeadSense: click the ${mode === C.PAGINATION_MODES.CLICK_LINK ? 'Next link' : 'Load more button'} to save it. Esc cancels.`;
    Object.assign(overlay.style, {
      position: 'fixed', top: '12px', left: '50%', transform: 'translateX(-50%)',
      zIndex: '2147483647', padding: '10px 14px', borderRadius: '999px',
      background: '#111827', color: '#fff', font: '600 12px system-ui,sans-serif',
      boxShadow: '0 6px 24px rgba(0,0,0,.35)', pointerEvents: 'none'
    });
    document.documentElement.appendChild(overlay);
  }

  async function pick(modeInput) {
    mode = modeInput;
    if (![C.PAGINATION_MODES.CLICK_LINK, C.PAGINATION_MODES.CLICK_BUTTON].includes(mode)) return { ok: false, reason: 'Picker only supports link and button modes.' };
    cleanup();
    active = true;
    createOverlay();

    return new Promise((resolve) => {
      const finish = async (result) => {
        cleanup();
        resolve(result);
      };
      const over = (event) => {
        const target = resolveTarget(event.target);
        if (eligible(target)) setHighlight(target);
      };
      const click = async (event) => {
        const target = resolveTarget(event.target);
        if (!eligible(target)) return;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        const selector = U.buildStableSelector(target);
        if (!selector) {
          await finish({ ok: false, reason: 'Could not build a stable selector for that control.' });
          return;
        }
        try {
          const settings = await S.saveSettings({
            paginationMode: mode,
            paginationTargetSelector: selector,
            paginationTargetLabel: U.cleanText(`${target.textContent} ${target.getAttribute('aria-label') || target.title || ''}`)
          });
          Logger.success('Pagination target saved', selector);
          await finish({ ok: true, selector, settings });
        } catch (error) {
          await finish({ ok: false, reason: error?.message || 'Failed to save selector.' });
        }
      };
      const key = (event) => {
        if (event.key === 'Escape') finish({ ok: false, reason: 'Picker cancelled.' });
      };
      listeners = { over, click, key };
      document.addEventListener('mouseover', over, true);
      document.addEventListener('click', click, true);
      document.addEventListener('keydown', key, true);
    });
  }

  root.LXPicker = { pick };
})(typeof window !== 'undefined' ? window : globalThis);
