/* scroll.js — observes user scrolling and lazy-loaded result growth; never scrolls the page automatically. */
(function attachScroll(root) {
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;

  function isScrollable(el) {
    if (!el || el.nodeType !== 1) return false;
    const style = getComputedStyle(el);
    const overflowY = style.overflowY;
    return (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && el.scrollHeight > el.clientHeight + 40;
  }

  function findContainer(rows) {
    const sample = rows && rows[0];
    let node = sample ? sample.parentElement : null;
    while (node && node !== document.body) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function progressOf(container) {
    const max = Math.max(1, container.scrollHeight - container.clientHeight);
    const top = Number(container.scrollTop || 0);
    return Math.min(100, Math.round((top / max) * 100));
  }

  function restorePosition(container, scrollTop) {
    const value = Number(scrollTop);
    if (!container || !Number.isFinite(value) || value < 0) return false;
    const max = Math.max(0, container.scrollHeight - container.clientHeight);
    container.scrollTop = Math.min(value, max);
    return true;
  }

  async function waitForManualGrowth({ findRows, settings, shouldCancel, onProgress }) {
    const initialRows = findRows();
    const container = findContainer(initialRows);
    const baselineSignature = initialRows.map((row) => row.__lxSig || '').filter(Boolean).join('|');
    let lastCount = initialRows.length;
    let lastSignature = baselineSignature;
    let lastTop = Number(container.scrollTop || 0);

    try {
      const result = await Wait.waitForCondition(() => {
        const rows = findRows();
        const signature = rows.map((row) => row.__lxSig || '').filter(Boolean).join('|');
        const currentTop = Number(container.scrollTop || 0);
        const changed = rows.length > lastCount || (signature && signature !== lastSignature);
        if (changed || currentTop !== lastTop) {
          lastCount = rows.length;
          lastSignature = signature;
          lastTop = currentTop;
          void onProgress?.({ progress: progressOf(container), scrollTop: currentTop, scrollHeight: container.scrollHeight, rows: rows.length });
        }
        return changed;
      }, { root: document.body || document.documentElement, timeoutMs: settings.timeoutMs, shouldCancel });
      return { ok: true, waitedMs: result.waitedMs, progress: progressOf(container), scrollTop: container.scrollTop, rows: findRows().length };
    } catch (error) {
      Logger.debug('Manual scroll growth wait ended', error?.message || error);
      return { ok: false, reason: error?.message || 'manual-scroll-timeout', progress: progressOf(container), scrollTop: container.scrollTop, rows: findRows().length };
    }
  }

  root.LXScroll = { findContainer, restorePosition, progressOf, waitForManualGrowth };
})(typeof window !== 'undefined' ? window : globalThis);
