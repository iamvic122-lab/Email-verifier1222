/* content.js — runtime bridge plus explicit user-assisted resume only. */
(function boot() {
  if (window.__LX_CONTENT_BOOTED__) return;
  window.__LX_CONTENT_BOOTED__ = true;

  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const Logger = window.LXLogger;
  const E = window.LXExtractor;
  const Controller = window.LXController;
  const Pagination = window.LXPagination;
  const Picker = window.LXPicker;
  const Safety = window.LXSafety;

  async function bootController() {
    try {
      await Controller.init();
      const meta = await S.getMeta();
      if (meta?.state && meta.state !== C.STATES.IDLE) {
        Logger.info('Saved run restored in standby', meta.state, meta.runId || '');
      }
    } catch (error) {
      Logger.error('Controller boot failed', error?.message || error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    (async () => {
      try {
        switch (message.type) {
          case 'LX_PING': {
            const settings = await S.getSettings();
            const safety = Safety.detect();
            const rows = E.findResultRows();
            sendResponse({
              ok: true,
              url: window.location.href,
              onSearch: /\/sales\/(search|lists|people)/i.test(window.location.pathname),
              rowsVisible: rows.length,
              loading: E.hasBlockingLoader(),
              safetyRisk: safety,
              pagination: Pagination.verifyTarget(settings.paginationMode, settings.paginationTargetSelector),
              state: (await S.getMeta()).state || C.STATES.IDLE,
              page: Number(new URL(window.location.href).searchParams.get('page')) || Number((await S.getMeta()).currentPage) || 1
            });
            return;
          }
          case 'LX_GET_STATE':
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_START': {
            const state = await Controller.start();
            sendResponse({ ok: true, state });
            return;
          }
          case 'LX_PAUSE': {
            const state = await Controller.pause();
            sendResponse({ ok: true, state });
            return;
          }
          case 'LX_RESUME': {
            const state = await Controller.resume();
            sendResponse({ ok: true, state });
            return;
          }
          case 'LX_STOP': {
            const state = await Controller.stop();
            sendResponse({ ok: true, state });
            return;
          }
          case 'LX_RESET_RUN': {
            const state = await Controller.resetRun();
            sendResponse({ ok: true, state });
            return;
          }
          case 'LX_EXTRACT_PAGE': {
            const result = await Controller.extractCurrentPage();
            if (!result?.ok) {
              sendResponse({ ok: false, reason: result?.reason || 'Extraction failed.' });
              return;
            }
            const leads = await S.getLeads();
            sendResponse({
              ok: true,
              foundOnPage: result.extraction?.leads?.length || 0,
              added: result.added || 0,
              updated: result.updated || 0,
              duplicates: result.duplicates || 0,
              totalLeads: leads.length,
              leads,
              readiness: (await S.getMeta()).lastReadiness || null
            });
            return;
          }
          case 'LX_NEXT_PAGE_ASSIST': {
            const result = await Controller.assistNextPage();
            sendResponse({ ok: !!result?.ok, reason: result?.reason || '', target: result?.target || null, state: result?.state || Controller.getSnapshot() });
            return;
          }
          case 'LX_LOAD_MORE_ASSIST': {
            const result = await Controller.assistLoadMore();
            sendResponse({ ok: !!result?.ok, reason: result?.reason || '', target: result?.target || null, state: result?.state || Controller.getSnapshot() });
            return;
          }
          case 'LX_SCROLL_ASSIST': {
            const result = await Controller.assistScroll();
            sendResponse({ ok: !!result?.ok, reason: result?.reason || '', state: result?.state || Controller.getSnapshot() });
            return;
          }
          case 'LX_VERIFY_TARGET': {
            const settings = await S.getSettings();
            const mode = message.mode || settings.paginationMode;
            const selector = message.selector ?? settings.paginationTargetSelector;
            sendResponse({ ok: true, result: Pagination.verifyTarget(mode, selector) });
            return;
          }
          case 'LX_PICK_TARGET': {
            const mode = message.mode;
            if (![C.PAGINATION_MODES.CLICK_LINK, C.PAGINATION_MODES.CLICK_BUTTON].includes(mode)) {
              sendResponse({ ok: false, reason: 'Target picker is available only for Next-link and Load-more-button modes.' });
              return;
            }
            sendResponse({ ok: true, started: true });
            void Picker.pick(mode).catch((error) => Logger.error('Target picker failed', error?.message || error));
            return;
          }
          case 'LX_GET_NEXT':
            sendResponse({ ok: true, hasNext: Pagination.hasNext((await S.getSettings()).paginationTargetSelector) });
            return;
          default:
            sendResponse({ ok: false, reason: 'Unknown message type.' });
        }
      } catch (error) {
        Logger.error('Message operation failed', message.type, error?.message || error);
        sendResponse({ ok: false, reason: error?.message || 'Operation failed.' });
      }
    })();

    return true;
  });

  void bootController();
})();
