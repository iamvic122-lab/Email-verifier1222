/* constants.js — single source of truth for states, operating modes and bounded settings. */
(function attachConstants(root) {
  const Constants = {
    VERSION: '3.2.0',
    STORAGE_KEYS: Object.freeze({
      LEADS: 'lx_leads',
      SETTINGS: 'lx_settings',
      META: 'lx_meta'
    }),
    STATES: Object.freeze({
      IDLE: 'IDLE',
      STARTING: 'STARTING',
      WAITING_READY: 'WAITING_READY',
      SCROLLING: 'SCROLLING',
      COLLECTING: 'COLLECTING',
      SAVING: 'SAVING',
      WAITING_USER: 'WAITING_USER',
      WAITING_PAGE: 'WAITING_PAGE',
      PAUSED: 'PAUSED',
      FINISHED: 'FINISHED',
      STOPPED: 'STOPPED',
      ERROR: 'ERROR'
    }),
    PAGINATION_MODES: Object.freeze({
      NONE: 'none',
      SCROLL: 'scroll',
      CLICK_LINK: 'click_link',
      CLICK_BUTTON: 'click_button'
    }),
    WAITING_ACTIONS: Object.freeze({
      NONE: 'none',
      NEXT_PAGE: 'next_page',
      LOAD_MORE: 'load_more',
      MANUAL_SCROLL: 'manual_scroll'
    }),
    DEFAULTS: Object.freeze({
      autoDownload: false,
      darkMode: true,
      autoScroll: false,
      autoNextPage: false,
      autoSave: true,
      autoResume: false,
      continueWhenPopupClosed: true,
      humanMode: false,
      paginationMode: 'click_link',
      paginationTargetSelector: '',
      paginationTargetLabel: '',
      safetyMode: true,
      stopOnSecurityPrompt: true,
      actionDelayMinMs: 1200,
      actionDelayMaxMs: 2200,
      randomDelayMinMs: 300,
      randomDelayMaxMs: 900,
      scrollMinPx: 350,
      scrollMaxPx: 700,
      scrollPauseMinMs: 500,
      scrollPauseMaxMs: 1200,
      retryCount: 3,
      timeoutMs: 30000,
      stableMs: 900,
      autoSaveMs: 30000,
      maxPages: 100,
      maxScrollPasses: 100,
      pageChangeRetries: 3,
      debugMode: false,
      safetyCooldownMs: 300000
    }),
    LIMITS: Object.freeze({
      retryCount: { min: 1, max: 6 },
      timeoutMs: { min: 5000, max: 90000 },
      stableMs: { min: 250, max: 5000 },
      actionDelayMinMs: { min: 250, max: 30000 },
      actionDelayMaxMs: { min: 500, max: 60000 },
      maxActionsPerMinute: { min: 2, max: 30 },
      randomDelayMinMs: { min: 0, max: 10000 },
      randomDelayMaxMs: { min: 50, max: 20000 },
      scrollMinPx: { min: 100, max: 1500 },
      scrollMaxPx: { min: 150, max: 2500 },
      scrollPauseMinMs: { min: 250, max: 8000 },
      scrollPauseMaxMs: { min: 500, max: 15000 },
      autoSaveMs: { min: 10000, max: 120000 },
      maxPages: { min: 1, max: 500 },
      maxScrollPasses: { min: 10, max: 500 },
      pageChangeRetries: { min: 1, max: 6 },
      safetyCooldownMs: { min: 60000, max: 1800000 }
    })
  };

  root.LXConstants = Constants;
})(typeof window !== 'undefined' ? window : globalThis);
