/* pagination.js — safe page/load-more target discovery, verification and user-assist watchers. */
(function attachPagination(root) {
  const SEL = root.LXSelectors;
  const C = root.LXConstants;
  const Wait = root.LXWait;
  const Logger = root.LXLogger;
  const Extractor = root.LXExtractor;
  const U = root.LX;

  function isVisible(element) {
    if (!element || element.nodeType !== 1) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0;
  }

  function isDisabled(element) {
    if (!element) return true;
    return !!(
      element.disabled ||
      element.getAttribute('aria-disabled') === 'true' ||
      element.getAttribute('disabled') !== null ||
      element.classList.contains('disabled') ||
      element.classList.contains('artdeco-button--disabled') ||
      !isVisible(element)
    );
  }

  function firstMatch(selectors) {
    for (const selector of selectors || []) {
      try {
        const candidate = [...document.querySelectorAll(selector)].find((element) => !isDisabled(element));
        if (candidate) return { element: candidate, selector };
      } catch (error) {
        Logger.debug('Pagination selector failed', selector, error?.message || error);
      }
    }
    return null;
  }

  function findByText(kind) {
    const elements = [...document.querySelectorAll(kind === 'link' ? 'a' : 'button')].filter(isVisible);
    return elements.find((element) => {
      const text = U.cleanText(element.textContent || '');
      const label = U.cleanText(element.getAttribute('aria-label') || element.title || '');
      return /\b(next|next page)\b/i.test(`${text} ${label}`) && !isDisabled(element);
    }) || null;
  }

  function findNext(customSelector = '') {
    if (customSelector) {
      const custom = firstMatch([customSelector]);
      if (custom) return custom;
    }
    const result = firstMatch([...SEL.nextButton, ...SEL.nextLink]);
    if (result) return result;
    const link = findByText('link');
    if (link) return { element: link, selector: 'text:next-link' };
    const button = findByText('button');
    if (button) return { element: button, selector: 'text:next-button' };
    return null;
  }

  function findLoadMoreButton(customSelector = '') {
    if (customSelector) {
      try {
        const custom = [...document.querySelectorAll(customSelector)].find((element) => !isDisabled(element));
        if (custom) return { element: custom, selector: customSelector };
      } catch (error) {
        Logger.warning('Custom load-more selector failed', customSelector, error?.message || error);
      }
    }
    const preferred = firstMatch(SEL.loadMoreButton.filter((selector) => selector !== 'button'));
    if (preferred) return preferred;
    const buttons = [...document.querySelectorAll('button')].filter(isVisible);
    const textMatch = buttons.find((button) => /\bload\s+more\b|show\s+more\s+results|more\s+results/i.test(`${U.cleanText(button.textContent)} ${U.cleanText(button.getAttribute('aria-label') || '')}`) && !isDisabled(button));
    return textMatch ? { element: textMatch, selector: 'text:load-more' } : null;
  }

  function getTarget(mode, customSelector = '') {
    if (mode === C.PAGINATION_MODES.CLICK_LINK) return findNext(customSelector);
    if (mode === C.PAGINATION_MODES.CLICK_BUTTON) return findLoadMoreButton(customSelector);
    return null;
  }

  function getPageDescriptor() {
    return {
      url: window.location.href,
      pageKey: U.pageKey(window.location.href),
      searchKey: U.searchKey(window.location.href),
      signature: Extractor.signature(),
      rowCount: Extractor.findResultRows().length
    };
  }

  function samePageChanged(previous, current) {
    return !!previous && (
      current.pageKey !== previous.pageKey ||
      (previous.signature && current.signature && current.signature !== previous.signature) ||
      current.rowCount > Number(previous.rowCount || 0)
    );
  }

  function hasNext(customSelector = '') { return !!findNext(customSelector); }
  function hasLoadMore(customSelector = '') { return !!findLoadMoreButton(customSelector); }

  function describeTarget(target) {
    if (!target?.element) return null;
    return {
      selector: target.selector || '',
      text: U.cleanText(`${target.element.textContent || ''} ${target.element.getAttribute('aria-label') || target.element.title || ''}`),
      disabled: isDisabled(target.element),
      visible: isVisible(target.element)
    };
  }

  function focusTarget(mode, customSelector = '') {
    const target = getTarget(mode, customSelector);
    if (!target) return { ok: false, reason: 'target-not-found' };
    try {
      target.element.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
      target.element.dataset.lxAssistTarget = 'true';
      target.element.style.outline = '3px solid #0a66c2';
      window.setTimeout(() => {
        try {
          if (target.element?.isConnected) {
            target.element.style.outline = '';
            delete target.element.dataset.lxAssistTarget;
          }
        } catch (_) {}
      }, 4000);
    } catch (error) {
      Logger.debug('Could not focus pagination target', error?.message || error);
    }
    return { ok: true, ...describeTarget(target) };
  }

  async function waitForResultChange(previous, settings, shouldCancel = () => false) {
    const timeoutMs = Number(settings?.timeoutMs) || C.DEFAULTS.timeoutMs;
    const startedAt = Date.now();
    try {
      const result = await Wait.waitForCondition(() => samePageChanged(previous, getPageDescriptor()), {
        root: document.body || document.documentElement,
        timeoutMs,
        shouldCancel
      });
      return { ok: true, descriptor: getPageDescriptor(), waitedMs: result.waitedMs };
    } catch (error) {
      return { ok: false, reason: error?.message || `No page/result change after ${Date.now() - startedAt}ms`, waitedMs: Date.now() - startedAt };
    }
  }

  function verifyTarget(mode, selector = '') {
    if (mode === C.PAGINATION_MODES.CLICK_LINK) {
      const target = selector ? firstMatch([selector]) : findNext();
      return { ok: !!target, mode, ...describeTarget(target), selector: target?.selector || selector || null };
    }
    if (mode === C.PAGINATION_MODES.CLICK_BUTTON) {
      const target = findLoadMoreButton(selector);
      return { ok: !!target, mode, ...describeTarget(target), selector: target?.selector || selector || null };
    }
    return { ok: true, mode, selector: null, visible: true, disabled: false, text: '' };
  }

  root.LXPagination = {
    findNext: (selector = '') => findNext(selector)?.element || null,
    hasNext,
    findLoadMoreButton: (selector = '') => findLoadMoreButton(selector)?.element || null,
    hasLoadMore,
    getTarget,
    getPageDescriptor,
    samePageChanged,
    focusTarget,
    waitForResultChange,
    verifyTarget
  };
})(typeof window !== 'undefined' ? window : globalThis);
