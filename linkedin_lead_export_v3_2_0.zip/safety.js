/* safety.js — fail-closed detection for visible auth, checkpoint and restriction signals. */
(function attachSafety(root) {
  const C = root.LXConstants;
  const SEL = root.LXSelectors;
  const U = root.LX;
  const Logger = root.LXLogger;

  const TEXT_PATTERNS = Object.freeze([
    { code: 'captcha', re: /\bcaptcha\b/i },
    { code: 'identity_verification', re: /verify (your|the) identity|verify it'?s you|confirm (your|the) identity/i },
    { code: 'security_checkpoint', re: /security checkpoint|verification checkpoint|account checkpoint|security challenge/i },
    { code: 'unusual_activity', re: /unusual activity|unusual sign-?in|suspicious activity/i },
    { code: 'account_restricted', re: /temporarily restricted|account restricted|your account has been restricted|access to your account has been restricted/i },
    { code: 'rate_limit', re: /too many requests|too many attempts|please try again later/i },
    { code: 'session_expired', re: /session has expired|sign in to continue|please sign in/i }
  ]);

  function visible(element) {
    if (!element || element.nodeType !== 1) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function normalizeResult(result) {
    return {
      risky: !!result?.risky,
      code: result?.code || '',
      reason: result?.reason || '',
      selector: result?.selector || '',
      checkedAt: new Date().toISOString()
    };
  }

  function detect() {
    for (const selector of SEL.securityMarkers || []) {
      try {
        const match = [...document.querySelectorAll(selector)].find(visible);
        if (match) return normalizeResult({ risky: true, code: 'security_marker', reason: `Visible security marker detected (${selector}).`, selector });
      } catch (error) {
        Logger.debug('Security selector failed', selector, error?.message || error);
      }
    }

    const bodyText = U.cleanText(document.body?.innerText || '').slice(0, 40000);
    for (const pattern of TEXT_PATTERNS) {
      if (pattern.re.test(bodyText)) {
        return normalizeResult({ risky: true, code: pattern.code, reason: `Visible security/session signal detected: ${pattern.code}.` });
      }
    }

    return normalizeResult({ risky: false, code: 'clear', reason: 'No visible authentication, checkpoint, CAPTCHA or restriction signal detected.' });
  }

  function validateSettings(settings) {
    const input = { ...C.DEFAULTS, ...(settings || {}) };
    const min = U.clamp(input.actionDelayMinMs, C.LIMITS.actionDelayMinMs.min, C.LIMITS.actionDelayMinMs.max);
    const max = U.clamp(input.actionDelayMaxMs, C.LIMITS.actionDelayMaxMs.min, C.LIMITS.actionDelayMaxMs.max);
    const safetyCooldownMs = U.clamp(input.safetyCooldownMs, C.LIMITS.safetyCooldownMs.min, C.LIMITS.safetyCooldownMs.max);
    return {
      ...input,
      safetyMode: true,
      stopOnSecurityPrompt: true,
      autoScroll: false,
      autoNextPage: false,
      autoResume: false,
      actionDelayMinMs: Math.min(min, max),
      actionDelayMaxMs: Math.max(min, max),
      retryCount: Math.round(U.clamp(input.retryCount, C.LIMITS.retryCount.min, C.LIMITS.retryCount.max)),
      timeoutMs: Math.round(U.clamp(input.timeoutMs, C.LIMITS.timeoutMs.min, C.LIMITS.timeoutMs.max)),
      stableMs: Math.round(U.clamp(input.stableMs, C.LIMITS.stableMs.min, C.LIMITS.stableMs.max)),
      maxPages: Math.round(U.clamp(input.maxPages, C.LIMITS.maxPages.min, C.LIMITS.maxPages.max)),
      pageChangeRetries: Math.round(U.clamp(input.pageChangeRetries, C.LIMITS.pageChangeRetries.min, C.LIMITS.pageChangeRetries.max)),
      safetyCooldownMs: Math.round(safetyCooldownMs)
    };
  }

  async function waitForActionBudget(meta, settings, Wait) {
    const normalized = validateSettings(settings);
    const now = Date.now();
    const lastActionAt = Date.parse(meta?.lastActionAt || '');
    const minGap = normalized.actionDelayMinMs;
    if (lastActionAt > 0) {
      const remaining = minGap - (now - lastActionAt);
      if (remaining > 0) await Wait.wait(remaining);
    }
    const delay = U.randomBetween(normalized.actionDelayMinMs, normalized.actionDelayMaxMs);
    if (delay > 0) await Wait.wait(delay);
    return { lastActionAt: new Date().toISOString() };
  }

  function isCoolingDown(meta, settings) {
    const eventAt = Date.parse(meta?.lastSafetyEventAt || '');
    if (!eventAt) return false;
    return Date.now() - eventAt < Number(settings?.safetyCooldownMs || C.DEFAULTS.safetyCooldownMs);
  }

  root.LXSafety = { detect, validateSettings, waitForActionBudget, isCoolingDown };
})(typeof window !== 'undefined' ? window : globalThis);
