# Sales Navigator Lead Extractor — v3.2.0

Production Manifest V3 extension for extracting visible Sales Navigator lead records with persistent local storage, duplicate-safe upserts, retryable readiness, explicit user-assisted pagination and fail-closed safety handling.

## Important safety behavior

No software can guarantee that LinkedIn will never restrict an account. This build therefore does not attempt to defeat or evade LinkedIn safeguards.

The extension deliberately does **not**:

- auto-click Next or Load more;
- auto-scroll the LinkedIn result list;
- rotate accounts, proxies or fingerprints;
- solve or bypass CAPTCHA;
- submit identity/authentication/checkpoint forms;
- continue after a visible restriction or security challenge.

Instead, it assists the user: it detects the available control, highlights it, waits for the user to perform the action, and then the user presses **Resume**. The extractor waits for a real DOM/result change, uses bounded retries, and checkpoints progress.

## Action to load more items

The popup has the requested menu:

- **None** — current visible result set only.
- **Scroll down to load more items** — the user scrolls the LinkedIn result list; the extension can detect growth after Resume.
- **Click link to navigate to next page** — the user clicks LinkedIn's Next control; the extension then verifies the new page/result state after Resume.
- **Click button to load more items on same page** — the user clicks LinkedIn's Load more control; the extension then verifies result growth after Resume.

**Select** lets the user select a stable target selector. **Verify** checks that target on the current page. **Assist Selected Action** highlights and scrolls the selected control into view without clicking it.

## Retry and waiting behavior

Readiness is mutation-driven with bounded polling fallback. A readiness timeout is retried up to the configured retry count. The extension watches the document-level DOM so SPA page replacement does not leave the observer attached to a detached result subtree.

After manual pagination/load-more activity, the extension compares:

- current page key / URL;
- result signature;
- visible row count.

A transition is accepted only when one of those meaningful signals changes.

## Safety guard

The guard checks for visible CAPTCHA, identity verification, security checkpoint, unusual-activity, restriction, rate-limit and session-expired signals. When a signal is detected, the run is stopped and the state is checkpointed for manual recovery.

The guard is always enabled. The UI does not expose an option to disable it.

## Resume behavior

The popup can be closed without losing the saved lead data or run checkpoint. The content-side controller does not silently restart a run after a reload. The user explicitly presses **Resume** after confirming the LinkedIn page is the intended page.

Saved metadata includes current URL/page, search key, current signature, row count, last saved lead, counters, waiting action, retry details and safety events.

## Project files

| File | Responsibility |
|---|---|
| `constants.js` | States, modes, defaults and bounds |
| `logger.js` | Central structured logging |
| `selectors.js` | LinkedIn selectors and security markers |
| `utils.js` | Normalization, identifiers and export helpers |
| `safety.js` | Fail-closed safety detection and pacing |
| `wait.js` | Mutation/condition synchronization |
| `storage.js` | Persistent local storage and duplicate-safe upserts |
| `extractor.js` | Result-row discovery and field extraction |
| `scroll.js` | User-scroll observation / position helpers |
| `pagination.js` | Target discovery, verification and user-assist watchers |
| `picker.js` | User-selected target selector picker |
| `export.js` | CSV/JSON/clipboard export |
| `controller.js` | State machine and run orchestration |
| `content.js` | Content-side message bridge |
| `popup.*` | Control panel and settings |
| `background.js` | MV3 lifecycle/default initialization |

## State machine

`IDLE → STARTING → WAITING_READY → COLLECTING → SAVING → WAITING_USER`

Control states: `PAUSED`, `STOPPED`, `FINISHED`, `ERROR`.

`WAITING_USER` means the extension is waiting for the user's LinkedIn action, such as clicking Next or Load more, or manually scrolling the result list.
