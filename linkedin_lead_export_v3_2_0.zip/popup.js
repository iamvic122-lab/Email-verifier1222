/* popup.js — control panel only; no scraping work is owned by the popup. */
(function initPopup() {
  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;

  const els = {
    settingsBtn: document.getElementById('settingsBtn'),
    statusPill: document.getElementById('statusPill'),
    totalCount: document.getElementById('totalCount'),
    pageCount: document.getElementById('pageCount'),
    duplicateCount: document.getElementById('duplicateCount'),
    errorCount: document.getElementById('errorCount'),
    progressBar: document.getElementById('progressBar'),
    statusHint: document.getElementById('statusHint'),
    speedValue: document.getElementById('speedValue'),
    etaValue: document.getElementById('etaValue'),
    safetyStrip: document.getElementById('safetyStrip'),
    startBtn: document.getElementById('startBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    resumeBtn: document.getElementById('resumeBtn'),
    stopBtn: document.getElementById('stopBtn'),
    extractBtn: document.getElementById('extractBtn'),
    assistBtn: document.getElementById('assistBtn'),
    resetRunBtn: document.getElementById('resetRunBtn'),
    clearBtn: document.getElementById('clearBtn'),
    setPaginationMode: document.getElementById('setPaginationMode'),
    selectTargetBtn: document.getElementById('selectTargetBtn'),
    verifyTargetBtn: document.getElementById('verifyTargetBtn'),
    targetStatus: document.getElementById('targetStatus'),
    tableRowCount: document.getElementById('tableRowCount'),
    leadTableHead: document.getElementById('leadTableHead'),
    leadTableBody: document.getElementById('leadTableBody'),
    leadTableEmpty: document.getElementById('leadTableEmpty'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    downloadCsvBtn: document.getElementById('downloadCsvBtn'),
    downloadJsonBtn: document.getElementById('downloadJsonBtn'),
    settingsPanel: document.getElementById('settingsPanel'),
    debugPanel: document.getElementById('debugPanel'),
    debugText: document.getElementById('debugText'),
    setAutoSave: document.getElementById('setAutoSave'),
    setContinueClosed: document.getElementById('setContinueClosed'),
    setAutoDownload: document.getElementById('setAutoDownload'),
    setDebug: document.getElementById('setDebug'),
    setRetry: document.getElementById('setRetry'),
    setTimeout: document.getElementById('setTimeout'),
    setStable: document.getElementById('setStable'),
    setMaxPages: document.getElementById('setMaxPages'),
    setActionDelayMin: document.getElementById('setActionDelayMin'),
    setActionDelayMax: document.getElementById('setActionDelayMax'),
    setSafetyCooldown: document.getElementById('setSafetyCooldown'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    urlIndicator: document.getElementById('urlIndicator')
  };

  let activeTabId = null;
  let refreshTimer = null;
  let initialized = false;

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs?.[0] || null;
  }

  function sendToTab(message) {
    if (!activeTabId) return Promise.resolve(null);
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(activeTabId, message, (response) => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response || null);
      });
    });
  }

  async function ensureContent(tab) {
    if (!tab?.id || !tab.url || !/linkedin\.com\/sales\//i.test(tab.url)) return null;
    let ping = await sendToTab({ type: 'LX_PING' });
    if (ping?.ok) return ping;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [
          'constants.js', 'logger.js', 'selectors.js', 'utils.js', 'safety.js', 'wait.js',
          'storage.js', 'extractor.js', 'scroll.js', 'pagination.js', 'picker.js', 'export.js',
          'controller.js', 'content.js'
        ]
      });
    } catch (_) {
      return null;
    }
    ping = await sendToTab({ type: 'LX_PING' });
    return ping?.ok ? ping : null;
  }

  async function refreshTab() {
    const tab = await getActiveTab();
    activeTabId = tab?.id || null;
    const ping = await ensureContent(tab);
    if (!tab?.url) {
      els.urlIndicator.textContent = '—';
      setHint('Open a Sales Navigator people search.');
      return;
    }
    try { els.urlIndicator.textContent = new URL(tab.url).pathname.slice(0, 52); }
    catch (_) { els.urlIndicator.textContent = String(tab.url).slice(0, 52); }
    if (!ping) {
      setHint('Open a Sales Navigator search page to use the extractor.');
      return;
    }
    renderState(await S.getMeta(), ping);
    renderTargetStatus(await S.getSettings(), ping);
  }

  function setHint(text) { els.statusHint.textContent = String(text || ''); }

  function renderState(meta = {}, ping = null) {
    const state = meta.state || C.STATES.IDLE;
    els.statusPill.textContent = state;
    els.statusPill.className = `status-pill ${state.toLowerCase()}`;
    els.totalCount.textContent = String(meta.totalLeads ?? 0);
    els.pageCount.textContent = String(meta.currentPage ?? (ping?.page ?? 1));
    els.duplicateCount.textContent = String(meta.duplicates ?? 0);
    els.errorCount.textContent = String(meta.errors ?? 0);
    els.progressBar.style.width = `${Math.max(0, Math.min(100, Number(meta.scrollProgress || 0)))}%`;
    els.speedValue.textContent = formatSpeed(meta);
    els.etaValue.textContent = '—';

    const active = [C.STATES.STARTING, C.STATES.WAITING_READY, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.WAITING_PAGE];
    els.pauseBtn.disabled = !active.includes(state);
    els.resumeBtn.disabled = ![C.STATES.PAUSED, C.STATES.WAITING_USER].includes(state);
    els.stopBtn.disabled = !active.includes(state) && ![C.STATES.PAUSED, C.STATES.WAITING_USER].includes(state);
    els.startBtn.disabled = active.includes(state);

    const risky = ping?.safetyRisk?.risky || meta?.lastSafetyResult?.risky;
    els.safetyStrip.textContent = risky ? `Safety guard: STOPPED — ${meta?.lastSafetyResult?.reason || ping?.safetyRisk?.reason || 'security signal detected'}` : 'Safety guard: READY';
    els.safetyStrip.classList.toggle('risk', !!risky);

    const hint = meta.lastError || meta.currentStateReason || (ping?.onSearch ? `${ping.rowsVisible} visible result rows.` : 'Open a Sales Navigator people search.');
    setHint(hint);
    renderDebug(meta, ping);
  }

  function renderDebug(meta, ping) {
    const debugEnabled = !!els.setDebug.checked || !!meta?.debug?.currentSelector || !!ping?.safetyRisk?.risky;
    els.debugPanel.hidden = !debugEnabled;
    if (!debugEnabled) return;
    const compact = {
      state: meta?.state,
      waitingAction: meta?.waitingAction,
      page: meta?.currentPage,
      currentUrl: meta?.currentUrl,
      currentSelector: meta?.debug?.currentSelector || meta?.currentSelector,
      failedSelector: meta?.debug?.failedSelector || meta?.failedSelector,
      rowsFound: meta?.rowsFound,
      retryCount: meta?.retryCount,
      lastError: meta?.lastError,
      lastReadiness: meta?.lastReadiness,
      safety: ping?.safetyRisk || meta?.lastSafetyResult || null
    };
    els.debugText.textContent = JSON.stringify(compact, null, 2);
  }

  function renderTargetStatus(settings, ping = null) {
    const mode = settings.paginationMode || C.PAGINATION_MODES.CLICK_LINK;
    els.setPaginationMode.value = mode;
    const labels = {
      none: 'Current-page extraction only.',
      scroll: 'Manual scroll: scroll the LinkedIn result list yourself, then Resume.',
      click_link: 'Manual Next: click LinkedIn’s Next control yourself, then Resume.',
      click_button: 'Manual Load more: click LinkedIn’s Load more control yourself, then Resume.'
    };
    const target = settings.paginationTargetSelector ? ` Saved target: ${settings.paginationTargetSelector}` : '';
    const verify = ping?.pagination;
    els.targetStatus.textContent = `${labels[mode] || ''}${target}${verify && mode !== C.PAGINATION_MODES.NONE ? ` ${verify.ok ? '✓ target visible' : '⚠ target not found'}.` : ''}`;
    els.assistBtn.textContent = mode === C.PAGINATION_MODES.CLICK_LINK ? 'Assist Next Page' : mode === C.PAGINATION_MODES.CLICK_BUTTON ? 'Assist Load More' : mode === C.PAGINATION_MODES.SCROLL ? 'Assist Scroll' : 'Assist Selected Action';
  }

  function formatSpeed(meta) {
    const count = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!started || !count) return '0/min';
    const minutes = Math.max((Date.now() - started) / 60000, 1 / 60);
    return `${Math.round(count / minutes)}/min`;
  }

  function setNumberInputs(settings) {
    els.setRetry.value = settings.retryCount;
    els.setTimeout.value = settings.timeoutMs;
    els.setStable.value = settings.stableMs;
    els.setMaxPages.value = settings.maxPages;
    els.setActionDelayMin.value = settings.actionDelayMinMs;
    els.setActionDelayMax.value = settings.actionDelayMaxMs;
    els.setSafetyCooldown.value = settings.safetyCooldownMs;
  }

  function populateSettings(settings) {
    els.setAutoSave.checked = !!settings.autoSave;
    els.setContinueClosed.checked = !!settings.continueWhenPopupClosed;
    els.setAutoDownload.checked = !!settings.autoDownload;
    els.setDebug.checked = !!settings.debugMode;
    setNumberInputs(settings);
    document.body.classList.toggle('light', settings.darkMode === false);
    document.body.classList.toggle('dark', settings.darkMode !== false);
  }

  async function loadData() {
    const leads = await S.getLeads();
    els.totalCount.textContent = String(leads.length);
    renderTable(leads.slice(-1000));
  }

  function renderTable(leads) {
    els.tableRowCount.textContent = `${leads.length} row${leads.length === 1 ? '' : 's'}`;
    if (!els.leadTableHead.childElementCount) {
      const thIndex = document.createElement('th'); thIndex.textContent = '#'; els.leadTableHead.appendChild(thIndex);
      U.COLUMNS.forEach((column) => { const th = document.createElement('th'); th.textContent = column.label; els.leadTableHead.appendChild(th); });
    }
    els.leadTableBody.replaceChildren();
    if (!leads.length) {
      const empty = els.leadTableEmpty.cloneNode(true);
      empty.hidden = false;
      empty.querySelector('td').colSpan = U.COLUMNS.length + 1;
      els.leadTableBody.appendChild(empty);
      return;
    }
    const fragment = document.createDocumentFragment();
    [...leads].reverse().forEach((lead, index) => {
      const tr = document.createElement('tr');
      const indexCell = document.createElement('td'); indexCell.textContent = String(leads.length - index); tr.appendChild(indexCell);
      U.COLUMNS.forEach((column) => {
        const td = document.createElement('td');
        if (column.key.endsWith('LinkedInUrl') && lead[column.key]) {
          const link = document.createElement('a');
          link.href = lead[column.key]; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = lead[column.key]; td.appendChild(link);
        } else td.textContent = U.exportValue(lead, column.key);
        tr.appendChild(td);
      });
      fragment.appendChild(tr);
    });
    els.leadTableBody.appendChild(fragment);
  }

  async function runCommand(type) {
    let response = await sendToTab({ type });
    if (!response?.ok) {
      await refreshTab();
      response = await sendToTab({ type });
    }
    if (!response?.ok) {
      setHint(response?.reason || 'The page did not respond. Refresh LinkedIn and try again.');
      return;
    }
    renderState(response.state || await S.getMeta());
    await loadData();
    if (response.state) renderTargetStatus(response.state.settings || await S.getSettings());
  }

  async function assistSelectedAction() {
    const mode = (await S.getSettings()).paginationMode;
    const types = {
      [C.PAGINATION_MODES.CLICK_LINK]: 'LX_NEXT_PAGE_ASSIST',
      [C.PAGINATION_MODES.CLICK_BUTTON]: 'LX_LOAD_MORE_ASSIST',
      [C.PAGINATION_MODES.SCROLL]: 'LX_SCROLL_ASSIST'
    };
    if (mode === C.PAGINATION_MODES.NONE) {
      setHint('Pagination is set to None. Use Start / Extract or Extract Current Page Only.');
      return;
    }
    const response = await sendToTab({ type: types[mode] });
    if (!response?.ok) {
      setHint(response?.reason || 'Could not prepare the selected action.');
      return;
    }
    setHint(response.state?.currentStateReason || 'Perform the action manually on LinkedIn, then press Resume.');
    renderState(response.state || await S.getMeta());
  }

  async function selectTarget() {
    const mode = els.setPaginationMode.value;
    if (![C.PAGINATION_MODES.CLICK_LINK, C.PAGINATION_MODES.CLICK_BUTTON].includes(mode)) {
      setHint('Select Click link or Click button first.'); return;
    }
    const response = await sendToTab({ type: 'LX_PICK_TARGET', mode });
    if (!response?.ok) { setHint(response?.reason || 'Could not start target picker.'); return; }
    setHint('Picker active. Click the LinkedIn control you want to target, then reopen the extension.');
  }

  async function verifyTarget() {
    const settings = await S.getSettings();
    const response = await sendToTab({ type: 'LX_VERIFY_TARGET', mode: settings.paginationMode, selector: settings.paginationTargetSelector });
    if (!response?.ok) { setHint(response?.reason || 'Target verification failed.'); return; }
    const r = response.result;
    renderTargetStatus(settings, { pagination: r });
    setHint(r.ok ? `Target verified: ${r.text || r.selector || 'target found'}.` : 'Target not found on the current page.');
  }

  async function saveSettings() {
    const patch = {
      autoScroll: false,
      autoNextPage: false,
      autoResume: false,
      safetyMode: true,
      stopOnSecurityPrompt: true,
      autoSave: els.setAutoSave.checked,
      continueWhenPopupClosed: els.setContinueClosed.checked,
      autoDownload: els.setAutoDownload.checked,
      debugMode: els.setDebug.checked,
      paginationMode: els.setPaginationMode.value,
      retryCount: Number(els.setRetry.value),
      timeoutMs: Number(els.setTimeout.value),
      stableMs: Number(els.setStable.value),
      maxPages: Number(els.setMaxPages.value),
      actionDelayMinMs: Number(els.setActionDelayMin.value),
      actionDelayMaxMs: Number(els.setActionDelayMax.value),
      safetyCooldownMs: Number(els.setSafetyCooldown.value)
    };
    const saved = await S.saveSettings(patch);
    populateSettings(saved);
    await refreshTab();
    setHint('Settings saved. Automatic LinkedIn clicks/scrolling remain disabled by design.');
  }

  async function init() {
    if (initialized) return;
    initialized = true;
    populateSettings(await S.getSettings());
    await loadData();
    await refreshTab();

    els.settingsBtn.addEventListener('click', () => { els.settingsPanel.hidden = !els.settingsPanel.hidden; });
    els.startBtn.addEventListener('click', () => runCommand('LX_START'));
    els.pauseBtn.addEventListener('click', () => runCommand('LX_PAUSE'));
    els.resumeBtn.addEventListener('click', () => runCommand('LX_RESUME'));
    els.stopBtn.addEventListener('click', () => runCommand('LX_STOP'));
    els.resetRunBtn.addEventListener('click', async () => { if (confirm('Reset the saved run state? Collected leads will remain.')) await runCommand('LX_RESET_RUN'); });
    els.extractBtn.addEventListener('click', async () => {
      const response = await sendToTab({ type: 'LX_EXTRACT_PAGE' });
      if (!response?.ok) setHint(response?.reason || 'Current-page extraction failed.');
      else { setHint(`Found ${response.foundOnPage} rows: ${response.added} new, ${response.updated} updated, ${response.duplicates} duplicates.`); await loadData(); }
    });
    els.assistBtn.addEventListener('click', assistSelectedAction);
    els.selectTargetBtn.addEventListener('click', selectTarget);
    els.verifyTargetBtn.addEventListener('click', verifyTarget);
    els.setPaginationMode.addEventListener('change', async () => {
      const settings = await S.saveSettings({ paginationMode: els.setPaginationMode.value, paginationTargetSelector: '', paginationTargetLabel: '' });
      populateSettings(settings); renderTargetStatus(settings);
      setHint('Mode changed. The extension will only assist; you perform the LinkedIn action manually.');
    });
    els.clearBtn.addEventListener('click', async () => { if (!confirm('Clear all collected leads? This cannot be undone.')) return; await S.clearLeads(); await loadData(); });
    els.copyAllBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) { await window.LXExport.copyAll(leads); setHint(`Copied ${leads.length} leads.`); } });
    els.downloadCsvBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) window.LXExport.downloadCsv(leads); });
    els.downloadJsonBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) window.LXExport.downloadJson(leads, await S.getMeta()); });
    els.saveSettingsBtn.addEventListener('click', saveSettings);

    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local') return;
      if (changes.lx_meta) renderState(changes.lx_meta.newValue || {});
      if (changes.lx_leads) await loadData();
      if (changes.lx_settings) {
        const next = { ...C.DEFAULTS, ...(changes.lx_settings.newValue || {}) };
        populateSettings(next); renderTargetStatus(next);
      }
    });

    refreshTimer = window.setInterval(async () => {
      try {
        const meta = await S.getMeta();
        const tab = await getActiveTab();
        if (tab?.id === activeTabId) {
          const ping = await sendToTab({ type: 'LX_PING' });
          renderState(meta, ping);
          if (ping?.ok) renderTargetStatus(await S.getSettings(), ping);
        } else renderState(meta);
      } catch (_) {}
    }, 1200);
  }

  window.addEventListener('unload', () => { if (refreshTimer) clearInterval(refreshTimer); }, { once: true });
  document.addEventListener('DOMContentLoaded', init, { once: true });
})();
