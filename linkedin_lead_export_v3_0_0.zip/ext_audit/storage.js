/* storage.js — resilient local persistence and lead upsert store. */
(function attachStorage(root) {
  const C = root.LXConstants;
  const U = root.LX;
  const Logger = root.LXLogger || console;
  const KEYS = C.STORAGE_KEYS;
  const cache = {
    loaded: false,
    leads: [],
    byKey: new Map(),
    localWriteDepth: 0
  };

  function chromeGet(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(keys, (result) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve(result);
      });
    });
  }

  function chromeSet(value) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set(value, () => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve();
      });
    });
  }

  function chromeRemove(keys) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.remove(keys, () => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve();
      });
    });
  }

  async function getSettings() {
    const result = await chromeGet(KEYS.SETTINGS);
    return { ...C.DEFAULTS, ...(result[KEYS.SETTINGS] || {}) };
  }

  async function saveSettings(patch) {
    const current = await getSettings();
    const next = { ...current, ...(patch || {}) };
    await chromeSet({ [KEYS.SETTINGS]: next });
    return next;
  }

  function rebuildIndex() {
    cache.byKey.clear();
    cache.leads.forEach((lead, index) => {
      const key = U.leadKey(lead);
      if (key && !cache.byKey.has(key)) cache.byKey.set(key, index);
    });
  }

  async function loadLeads(force = false) {
    if (cache.loaded && !force) return cache.leads;
    const result = await chromeGet(KEYS.LEADS);
    const raw = Array.isArray(result[KEYS.LEADS]) ? result[KEYS.LEADS] : [];
    cache.leads = raw.map(U.normalizeLead);
    rebuildIndex();
    cache.loaded = true;
    return cache.leads;
  }

  async function getLeads() {
    return U.clone(await loadLeads());
  }

  async function getLeadCount() {
    await loadLeads();
    return cache.leads.length;
  }

  function mergeField(oldValue, newValue) {
    const oldText = String(oldValue ?? '').trim();
    const newText = String(newValue ?? '').trim();
    if (!newText) return oldValue || '';
    if (!oldText) return newValue;
    if (newText === oldText) return oldValue;
    if (newText.length > oldText.length + 8) return newValue;
    return oldValue;
  }

  function mergeLead(existing, incoming) {
    const merged = { ...existing };
    const fields = [
      'personName', 'jobTitle', 'companyName', 'location',
      'connectionDegree', 'about', 'yearsInRole', 'yearsInCompany',
      'personLinkedInUrl', 'companyLinkedInUrl', 'employeeCount'
    ];
    fields.forEach((key) => { merged[key] = mergeField(existing[key], incoming[key]); });
    merged.premium = !!(existing.premium || incoming.premium);
    merged.sourceRow = incoming.sourceRow || existing.sourceRow || 0;
    merged.capturedFromUrl = incoming.capturedFromUrl || existing.capturedFromUrl || '';
    merged.capturedAt = existing.capturedAt || incoming.capturedAt || new Date().toISOString();
    merged.lastSeenAt = incoming.capturedAt || existing.lastSeenAt || merged.capturedAt;
    merged.leadId = merged.leadId || incoming.leadId || U.extractLeadId(merged.personLinkedInUrl);
    merged.companyId = merged.companyId || incoming.companyId || U.extractCompanyId(merged.companyLinkedInUrl);
    return U.normalizeLead(merged);
  }

  async function persistLeads() {
    cache.localWriteDepth += 1;
    try {
      await chromeSet({ [KEYS.LEADS]: cache.leads });
    } finally {
      cache.localWriteDepth = Math.max(0, cache.localWriteDepth - 1);
    }
  }

  async function upsertLead(rawLead) {
    const incoming = U.normalizeLead(rawLead);
    if (!U.leadKey(incoming)) return { added: false, updated: false, lead: null };
    await loadLeads();
    const key = U.leadKey(incoming);
    const existingIndex = cache.byKey.get(key);
    if (existingIndex == null) {
      cache.leads.push(incoming);
      cache.byKey.set(key, cache.leads.length - 1);
      await persistLeads();
      return { added: true, updated: false, lead: incoming };
    }
    const current = cache.leads[existingIndex];
    const merged = mergeLead(current, incoming);
    const changed = JSON.stringify(merged) !== JSON.stringify(current);
    cache.leads[existingIndex] = merged;
    if (changed) await persistLeads();
    return { added: false, updated: changed, lead: merged };
  }

  async function mergeLeads(rawLeads) {
    await loadLeads();
    const result = { all: null, added: [], updated: [], duplicates: 0 };
    for (const rawLead of Array.isArray(rawLeads) ? rawLeads : []) {
      const upserted = await upsertLead(rawLead);
      if (!upserted.lead) continue;
      if (upserted.added) result.added.push(upserted.lead);
      else if (upserted.updated) result.updated.push(upserted.lead);
      else result.duplicates += 1;
    }
    result.all = U.clone(cache.leads);
    return result;
  }

  async function clearLeads() {
    await chromeRemove(KEYS.LEADS);
    cache.loaded = true;
    cache.leads = [];
    cache.byKey.clear();
  }

  async function getMeta() {
    const result = await chromeGet(KEYS.META);
    return result[KEYS.META] || {};
  }

  async function setMeta(patch) {
    const current = await getMeta();
    const next = { ...current, ...(patch || {}) };
    await chromeSet({ [KEYS.META]: next });
    return next;
  }

  async function clearMeta() {
    try { await chromeRemove(KEYS.META); } catch (error) { Logger.warning('Failed to clear metadata', error); }
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes[KEYS.LEADS] || cache.localWriteDepth > 0) return;
      cache.loaded = false;
      cache.leads = [];
      cache.byKey.clear();
    });
  } catch (_) {
    // The storage wrapper remains usable in test or restricted contexts.
  }

  root.LXStorage = {
    KEYS,
    DEFAULT_SETTINGS: C.DEFAULTS,
    getSettings,
    saveSettings,
    getLeads,
    getLeadCount,
    loadLeads,
    mergeLeads,
    upsertLead,
    clearLeads,
    getMeta,
    setMeta,
    clearMeta
  };
})(typeof window !== 'undefined' ? window : globalThis);
