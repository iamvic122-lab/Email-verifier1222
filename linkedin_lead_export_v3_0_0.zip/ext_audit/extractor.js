/* extractor.js — LinkedIn row discovery and field extraction. */
(function attachExtractor(root) {
  const U = root.LX;
  const SEL = root.LXSelectors;
  const Logger = root.LXLogger;

  const Extractor = {
    _activeResultSelector: null,
    _lastResultSelector: null,

    _q(node, selectors) {
      for (const selector of selectors || []) {
        try {
          const element = node && node.querySelector(selector);
          if (element) return element;
        } catch (_) {
          Logger.debug('Invalid selector ignored', selector);
        }
      }
      return null;
    },

    _text(element) {
      return element ? U.cleanText(element.textContent) : '';
    },

    _normalizeRowCandidate(row) {
      if (!row || row.nodeType !== 1) return null;
      return this._q(row, SEL.personLink) ? row : null;
    },

    _dedupeRows(rows) {
      const seen = new Set();
      const result = [];
      for (const row of rows || []) {
        const person = this._q(row, SEL.personLink);
        const href = person ? U.convertLeadUrl(person.getAttribute('href') || '') : '';
        const key = href || row;
        if (seen.has(key)) continue;
        seen.add(key);
        result.push(row);
      }
      return result;
    },

    findResultRows() {
      if (this._activeResultSelector) {
        try {
          const cached = Array.from(document.querySelectorAll(this._activeResultSelector))
            .map((node) => this._normalizeRowCandidate(node))
            .filter(Boolean);
          const dedupedCached = this._dedupeRows(cached);
          if (dedupedCached.length) {
            this._lastResultSelector = this._activeResultSelector;
            return dedupedCached;
          }
        } catch (_) {
          this._activeResultSelector = null;
        }
      }

      const scored = [];
      for (const selector of SEL.resultRow) {
        try {
          const nodes = Array.from(document.querySelectorAll(selector))
            .map((node) => this._normalizeRowCandidate(node))
            .filter(Boolean);
          const deduped = this._dedupeRows(nodes);
          if (deduped.length) scored.push({ selector, rows: deduped });
        } catch (_) {
          // Keep evaluating alternative selectors.
        }
      }
      if (scored.length) {
        scored.sort((a, b) => b.rows.length - a.rows.length);
        this._activeResultSelector = scored[0].selector;
        this._lastResultSelector = scored[0].selector;
        return scored[0].rows;
      }

      const fallback = new Set();
      document.querySelectorAll('a[href*="/sales/lead/"]').forEach((anchor) => {
        const row = anchor.closest('li') || anchor.closest('article') || anchor.closest('[role="listitem"]');
        if (row) fallback.add(row);
      });
      this._activeResultSelector = null;
      this._lastResultSelector = fallback.size ? 'fallback:a[href*=\"/sales/lead/\"]' : null;
      return this._dedupeRows(Array.from(fallback));
    },

    signature(rows = this.findResultRows()) {
      return rows.map((row) => {
        const person = this._q(row, SEL.personLink);
        return person ? U.convertLeadUrl(person.getAttribute('href') || '') : '';
      }).filter(Boolean).join('|');
    },

    rowSignature(row) {
      const person = this._q(row, SEL.personLink);
      return person ? U.convertLeadUrl(person.getAttribute('href') || '') : '';
    },

    hasBlockingLoader() {
      return SEL.loading.some((selector) => {
        try {
          return Array.from(document.querySelectorAll(selector)).some((element) => {
            const style = getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
          });
        } catch (_) {
          return false;
        }
      });
    },

    observationRoot() {
      const row = this.findResultRows()[0];
      return row ? (row.closest('ol, ul, main, section') || document.body) : document.body;
    },

    extractLead(row, index = 0) {
      if (!row) return null;
      const personA = this._q(row, SEL.personLink) || row.querySelector('a[href*="/sales/lead/"]');
      if (!personA) return null;

      const personLinkedInUrl = U.convertLeadUrl(personA.getAttribute('href') || '');
      if (!personLinkedInUrl) return null;

      let personName = this._text(this._q(row, SEL.personName)) || this._text(personA);
      let jobTitle = this._text(this._q(row, SEL.jobTitle));
      const companyA = this._q(row, SEL.companyLink);
      const companyName = this._text(this._q(row, SEL.companyName)) || this._text(companyA);
      const companyLinkedInUrl = companyA ? U.convertCompanyUrl(companyA.getAttribute('href') || '') : '';

      if (jobTitle) {
        jobTitle = jobTitle.split(/\d+\s*year|\d+\s*month|in role|in company/i)[0].replace(/[,·•]$/, '').trim();
      }

      if (jobTitle && companyName) {
        const marker = ` at ${companyName}`.toLowerCase();
        const indexAt = jobTitle.toLowerCase().lastIndexOf(marker);
        if (indexAt > 0) jobTitle = jobTitle.slice(0, indexAt).trim();
      }

      if (!jobTitle) {
        const candidates = Array.from(row.querySelectorAll('span, div'))
          .map((element) => this._text(element))
          .filter(Boolean)
          .filter((text) => text !== personName && text !== companyName && text.length < 120);
        const skip = /^(1st|2nd|3rd|3\+|connect|message|save|premium|open profile|view profile)$/i;
        jobTitle = candidates.find((text) => !skip.test(text) && !/^\d+\s*(year|month|employee)/i.test(text)) || '';
      }

      const rowText = this._text(row);
      const roleMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in role/i);
      const companyTenureMatch = rowText.match(/((?:\d+\s*years?\s*)?(?:\d+\s*months?)?)\s*in company/i);
      const yearsInRole = roleMatch ? U.cleanText(roleMatch[1]) : '';
      const yearsInCompany = companyTenureMatch ? U.cleanText(companyTenureMatch[1]) : '';

      let connectionDegree = this._text(this._q(row, SEL.connectionDegree));
      const degreeMatch = connectionDegree.match(/(1st|2nd|3rd|3\+|Out of network|Following|You)/i);
      if (degreeMatch) connectionDegree = degreeMatch[1];

      let about = this._text(this._q(row, SEL.about));
      if (!about) {
        const paragraph = row.querySelector('p');
        about = this._text(paragraph);
      }
      about = about.replace(/\s*…\s*Show more$/i, '').trim();

      let employeeCount = this._text(this._q(row, SEL.employeeCount));
      if (employeeCount.includes('·')) employeeCount = employeeCount.split('·')[0].trim();
      if (employeeCount && !/\d/.test(employeeCount)) employeeCount = '';

      return U.normalizeLead({
        personName,
        jobTitle,
        companyName,
        location: this._text(this._q(row, SEL.location)),
        employeeCount,
        connectionDegree,
        premium: !!this._q(row, SEL.premiumBadge),
        about,
        yearsInRole,
        yearsInCompany,
        personLinkedInUrl,
        companyLinkedInUrl,
        sourceRow: index + 1,
        leadId: U.extractLeadId(personLinkedInUrl),
        companyId: U.extractCompanyId(companyLinkedInUrl),
        capturedAt: new Date().toISOString(),
        capturedFromUrl: window.location.href
      });
    },

    extractAll(options = {}) {
      const rows = this.findResultRows();
      const retryCount = Math.max(1, Math.min(6, Number(options.retryCount) || 3));
      const leads = [];
      const seen = new Set();
      const failures = [];
      rows.forEach((row, index) => {
        let lead = null;
        let lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try {
            lead = this.extractLead(row, index);
            lastError = null;
            break;
          } catch (error) {
            lastError = error;
            Logger.warning('Row extraction retry', index + 1, attempt, error);
          }
        }
        if (lastError) {
          failures.push({ row: index + 1, message: lastError.message || 'Unknown extraction error', attempts: retryCount });
          Logger.error('Row extraction failed after retries', index + 1, lastError);
          return;
        }
        const key = lead ? U.leadKey(lead) : '';
        if (!lead || !key || seen.has(key)) {
          if (lead && key) Logger.debug('Duplicate row skipped', key);
          return;
        }
        seen.add(key);
        leads.push(lead);
      });
      return { leads, rowsFound: rows.length, failures, selector: this._lastResultSelector };
    }
  };

  root.LXExtractor = Extractor;
})(typeof window !== 'undefined' ? window : globalThis);
