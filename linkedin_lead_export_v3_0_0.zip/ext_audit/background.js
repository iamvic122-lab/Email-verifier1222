/* background.js — MV3 lifecycle only; long-running work stays in content context. */
chrome.runtime.onInstalled.addListener(async () => {
  try {
    const current = await chrome.storage.local.get('lx_settings');
    if (!current.lx_settings) {
      await chrome.storage.local.set({
        lx_settings: {
          autoDownload: false,
          darkMode: true,
          autoScroll: true,
          autoNextPage: true,
          autoSave: true,
          autoResume: true,
          continueWhenPopupClosed: true,
          humanMode: true,
          randomDelayMinMs: 250,
          randomDelayMaxMs: 900,
          scrollMinPx: 420,
          scrollMaxPx: 840,
          scrollPauseMinMs: 250,
          scrollPauseMaxMs: 800,
          retryCount: 3,
          timeoutMs: 15000,
          stableMs: 700,
          autoSaveMs: 30000,
          maxPages: 1000,
          maxScrollPasses: 80,
          pageChangeRetries: 3,
          debugMode: false
        }
      });
    }
  } catch (error) {
    console.error('[LX] Install initialization failed', error);
  }
});
