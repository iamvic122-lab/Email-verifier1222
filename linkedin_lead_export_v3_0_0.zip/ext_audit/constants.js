/*
 * constants.js — single source of truth for engine settings and states.
 */
(function attachConstants(root) {
  const Constants = {
    VERSION: '3.0.0',
    STORAGE_KEYS: {
      LEADS: 'lx_leads',
      SETTINGS: 'lx_settings',
      META: 'lx_meta'
    },
    STATES: Object.freeze({
      IDLE: 'IDLE',
      STARTING: 'STARTING',
      SCROLLING: 'SCROLLING',
      COLLECTING: 'COLLECTING',
      SAVING: 'SAVING',
      NEXT_PAGE: 'NEXT_PAGE',
      WAITING_PAGE: 'WAITING_PAGE',
      PAUSED: 'PAUSED',
      FINISHED: 'FINISHED',
      STOPPED: 'STOPPED',
      ERROR: 'ERROR'
    }),
    DEFAULTS: Object.freeze({
      autoDownload: false,
      darkMode: true,
      autoScroll: true,
      autoNextPage: true,
      autoSave: true,
      autoResume: true,
      continueWhenPopupClosed: true,
      humanMode: true,
      randomDelayMinMs: 250,
      randomDelayMaxMs: 900,
      scrollMinPx: 420,
      scrollMaxPx: 840,
      scrollPauseMinMs: 250,
      scrollPauseMaxMs: 800,
      retryCount: 3,
      timeoutMs: 15000,
      stableMs: 700,
      autoSaveMs: 30000,
      maxPages: 1000,
      maxScrollPasses: 80,
      pageChangeRetries: 3,
      debugMode: false
    }),
    LIMITS: Object.freeze({
      retryCount: { min: 1, max: 6 },
      timeoutMs: { min: 3000, max: 60000 },
      stableMs: { min: 250, max: 5000 },
      randomDelayMinMs: { min: 0, max: 10000 },
      randomDelayMaxMs: { min: 50, max: 15000 },
      scrollMinPx: { min: 100, max: 1500 },
      scrollMaxPx: { min: 150, max: 2500 },
      scrollPauseMinMs: { min: 0, max: 5000 },
      scrollPauseMaxMs: { min: 50, max: 10000 },
      autoSaveMs: { min: 10000, max: 120000 },
      maxPages: { min: 1, max: 5000 },
      maxScrollPasses: { min: 10, max: 500 }
    })
  };

  root.LXConstants = Constants;
})(typeof window !== 'undefined' ? window : globalThis);
