/* wait.js — mutation/condition driven async waiting with bounded fallbacks. */
(function attachWait(root) {
  const Logger = root.LXLogger || console;

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));
  }

  function waitForCondition(predicate, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 15000;
    const rootNode = options.root || document;
    const observeAttributes = options.observeAttributes !== false;
    const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : () => false;
    const startedAt = Date.now();

    return new Promise((resolve, reject) => {
      let settled = false;
      let observer = null;
      let fallbackTimer = null;
      let pollTimer = null;
      let settleTimer = null;

      const cleanup = () => {
        if (observer) observer.disconnect();
        if (fallbackTimer) clearTimeout(fallbackTimer);
        if (pollTimer) clearTimeout(pollTimer);
        if (settleTimer) clearTimeout(settleTimer);
      };

      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        cleanup();
        if (error) reject(error); else resolve(value);
      };

      const schedulePoll = () => {
        if (settled) return;
        if (pollTimer) clearTimeout(pollTimer);
        pollTimer = setTimeout(evaluate, Math.min(300, Math.max(75, timeoutMs / 80)));
      };

      const evaluate = () => {
        if (settled) return;
        if (shouldCancel()) {
          finish(new Error('Wait cancelled'));
          return;
        }
        try {
          const value = predicate();
          if (value) {
            finish(null, { value, waitedMs: Date.now() - startedAt });
            return;
          }
        } catch (_) {
          // Predicate is retried after DOM activity or bounded fallback polling.
        }
        schedulePoll();
      };

      try {
        observer = new MutationObserver(() => {
          if (settled) return;
          clearTimeout(settleTimer);
          settleTimer = setTimeout(evaluate, 0);
        });
        observer.observe(rootNode, {
          subtree: true,
          childList: true,
          attributes: observeAttributes,
          characterData: true
        });
      } catch (error) {
        Logger.warning('MutationObserver unavailable; using bounded predicate polling', error);
      }

      evaluate();
      fallbackTimer = setTimeout(() => {
        finish(new Error(`Wait timed out after ${timeoutMs}ms`));
      }, timeoutMs);
    });
  }

  function waitForMutation(rootNode, options = {}) {
    const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : 5000;
    const observeAttributes = options.observeAttributes !== false;
    return new Promise((resolve, reject) => {
      let done = false;
      const observer = new MutationObserver((mutations) => {
        if (done) return;
        done = true;
        observer.disconnect();
        clearTimeout(timer);
        resolve({ mutations });
      });
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        observer.disconnect();
        reject(new Error(`Mutation wait timed out after ${timeoutMs}ms`));
      }, timeoutMs);
      observer.observe(rootNode, {
        subtree: true,
        childList: true,
        attributes: observeAttributes,
        characterData: true
      });
    });
  }

  root.LXWait = { wait, waitForCondition, waitForMutation };
})(typeof window !== 'undefined' ? window : globalThis);
