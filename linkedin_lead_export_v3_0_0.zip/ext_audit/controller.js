/* controller.js — persistent state-machine orchestrator for the scraping run. */
(function attachController(root) {
  const C = root.LXConstants;
  const S = root.LXStorage;
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;
  const Extractor = root.LXExtractor;
  const Scroll = root.LXScroll;
  const Pagination = root.LXPagination;

  class Controller {
    constructor() {
      this.settings = { ...C.DEFAULTS };
      this.state = C.STATES.IDLE;
      this.meta = {};
      this.runPromise = null;
      this.pauseRequested = false;
      this.stopRequested = false;
      this.autoSaveTimer = null;
      this.startedAtMs = 0;
      this.lastProgressAt = 0;
    }

    async init() {
      this.settings = await S.getSettings();
      Logger.setDebug(this.settings.debugMode);
      this.meta = await S.getMeta();
      if (!this.meta.state) {
        await this._persist({ state: C.STATES.IDLE });
      }
      return this.getSnapshot();
    }

    getSnapshot() {
      return U.clone({
        state: this.state,
        settings: this.settings,
        ...this.meta
      });
    }

    async refreshSettings() {
      this.settings = await S.getSettings();
      Logger.setDebug(this.settings.debugMode);
      return this.settings;
    }

    _baseMeta() {
      const now = new Date().toISOString();
      return {
        state: this.state,
        currentUrl: window.location.href,
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        lastActivityAt: now,
        updatedAt: now
      };
    }

    async _persist(patch = {}) {
      this.meta = { ...this.meta, ...this._baseMeta(), ...patch };
      await S.setMeta(this.meta);
      return this.meta;
    }

    async _transition(nextState, patch = {}) {
      const allowed = C.STATES[nextState] ? nextState : C.STATES.ERROR;
      this.state = allowed;
      Logger.info('State →', allowed);
      await this._persist({ currentStateReason: patch.reason || '', ...patch });
      return this.state;
    }

    _getPageNumber() {
      try {
        const page = Number(new URL(window.location.href).searchParams.get('page'));
        return Number.isFinite(page) && page > 0 ? page : Number(this.meta.currentPage) || 1;
      } catch (_) {
        return Number(this.meta.currentPage) || 1;
      }
    }

    _shouldPause() {
      return this.pauseRequested || this.state === C.STATES.PAUSED;
    }

    _shouldStop() {
      return this.stopRequested;
    }

    _startAutoSave() {
      this._stopAutoSave();
      if (!this.settings.autoSave) return;
      const schedule = () => {
        this.autoSaveTimer = setTimeout(async () => {
          if (this.state === C.STATES.FINISHED || this.state === C.STATES.STOPPED || this.state === C.STATES.ERROR) return;
          try {
            await this._persist({ lastAutosaveAt: new Date().toISOString() });
          } catch (error) {
            Logger.warning('Autosave failed', error);
          }
          schedule();
        }, this.settings.autoSaveMs);
      };
      schedule();
    }

    _stopAutoSave() {
      if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }

    async start({ resume = true, currentPage = true } = {}) {
      if (this.runPromise) return this.getSnapshot();
      await this.refreshSettings();

      const existing = await S.getMeta();
      const sameSearch = existing.searchKey && existing.searchKey === U.searchKey(window.location.href);
      const resumable = [C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE, C.STATES.PAUSED, C.STATES.STOPPED].includes(existing.state);

      if (resume && this.settings.autoResume && sameSearch && resumable) {
        this.meta = existing;
        this.state = existing.state === C.STATES.PAUSED ? C.STATES.PAUSED : C.STATES.STARTING;
      } else {
        this.meta = {
          runId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          searchKey: U.searchKey(window.location.href),
          startedAt: new Date().toISOString(),
          pagesProcessed: 0,
          currentPage: currentPage ? this._getPageNumber() : 1,
          collectedThisRun: 0,
          duplicates: 0,
          errors: 0,
          visitedPages: [],
          lastError: '',
          debug: {}
        };
        this.state = C.STATES.STARTING;
      }

      this.pauseRequested = false;
      this.stopRequested = false;
      const currentLeadCount = await S.getLeadCount();
      this.meta.totalLeads = currentLeadCount;
      this.startedAtMs = Date.now();
      this.lastProgressAt = Date.now();
      await this._persist({ totalLeads: currentLeadCount });
      this._startAutoSave();
      this.runPromise = this._runLoop().finally(() => {
        this.runPromise = null;
      });
      return this.getSnapshot();
    }

    async pause() {
      this.pauseRequested = true;
      if (this.state !== C.STATES.FINISHED && this.state !== C.STATES.STOPPED) {
        this.state = C.STATES.PAUSED;
        await this._persist({ state: C.STATES.PAUSED, currentStateReason: 'Paused by user' });
      }
      return this.getSnapshot();
    }

    async resume() {
      this.pauseRequested = false;
      this.stopRequested = false;
      if (!this.runPromise) return this.start({ resume: true });
      if (this.state === C.STATES.PAUSED) {
        this.state = C.STATES.STARTING;
        await this._persist({ state: C.STATES.STARTING, currentStateReason: 'Resumed by user' });
      }
      return this.getSnapshot();
    }

    async stop() {
      this.stopRequested = true;
      this.pauseRequested = false;
      this._stopAutoSave();
      this.state = C.STATES.STOPPED;
      await this._persist({ state: C.STATES.STOPPED, currentStateReason: 'Stopped by user', stoppedAt: new Date().toISOString() });
      return this.getSnapshot();
    }

    async resetRun() {
      this.pauseRequested = false;
      this.stopRequested = true;
      this._stopAutoSave();
      this.runPromise = null;
      await S.setMeta({
        state: C.STATES.IDLE,
        currentStateReason: 'Run reset',
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        pagesProcessed: 0,
        collectedThisRun: 0,
        duplicates: 0,
        errors: 0,
        visitedPages: [],
        lastError: '',
        debug: {}
      });
      this.meta = await S.getMeta();
      this.state = C.STATES.IDLE;
      this.stopRequested = false;
      return this.getSnapshot();
    }

    async extractCurrentPage() {
      await this.refreshSettings();
      const readiness = await this.waitForReady();
      if (!readiness.ready) return { ok: false, reason: readiness.reason, readiness };
      return this.collectAndSavePage();
    }

    async waitForReady() {
      const stableMs = U.clamp(this.settings.stableMs, 250, 5000);
      const timeoutMs = U.clamp(this.settings.timeoutMs, 3000, 60000);
      const rootNode = Extractor.observationRoot();
      const startedAt = Date.now();
      let lastSignature = '';
      let stableSince = 0;
      let mutations = 0;
      let currentRows = 0;

      return new Promise((resolve) => {
        let observer = null;
        let stableTimer = null;
        let timeoutTimer = null;
        let finished = false;

        const cleanup = () => {
          if (observer) observer.disconnect();
          if (stableTimer) clearTimeout(stableTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
        };

        const finish = (result) => {
          if (finished) return;
          finished = true;
          cleanup();
          resolve({ ...result, waitedMs: Date.now() - startedAt, rowsVisible: currentRows, mutations });
        };

        const evaluate = () => {
          if (this._shouldStop()) {
            finish({ ready: false, reason: 'cancelled' });
            return;
          }
          currentRows = Extractor.findResultRows().length;
          const signature = Extractor.signature();
          const blocked = Extractor.hasBlockingLoader();
          if (signature !== lastSignature || blocked) {
            lastSignature = signature;
            stableSince = blocked || !signature ? 0 : Date.now();
            if (stableTimer) clearTimeout(stableTimer);
          }
          if (currentRows > 0 && signature && !blocked) {
            if (!stableSince) stableSince = Date.now();
            const remaining = stableMs - (Date.now() - stableSince);
            if (remaining <= 0) {
              finish({ ready: true, reason: 'stable' });
              return;
            }
            stableTimer = setTimeout(evaluate, remaining);
          }
        };

        try {
          observer = new MutationObserver((changes) => {
            mutations += changes.length;
            evaluate();
          });
          observer.observe(rootNode, { subtree: true, childList: true, attributes: true, characterData: true });
        } catch (error) {
          Logger.warning('Readiness observer unavailable', error);
        }

        evaluate();
        timeoutTimer = setTimeout(() => {
          finish({
            ready: false,
            reason: currentRows ? 'timeout-unstable' : 'timeout-no-results'
          });
        }, timeoutMs);
      });
    }

    async collectAndSavePage() {
      const extraction = Extractor.extractAll({ retryCount: this.settings.retryCount });
      await this._transition(C.STATES.SAVING, {
        currentPage: this._getPageNumber(),
        currentSelector: extraction.selector || 'resultRow/personLink',
        failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
        rowsFound: extraction.rowsFound,
        rowFailures: extraction.failures.length,
        debug: {
          currentSelector: extraction.selector || 'resultRow/personLink',
        failedSelector: extraction.rowsFound ? '' : (extraction.selector || 'resultRow'),
          rowsFound: extraction.rowsFound,
          failedRows: extraction.failures
        }
      });

      let added = 0;
      let updated = 0;
      let duplicates = 0;
      const retryCount = Math.max(1, Math.min(6, Number(this.settings.retryCount) || 3));

      for (const lead of extraction.leads) {
        if (this._shouldStop()) break;
        while (this._shouldPause()) {
          this.state = C.STATES.PAUSED;
          await this._persist({ state: C.STATES.PAUSED, currentStateReason: 'Paused by user' });
          if (this._shouldStop()) return { ok: false, stopped: true };
          await Wait.wait(250);
        }

        let saved = false;
        let lastError = null;
        for (let attempt = 1; attempt <= retryCount; attempt += 1) {
          try {
            this.state = C.STATES.SAVING;
            await this._persist({
              retryCount: attempt,
              debug: { currentSelector: 'storage.upsertLead', retryCount: attempt, leadKey: U.leadKey(lead) }
            });
            const result = await S.upsertLead(lead);
            if (result.added) added += 1;
            else if (result.updated) updated += 1;
            else duplicates += 1;
            saved = true;
            this.lastProgressAt = Date.now();
            const totalLeads = await S.getLeadCount();
            await this._persist({
              totalLeads,
              collectedThisRun: Number(this.meta.collectedThisRun || 0) + (result.added ? 1 : 0),
              duplicates: Number(this.meta.duplicates || 0) + (!result.added && !result.updated ? 1 : 0),
              lastSavedLead: U.leadKey(lead),
              lastSavedAt: new Date().toISOString()
            });
            break;
          } catch (error) {
            lastError = error;
            Logger.warning('Lead save attempt failed', attempt, error);
            if (attempt < retryCount) await Wait.wait(200);
          }
        }

        if (!saved) {
          this.meta.errors = Number(this.meta.errors || 0) + 1;
          await this._persist({
            errors: this.meta.errors,
            lastError: lastError?.message || 'Lead save failed',
            debug: { currentSelector: 'storage.upsertLead', failedLead: U.leadKey(lead), retryCount }
          });
          Logger.error('Lead skipped after retries', lastError);
        }
      }

      const nextMeta = {
        pagesProcessed: Number(this.meta.pagesProcessed || 0) + 1,
        lastPageSavedAt: new Date().toISOString(),
        lastPageStats: { rowsFound: extraction.rowsFound, added, updated, duplicates, rowFailures: extraction.failures.length }
      };
      await this._persist(nextMeta);
      if (this.settings.autoDownload && extraction.leads.length && root.LXExport?.downloadCsv) {
        try {
          root.LXExport.downloadCsv(await S.getLeads());
        } catch (error) {
          Logger.warning('Auto-download failed', error);
        }
      }
      return { ok: !this._shouldStop(), extraction, added, updated, duplicates };
    }

    async _runLoop() {
      try {
        const pageGuard = await this._validateSearchContext();
        if (!pageGuard.ok) {
          await this._transition(C.STATES.ERROR, { lastError: pageGuard.reason, errors: Number(this.meta.errors || 0) + 1 });
          this._stopAutoSave();
          return;
        }

        const maxPages = Math.max(1, Number(this.settings.maxPages) || 1000);
        const visited = new Set(Array.isArray(this.meta.visitedPages) ? this.meta.visitedPages : []);

        while (!this._shouldStop()) {
          if (this._shouldPause()) {
            await this.pause();
            this._stopAutoSave();
            return;
          }

          if (Number(this.meta.pagesProcessed || 0) >= maxPages) {
            await this._transition(C.STATES.FINISHED, { currentStateReason: 'Maximum page limit reached' });
            break;
          }

          await this._transition(C.STATES.STARTING, { currentPage: this._getPageNumber() });
          const ready = await this.waitForReady();
          await this._persist({ lastReadiness: ready, scrollProgress: 0 });
          if (!ready.ready) {
            if (ready.reason === 'cancelled') return;
            throw new Error(ready.reason === 'timeout-no-results'
              ? 'No lead rows became available before timeout.'
              : 'Result rows did not stabilize before timeout.');
          }

          if (this.settings.autoScroll) {
            await this._transition(C.STATES.SCROLLING, { currentPage: this._getPageNumber() });
            const container = Scroll.findContainer(Extractor.findResultRows());
            if (this.meta.resumePageKey === U.pageKey(window.location.href) && Number.isFinite(Number(this.meta.scrollTop))) {
              Scroll.restorePosition(container, Number(this.meta.scrollTop));
            }
            const scrollResult = await Scroll.scrollToBottom({
              findRows: () => Extractor.findResultRows(),
              settings: this.settings,
              shouldPause: () => this._shouldPause() || this._shouldStop(),
              onProgress: async (progress) => {
                await this._persist({ scrollProgress: progress.progress, scrollTop: progress.scrollTop, resumePageKey: U.pageKey(window.location.href) });
              }
            });
            await this._persist({ scrollProgress: scrollResult.progress, scrollTop: scrollResult.scrollTop, resumePageKey: U.pageKey(window.location.href) });
            if (scrollResult.paused) {
              await this.pause();
              this._stopAutoSave();
              return;
            }
            const postScrollReady = await this.waitForReady();
            if (postScrollReady.ready) await this._persist({ lastReadiness: postScrollReady });
          }

          await this._transition(C.STATES.COLLECTING, { currentPage: this._getPageNumber() });
          const descriptor = Pagination.getPageDescriptor();
          const pageId = `${descriptor.pageKey}|${descriptor.signature}`;
          if (visited.has(pageId)) {
            throw new Error('Pagination loop detected: this page signature was already processed.');
          }
          visited.add(pageId);
          await this._persist({ visitedPages: Array.from(visited).slice(-maxPages) });

          const result = await this.collectAndSavePage();
          if (!result.ok || this._shouldStop()) {
            await this.stop();
            return;
          }

          if (!this.settings.autoNextPage || !Pagination.hasNext()) {
            await this._transition(C.STATES.FINISHED, { currentStateReason: 'No next page available' });
            break;
          }

          await this._transition(C.STATES.NEXT_PAGE, { currentPage: this._getPageNumber() });
          const previous = Pagination.getPageDescriptor();
          const next = await Pagination.clickNextWithRetry(previous, this.settings, () => this._shouldStop() || this._shouldPause());
          if (!next.ok) throw new Error(`Next page failed: ${next.reason}`);

          const urlPage = this._getPageNumber();
          const nextPageNumber = Math.max(urlPage, Number(this.meta.currentPage || 1) + 1);
          await this._transition(C.STATES.WAITING_PAGE, {
            currentPage: nextPageNumber,
            currentUrl: next.descriptor.url,
            pageChangeWaitMs: next.waitedMs,
            scrollTop: 0,
            scrollProgress: 0,
            resumePageKey: U.pageKey(next.descriptor.url)
          });

          const newSearch = U.searchKey(window.location.href);
          if (newSearch !== this.meta.searchKey) {
            throw new Error('Search context changed during pagination; run stopped to prevent mixing datasets.');
          }
        }

        if (this.state !== C.STATES.PAUSED && this.state !== C.STATES.ERROR) {
          await this._persist({ finishedAt: new Date().toISOString() });
        }
      } catch (error) {
        Logger.error('Controller failed', error);
        const errors = Number(this.meta.errors || 0) + 1;
        await this._transition(C.STATES.ERROR, {
          lastError: error?.message || 'Unknown controller error',
          errors,
          debug: {
            currentState: this.state,
            currentUrl: window.location.href,
            lastError: error?.message || 'Unknown controller error'
          }
        });
      } finally {
        this._stopAutoSave();
      }
    }

    async _validateSearchContext() {
      const path = window.location.pathname;
      if (!/\/sales\/(search|lists|people)/i.test(path)) {
        return { ok: false, reason: 'Open a Sales Navigator search/list/people view before starting.' };
      }
      const existing = await S.getMeta();
      if (existing.searchKey && existing.searchKey !== U.searchKey(window.location.href) && existing.state && ![C.STATES.IDLE, C.STATES.STOPPED, C.STATES.FINISHED].includes(existing.state)) {
        return { ok: false, reason: 'The current search does not match the saved run. Reset the run before starting a different search.' };
      }
      return { ok: true };
    }
  }

  root.LXController = new Controller();
})(typeof window !== 'undefined' ? window : globalThis);
