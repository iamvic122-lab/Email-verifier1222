# Sales Navigator Lead Export — v3.0.0

Production-grade MV3 extension for extracting visible Sales Navigator lead records and optionally continuing through lazy-loaded result pages with a persistent state machine.

## Engine

The long-running controller lives in the LinkedIn content context instead of the popup. Closing the popup no longer terminates an active run. Run metadata is persisted to `chrome.storage.local`, so the extension can recover after a tab reload or browser restart when Resume is enabled.

### State machine

`IDLE → STARTING → SCROLLING → COLLECTING → SAVING → NEXT_PAGE → WAITING_PAGE → COLLECTING → FINISHED`

Additional control states are `PAUSED`, `STOPPED`, and `ERROR`.

### Pagination

The engine keeps all Next selectors in `selectors.js`, verifies disabled state, clicks only an active control, and waits for a real page-key or result-signature change. Repeated page signatures stop the run as a pagination-loop safeguard.

### Lazy loading

The scroll engine identifies the actual scrollable result container, advances in variable increments, waits for DOM/layout progress, records scroll progress, and stops after repeated no-growth observations or a configured maximum pass count.

### Waiting

Result readiness is mutation-driven. A `MutationObserver` watches the result area and a bounded timeout is the fallback. No long fixed sleep is used as the primary synchronization mechanism.

### Persistence

Leads are normalized and upserted using a canonical profile URL / lead ID key. Each successful lead save persists immediately. Run metadata is also autosaved on a single rescheduled timer at the configured interval.

### Recovery

Failed lead saves retry up to the configured retry count. A failed individual lead is skipped instead of crashing the full run. Controller failures move to `ERROR` and preserve enough metadata for diagnosis.

### Exports

CSV, JSON, and clipboard exports are local browser operations. No extension code sends extracted data to a remote service.

## Installation

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click **Load unpacked**.
4. Select this folder.
5. Open a Sales Navigator people search.
6. Open the extension popup and click **Start**.

## Files

| File | Responsibility |
|---|---|
| `constants.js` | States, defaults, bounds |
| `logger.js` | Structured logging |
| `selectors.js` | All LinkedIn selectors |
| `utils.js` | URL/text normalization, keys, export schema |
| `wait.js` | Mutation/condition waits |
| `storage.js` | Persistent lead and run storage |
| `extractor.js` | Result discovery and field extraction |
| `scroll.js` | Lazy-load scroll engine |
| `pagination.js` | Next-page discovery and verification |
| `controller.js` | State machine and orchestration |
| `content.js` | Runtime message bridge and auto-resume boot |
| `popup.js/html/css` | Live control panel |
| `export.js` | CSV/JSON/clipboard |
| `background.js` | MV3 lifecycle/default initialization |

## Debugging

Enable **Debug Mode** in Settings. The persisted run metadata exposes the current state, selector context, failed rows, retry count, last error, page signature, and pagination progress in the popup state model and browser console.
