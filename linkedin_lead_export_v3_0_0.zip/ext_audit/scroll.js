/* scroll.js — variable-speed lazy-load scrolling without fixed loops. */
(function attachScroll(root) {
  const U = root.LX;
  const C = root.LXConstants;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;

  function isScrollable(el) {
    if (!el || el.nodeType !== 1) return false;
    const style = getComputedStyle(el);
    const overflowY = style.overflowY;
    return (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && el.scrollHeight > el.clientHeight + 40;
  }

  function findContainer(rows) {
    const sample = rows && rows[0];
    let node = sample ? sample.parentElement : null;
    while (node && node !== document.body) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function progressOf(container) {
    const max = Math.max(1, container.scrollHeight - container.clientHeight);
    const top = Number(container.scrollTop || 0);
    return Math.min(100, Math.round((top / max) * 100));
  }

  function atBottom(container, threshold = 32) {
    return container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
  }

  function restorePosition(container, scrollTop) {
    const value = Number(scrollTop);
    if (!container || !Number.isFinite(value) || value < 0) return false;
    const max = Math.max(0, container.scrollHeight - container.clientHeight);
    container.scrollTop = Math.min(value, max);
    return true;
  }

  async function scrollToBottom({ findRows, settings, shouldPause, onProgress }) {
    const firstRows = findRows();
    const container = findContainer(firstRows);
    let passes = 0;
    let noGrowth = 0;
    let lastHeight = container.scrollHeight;
    let lastTop = container.scrollTop;
    let lastSignature = '';

    while (passes < settings.maxScrollPasses) {
      if (shouldPause()) return { paused: true, progress: progressOf(container), passes };
      passes += 1;

      if (atBottom(container)) {
        try {
          await Wait.waitForCondition(() => {
            const rows = findRows();
            const signature = rows.map((row) => {
              const a = row.querySelector('a[href*="/sales/lead/"]');
              return a ? a.getAttribute('href') || '' : '';
            }).join('|');
            return signature === lastSignature && container.scrollHeight === lastHeight;
          }, { root: container, timeoutMs: 1200 });
        } catch (_) {
          // Bottom-of-list timeout is a normal termination signal.
        }
        const currentHeight = container.scrollHeight;
        const currentTop = container.scrollTop;
        const currentSignature = findRows().map((row) => {
          const a = row.querySelector('a[href*="/sales/lead/"]');
          return a ? a.getAttribute('href') || '' : '';
        }).join('|');
        if (currentHeight === lastHeight && currentTop === lastTop && currentSignature === lastSignature) noGrowth += 1;
        else noGrowth = 0;
        lastHeight = currentHeight;
        lastTop = currentTop;
        lastSignature = currentSignature;
        if (noGrowth >= 2) break;
      }

      const distance = U.randomBetween(settings.scrollMinPx, settings.scrollMaxPx);
      const beforeTop = container.scrollTop;
      const beforeHeight = container.scrollHeight;
      container.scrollBy({ top: distance, left: 0, behavior: settings.humanMode ? 'smooth' : 'auto' });

      try {
        await Wait.waitForCondition(() => {
          const moved = Math.abs(container.scrollTop - beforeTop) > 8;
          const grew = container.scrollHeight > beforeHeight;
          return moved || grew || atBottom(container);
        }, { root: container, timeoutMs: 2200 });
      } catch (_) {
        // Bounded fallback: continue and let the next pass decide whether progress occurred.
      }

      if (settings.humanMode) {
        const pause = U.randomBetween(settings.scrollPauseMinMs, settings.scrollPauseMaxMs);
        if (pause > 0) await Wait.wait(pause);
      }

      Logger.debug('Scroll pass', passes, 'progress', progressOf(container));
      if (typeof onProgress === 'function') {
        await onProgress({ progress: progressOf(container), scrollTop: container.scrollTop, scrollHeight: container.scrollHeight, passes });
      }
    }

    if (passes >= settings.maxScrollPasses) {
      Logger.warning('Maximum scroll passes reached', settings.maxScrollPasses);
    }
    return { paused: false, progress: progressOf(container), scrollTop: container.scrollTop, scrollHeight: container.scrollHeight, passes };
  }

  root.LXScroll = { findContainer, restorePosition, progressOf, atBottom, scrollToBottom };
})(typeof window !== 'undefined' ? window : globalThis);
