/* pagination.js — reliable Next detection, click, and page-change verification. */
(function attachPagination(root) {
  const SEL = root.LXSelectors;
  const Wait = root.LXWait;
  const Logger = root.LXLogger;
  const Extractor = root.LXExtractor;
  const U = root.LX;

  function isVisible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function isDisabled(element) {
    if (!element) return true;
    return element.disabled || element.getAttribute('aria-disabled') === 'true' || element.classList.contains('disabled') || !isVisible(element);
  }

  function findNext() {
    for (const selector of [...SEL.nextButton, ...SEL.nextLink]) {
      try {
        const candidates = Array.from(document.querySelectorAll(selector));
        const active = candidates.find((element) => isVisible(element) && !isDisabled(element));
        if (active) return active;
      } catch (_) {
        // Keep trying alternate selectors.
      }
    }

    const textCandidates = Array.from(document.querySelectorAll('button, a')).filter(isVisible);
    return textCandidates.find((element) => {
      const text = U.cleanText(element.textContent);
      const label = U.cleanText(element.getAttribute('aria-label') || element.title || '');
      const combined = `${text} ${label}`.toLowerCase();
      return /\bnext\b/.test(combined) && !isDisabled(element);
    }) || null;
  }

  function hasNext() {
    return !!findNext();
  }

  function getPageDescriptor() {
    return {
      url: window.location.href,
      pageKey: U.pageKey(window.location.href),
      searchKey: U.searchKey(window.location.href),
      signature: Extractor.signature()
    };
  }

  async function clickAndWaitForChange(previous, settings, shouldCancel = () => false) {
    const next = findNext();
    if (!next) return { ok: false, reason: 'next-not-found' };

    const rootNode = Extractor.observationRoot();
    next.scrollIntoView({ block: 'center', inline: 'nearest' });
    next.click();
    Logger.info('Next page clicked');

    try {
      const result = await Wait.waitForCondition(() => {
        const current = getPageDescriptor();
        return current.pageKey !== previous.pageKey || current.signature !== previous.signature;
      }, { root: rootNode, timeoutMs: settings.timeoutMs, shouldCancel });
      return { ok: true, descriptor: getPageDescriptor(), waitedMs: result.waitedMs };
    } catch (error) {
      return { ok: false, reason: error.message || 'page-change-timeout' };
    }
  }

  async function clickNextWithRetry(previous, settings, shouldCancel = () => false) {
    let lastFailure = '';
    for (let attempt = 1; attempt <= settings.pageChangeRetries; attempt += 1) {
      if (attempt > 1) {
        try {
          await Wait.waitForCondition(() => {
            const button = findNext();
            return !!button && !isDisabled(button);
          }, { root: document.body, timeoutMs: settings.timeoutMs, shouldCancel });
        } catch (_) {
          // Continue to retry and report the final failure.
        }
      }
      const result = await clickAndWaitForChange(previous, settings, shouldCancel);
      if (result.ok) return { ...result, attempt };
      lastFailure = result.reason || 'unknown-pagination-failure';
      Logger.warning('Pagination attempt failed', attempt, lastFailure);
    }
    return { ok: false, reason: lastFailure || 'pagination-failed' };
  }

  root.LXPagination = { findNext, hasNext, getPageDescriptor, clickNextWithRetry };
})(typeof window !== 'undefined' ? window : globalThis);
