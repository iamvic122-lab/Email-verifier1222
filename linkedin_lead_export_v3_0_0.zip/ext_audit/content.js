/* content.js — message bridge + lifecycle for the persistent controller. */
(function boot() {
  if (window.__LX_CONTENT_BOOTED__) return;
  window.__LX_CONTENT_BOOTED__ = true;

  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const Logger = window.LXLogger;
  const E = window.LXExtractor;
  const Controller = window.LXController;
  const Pagination = window.LXPagination;

  async function bootController() {
    try {
      await Controller.init();
      const settings = await S.getSettings();
      Logger.setDebug(settings.debugMode);
      const meta = await S.getMeta();
      const sameSearch = meta.searchKey === U.searchKey(window.location.href);
      const resumable = [
        C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE
      ].includes(meta.state);
      if (settings.autoResume && sameSearch && resumable) {
        Logger.info('Resuming saved run', meta.runId || 'unknown');
        await Controller.start({ resume: true });
      }
    } catch (error) {
      Logger.error('Controller boot failed', error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    (async () => {
      try {
        switch (message.type) {
          case 'LX_PING': {
            sendResponse({
              ok: true,
              url: window.location.href,
              onSearch: /\/sales\/(search|lists|people)/i.test(window.location.pathname),
              rowsVisible: E.findResultRows().length,
              loading: E.hasBlockingLoader(),
              state: (await S.getMeta()).state || C.STATES.IDLE
            });
            return;
          }
          case 'LX_GET_STATE':
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_START':
            await Controller.start({ resume: true });
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_PAUSE':
            await Controller.pause();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESUME':
            await Controller.resume();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_STOP':
            await Controller.stop();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESET_RUN':
            await Controller.resetRun();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_EXTRACT_PAGE': {
            const result = await Controller.extractCurrentPage();
            if (!result.ok) {
              sendResponse({ ok: false, reason: result.reason || 'Extraction failed', readiness: result.readiness });
              return;
            }
            const leads = await S.getLeads();
            sendResponse({
              ok: true,
              foundOnPage: result.extraction.leads.length,
              added: result.added,
              updated: result.updated,
              duplicates: result.duplicates,
              totalLeads: leads.length,
              leads,
              readiness: Controller.meta.lastReadiness || null
            });
            return;
          }
          case 'LX_GET_NEXT':
            sendResponse({ ok: true, hasNext: Pagination.hasNext() });
            return;
          default:
            sendResponse({ ok: false, reason: 'Unknown message' });
        }
      } catch (error) {
        Logger.error('Message operation failed', message.type, error);
        sendResponse({ ok: false, reason: error?.message || 'Operation failed' });
      }
    })();

    return true;
  });

  bootController();
  Logger.info('Content controller ready', window.location.href);
})();
