/* selectors.js — all LinkedIn DOM selectors live here. */
(function attachSelectors(root) {
  root.LXSelectors = Object.freeze({
    resultRow: [
      'li.artdeco-list__item[data-x-search-result="LEAD"]',
      'li[data-x-search-result="LEAD"]',
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'li.artdeco-list__item.pl3.pv3'
    ],
    personLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a.ember-view[href*="/sales/lead/"]'
    ],
    personName: [
      '[data-anonymize="person-name"]',
      'span[data-anonymize="person-name"]',
      '.artdeco-entity-lockup__title a',
      '.artdeco-entity-lockup__title span'
    ],
    jobTitle: [
      '[data-anonymize="title"]',
      '[data-anonymize="job-title"]',
      '.artdeco-entity-lockup__subtitle span[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle'
    ],
    companyLink: [
      'a[data-anonymize="company-name"]',
      'a[href*="/sales/company/"]'
    ],
    companyName: [
      '[data-anonymize="company-name"]',
      'a[data-anonymize="company-name"]'
    ],
    location: [
      '[data-anonymize="location"]',
      '.artdeco-entity-lockup__caption span[data-anonymize="location"]'
    ],
    employeeCount: [
      '[data-anonymize="company-size"]',
      '.artdeco-entity-lockup__metadata span:nth-child(1)'
    ],
    connectionDegree: [
      '.artdeco-entity-lockup__degree',
      'span.artdeco-entity-lockup__degree',
      '[data-test-connection-degree]'
    ],
    premiumBadge: [
      'li-icon[type="linkedin-premium-gold-icon"]',
      'svg[data-test-icon="premium-app-medium"]',
      '.premium-icon',
      'img[alt*="Premium"]'
    ],
    about: [
      '[data-anonymize="person-blurb"]',
      '.result-lockup__highlight-keyword',
      '.artdeco-entity-lockup__content p'
    ],
    loading: [
      '[aria-busy="true"]',
      '[role="progressbar"]',
      '.artdeco-loader',
      '.search-results-container .loader'
    ],
    nextButton: [
      'button[aria-label*="Next"]',
      'button[aria-label*="next"]',
      'button[data-test-pagination-next]',
      'button.artdeco-pagination__button--next',
      'button[title*="Next"]',
      'button[title*="next"]'
    ],
    nextLink: [
      'a[aria-label*="Next"]',
      'a[aria-label*="next"]',
      'a[data-test-pagination-next]',
      'a.artdeco-pagination__link--next'
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
