# Sales Navigator Lead Export — v3.1.0

Production MV3 extension for extracting visible Sales Navigator lead records with persistent run state, resumable pagination, selectable load-more strategies, retry/recovery and conservative account-safety guards.

## Action to load more items

The popup now includes the same four operating modes:

- **None** — collect the current result view only.
- **Scroll down to load more items** — progressively scroll the result container until no additional records appear.
- **Click link to navigate to next page** — verify and click a Next link, wait for a real page/result change, then continue.
- **Click button to load more items on same page** — repeatedly click a Load more button and wait for result growth before continuing.

For link/button modes, **Select** starts a user-driven picker on the page. The picker stores a stable selector when possible. **Verify** checks whether the stored selector or auto-detected control is available on the current page.

## Pagination timeout fix

Page transitions are now observed from `document.body` instead of only the old result container. This matters for SPA navigation because LinkedIn can replace or detach the original result subtree during a page change. The wait engine also checks URL/page-key changes and result-signature changes, with bounded polling only as fallback.

The default synchronization timeout is 30 seconds rather than 15 seconds, while the wait remains mutation-driven.

## State machine

`IDLE → STARTING → SCROLLING → COLLECTING → SAVING → NEXT_PAGE → WAITING_PAGE → COLLECTING → FINISHED`

Control states remain `PAUSED`, `STOPPED` and `ERROR`.

## Safety behavior

The extension does not attempt to bypass CAPTCHA, checkpoints, identity verification, rate limits or other platform safeguards. Safety mode uses conservative action pacing, a configurable action-rate ceiling, and stops when visible verification/restriction signals are detected.

No software setting can guarantee that a third-party platform will never restrict an account. The safe behavior is to stop rather than continue through a detected security challenge.

## Persistence and resume

Leads are stored locally in `chrome.storage.local` and upserted by canonical LinkedIn profile URL/lead ID. Run metadata is checkpointed after lead saves, page completion, scroll progress and the autosave interval. New content-script instances can resume the active run after a page navigation or browser restart when Resume is enabled.

## Files

| File | Responsibility |
|---|---|
| `constants.js` | States, modes, defaults, bounds |
| `logger.js` | Structured logging |
| `selectors.js` | LinkedIn DOM selectors |
| `utils.js` | Normalization, IDs, stable selector generation, export helpers |
| `safety.js` | Security-signal detection and conservative pacing |
| `wait.js` | Mutation/condition waits |
| `storage.js` | Persistent lead/meta/settings store with serialized writes |
| `extractor.js` | Cached result discovery and field extraction |
| `scroll.js` | Lazy-load scrolling |
| `pagination.js` | Next/load-more discovery, clicking and verification |
| `picker.js` | User-driven pagination target selection |
| `controller.js` | Persistent state machine and orchestration |
| `content.js` | Runtime message bridge and resume boot |
| `popup.*` | Control panel and settings |
| `export.js` | CSV/JSON/clipboard export |
| `background.js` | MV3 lifecycle/default initialization |
