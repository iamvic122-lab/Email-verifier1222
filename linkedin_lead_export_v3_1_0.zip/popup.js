/* popup.js — live control panel; engine execution remains in the content controller. */
(function popup() {
  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const E = window.LXExport;

  const els = {
    settingsBtn: document.getElementById('settingsBtn'),
    settingsPanel: document.getElementById('settingsPanel'),
    statusPill: document.getElementById('statusPill'),
    statusHint: document.getElementById('statusHint'),
    totalCount: document.getElementById('totalCount'),
    pageCount: document.getElementById('pageCount'),
    duplicateCount: document.getElementById('duplicateCount'),
    errorCount: document.getElementById('errorCount'),
    speedValue: document.getElementById('speedValue'),
    etaValue: document.getElementById('etaValue'),
    progressBar: document.getElementById('progressBar'),
    startBtn: document.getElementById('startBtn'),
    pauseBtn: document.getElementById('pauseBtn'),
    resumeBtn: document.getElementById('resumeBtn'),
    stopBtn: document.getElementById('stopBtn'),
    extractBtn: document.getElementById('extractBtn'),
    resetRunBtn: document.getElementById('resetRunBtn'),
    clearBtn: document.getElementById('clearBtn'),
    tableRowCount: document.getElementById('tableRowCount'),
    leadTableHead: document.getElementById('leadTableHead'),
    leadTableBody: document.getElementById('leadTableBody'),
    leadTableEmpty: document.getElementById('leadTableEmpty'),
    copyAllBtn: document.getElementById('copyAllBtn'),
    downloadCsvBtn: document.getElementById('downloadCsvBtn'),
    downloadJsonBtn: document.getElementById('downloadJsonBtn'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    urlIndicator: document.getElementById('urlIndicator'),
    setPaginationMode: document.getElementById('setPaginationMode'),
    selectTargetBtn: document.getElementById('selectTargetBtn'),
    verifyTargetBtn: document.getElementById('verifyTargetBtn'),
    targetStatus: document.getElementById('targetStatus'),
    setAutoScroll: document.getElementById('setAutoScroll'),
    setAutoNext: document.getElementById('setAutoNext'),
    setAutoSave: document.getElementById('setAutoSave'),
    setAutoResume: document.getElementById('setAutoResume'),
    setContinueClosed: document.getElementById('setContinueClosed'),
    setHumanMode: document.getElementById('setHumanMode'),
    setAutoDownload: document.getElementById('setAutoDownload'),
    setSafetyMode: document.getElementById('setSafetyMode'),
    setStopOnSecurity: document.getElementById('setStopOnSecurity'),
    setDebug: document.getElementById('setDebug'),
    setScrollMin: document.getElementById('setScrollMin'),
    setScrollMax: document.getElementById('setScrollMax'),
    setRetry: document.getElementById('setRetry'),
    setTimeout: document.getElementById('setTimeout'),
    setStable: document.getElementById('setStable'),
    setMaxPages: document.getElementById('setMaxPages'),
    setActionDelayMin: document.getElementById('setActionDelayMin'),
    setActionDelayMax: document.getElementById('setActionDelayMax'),
    setActionsPerMinute: document.getElementById('setActionsPerMinute')
  };

  let activeTabId = null;
  let refreshTimer = null;

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs?.[0] || null;
  }

  async function sendToTab(message) {
    if (!activeTabId) return null;
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(activeTabId, message, (response) => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response || null);
      });
    });
  }

  async function ensureContent(tab) {
    if (!tab?.id || !tab.url || !/linkedin\.com\/sales\//i.test(tab.url)) return null;
    let ping = await sendToTab({ type: 'LX_PING' });
    if (ping?.ok) return ping;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [
          'constants.js', 'logger.js', 'selectors.js', 'utils.js', 'safety.js',
          'wait.js', 'storage.js', 'extractor.js', 'scroll.js', 'pagination.js',
          'picker.js', 'export.js', 'controller.js', 'content.js'
        ]
      });
    } catch (_) {
      return null;
    }
    ping = await sendToTab({ type: 'LX_PING' });
    return ping?.ok ? ping : null;
  }

  async function refreshTab() {
    const tab = await getActiveTab();
    activeTabId = tab?.id || null;
    const ping = await ensureContent(tab);
    if (!tab?.url) {
      els.urlIndicator.textContent = '—';
      setHint('Open a Sales Navigator people search.');
      return;
    }
    try { els.urlIndicator.textContent = new URL(tab.url).pathname.slice(0, 52); }
    catch (_) { els.urlIndicator.textContent = tab.url.slice(0, 52); }

    if (!ping) {
      setHint('Open a Sales Navigator search page to use the engine.');
      return;
    }
    const meta = await S.getMeta();
    renderState(meta, ping);
    renderTargetStatus(await S.getSettings(), ping);
  }

  function setHint(text) { els.statusHint.textContent = text; }

  function renderState(meta, ping = null) {
    const state = meta?.state || C.STATES.IDLE;
    els.statusPill.textContent = state;
    els.statusPill.className = `status-pill ${state.toLowerCase()}`;
    els.totalCount.textContent = String(meta?.totalLeads ?? 0);
    els.pageCount.textContent = String(meta?.currentPage ?? (ping?.page ?? 1));
    els.duplicateCount.textContent = String(meta?.duplicates ?? 0);
    els.errorCount.textContent = String(meta?.errors ?? 0);
    els.progressBar.style.width = `${Math.max(0, Math.min(100, Number(meta?.scrollProgress || 0)))}%`;
    els.speedValue.textContent = formatSpeed(meta);
    els.etaValue.textContent = formatEta(meta);

    const active = [C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING, C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE];
    els.pauseBtn.disabled = !active.includes(state);
    els.resumeBtn.disabled = ![C.STATES.PAUSED, C.STATES.STOPPED, C.STATES.ERROR].includes(state);
    els.stopBtn.disabled = !active.includes(state) && state !== C.STATES.PAUSED;
    els.startBtn.disabled = active.includes(state);

    const risk = ping?.safetyRisk?.risky ? `Safety guard: ${ping.safetyRisk.reason}` : null;
    const hint = risk || meta?.lastError || meta?.currentStateReason || (ping?.onSearch ? `${ping.rowsVisible} visible result rows.` : 'Open a Sales Navigator people search.');
    setHint(hint);
  }

  function renderTargetStatus(settings, ping = null) {
    const mode = settings.paginationMode || C.PAGINATION_MODES.CLICK_LINK;
    els.setPaginationMode.value = mode;
    const labels = {
      none: 'No automatic load-more action.',
      scroll: 'Scroll engine will load more results at the bottom.',
      click_link: 'Next-page action is ready for auto-detection or your saved target.',
      click_button: 'Load-more button action is ready for auto-detection or your saved target.'
    };
    const target = settings.paginationTargetSelector ? ` Target: ${settings.paginationTargetSelector}` : '';
    const verify = ping?.pagination;
    if (verify && mode !== C.PAGINATION_MODES.NONE) {
      els.targetStatus.textContent = `${labels[mode] || ''}${target} ${verify.ok ? '✓ verified on this page.' : 'Target not found on this page.'}`;
    } else {
      els.targetStatus.textContent = `${labels[mode] || ''}${target}`;
    }
  }

  function formatSpeed(meta) {
    const count = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!started || !count) return '0/min';
    const minutes = Math.max((Date.now() - started) / 60000, 1 / 60);
    return `${Math.round(count / minutes)}/min`;
  }

  function formatEta(meta) {
    const total = Number(meta?.expectedTotal || 0);
    const done = Number(meta?.collectedThisRun || 0);
    const started = Date.parse(meta?.startedAt || '');
    if (!total || !started || done >= total) return '—';
    const perMin = done / Math.max((Date.now() - started) / 60000, 1 / 60);
    if (!perMin) return '—';
    const minutes = Math.max((total - done) / perMin, 0);
    return minutes < 60 ? `${Math.ceil(minutes)}m` : `${Math.floor(minutes / 60)}h ${Math.ceil(minutes % 60)}m`;
  }

  async function loadData() {
    const leads = await S.getLeads();
    els.totalCount.textContent = String(leads.length);
    renderTable(leads.slice(-1000));
  }

  function renderTable(leads) {
    els.tableRowCount.textContent = `${leads.length} row${leads.length === 1 ? '' : 's'}`;
    if (!els.leadTableHead.childElementCount) {
      const thIndex = document.createElement('th'); thIndex.textContent = '#'; els.leadTableHead.appendChild(thIndex);
      U.COLUMNS.forEach((column) => { const th = document.createElement('th'); th.textContent = column.label; els.leadTableHead.appendChild(th); });
    }
    els.leadTableBody.replaceChildren();
    if (!leads.length) {
      const empty = els.leadTableEmpty.cloneNode(true);
      empty.hidden = false;
      empty.querySelector('td').colSpan = U.COLUMNS.length + 1;
      els.leadTableBody.appendChild(empty);
      return;
    }
    const fragment = document.createDocumentFragment();
    [...leads].reverse().forEach((lead, index) => {
      const tr = document.createElement('tr');
      const indexCell = document.createElement('td');
      indexCell.textContent = String(leads.length - index);
      tr.appendChild(indexCell);
      U.COLUMNS.forEach((column) => {
        const td = document.createElement('td');
        if (column.key.endsWith('LinkedInUrl') && lead[column.key]) {
          const link = document.createElement('a');
          link.href = lead[column.key]; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = lead[column.key]; td.appendChild(link);
        } else {
          td.textContent = U.exportValue(lead, column.key);
        }
        tr.appendChild(td);
      });
      fragment.appendChild(tr);
    });
    els.leadTableBody.appendChild(fragment);
  }

  function populateSettings(settings) {
    els.setPaginationMode.value = settings.paginationMode;
    els.setAutoScroll.checked = !!settings.autoScroll;
    els.setAutoNext.checked = !!settings.autoNextPage;
    els.setAutoSave.checked = !!settings.autoSave;
    els.setAutoResume.checked = !!settings.autoResume;
    els.setContinueClosed.checked = !!settings.continueWhenPopupClosed;
    els.setHumanMode.checked = !!settings.humanMode;
    els.setAutoDownload.checked = !!settings.autoDownload;
    els.setSafetyMode.checked = !!settings.safetyMode;
    els.setStopOnSecurity.checked = !!settings.stopOnSecurityPrompt;
    els.setDebug.checked = !!settings.debugMode;
    els.setScrollMin.value = settings.scrollMinPx;
    els.setScrollMax.value = settings.scrollMaxPx;
    els.setRetry.value = settings.retryCount;
    els.setTimeout.value = settings.timeoutMs;
    els.setStable.value = settings.stableMs;
    els.setMaxPages.value = settings.maxPages;
    els.setActionDelayMin.value = settings.actionDelayMinMs;
    els.setActionDelayMax.value = settings.actionDelayMaxMs;
    els.setActionsPerMinute.value = settings.maxActionsPerMinute;
  }

  async function runCommand(type) {
    let response = await sendToTab({ type });
    if (!response?.ok) {
      await refreshTab();
      response = await sendToTab({ type });
    }
    if (!response?.ok) {
      setHint(response?.reason || 'The page did not respond. Refresh it and try again.');
      return;
    }
    renderState(response.state || await S.getMeta());
    await loadData();
  }

  async function selectTarget() {
    const mode = els.setPaginationMode.value;
    if (![C.PAGINATION_MODES.CLICK_LINK, C.PAGINATION_MODES.CLICK_BUTTON].includes(mode)) {
      setHint('Select Click link or Click button first.');
      return;
    }
    const response = await sendToTab({ type: 'LX_PICK_TARGET', mode });
    if (!response?.ok) {
      setHint(response?.reason || 'Could not start target picker.');
      return;
    }
    setHint('Picker started. Click the Next link or Load more button on the page, then reopen the extension to verify it.');
  }

  async function verifyTarget() {
    const settings = await S.getSettings();
    const response = await sendToTab({
      type: 'LX_VERIFY_TARGET',
      mode: settings.paginationMode,
      selector: settings.paginationTargetSelector
    });
    if (!response?.ok) {
      setHint(response?.reason || 'Target verification failed.');
      return;
    }
    const r = response.result;
    renderTargetStatus(settings, { pagination: r });
    setHint(r.ok ? `Target verified: ${r.selector || 'auto-detected'}${r.text ? ` — ${r.text}` : ''}` : 'Target not found on the current page.');
  }

  async function init() {
    const settings = await S.getSettings();
    document.body.classList.toggle('light', settings.darkMode === false);
    document.body.classList.toggle('dark', settings.darkMode !== false);
    populateSettings(settings);
    await loadData();
    await refreshTab();

    els.settingsBtn.addEventListener('click', () => { els.settingsPanel.hidden = !els.settingsPanel.hidden; });
    els.startBtn.addEventListener('click', () => runCommand('LX_START'));
    els.pauseBtn.addEventListener('click', () => runCommand('LX_PAUSE'));
    els.resumeBtn.addEventListener('click', () => runCommand('LX_RESUME'));
    els.stopBtn.addEventListener('click', () => runCommand('LX_STOP'));
    els.resetRunBtn.addEventListener('click', async () => { if (confirm('Reset the saved run state? Your collected leads will remain.')) await runCommand('LX_RESET_RUN'); });
    els.extractBtn.addEventListener('click', async () => {
      const response = await sendToTab({ type: 'LX_EXTRACT_PAGE' });
      if (!response?.ok) setHint(response?.reason || 'Current-page extraction failed.');
      else { setHint(`Found ${response.foundOnPage} rows: ${response.added} new, ${response.updated} updated, ${response.duplicates} duplicates.`); await loadData(); }
    });
    els.selectTargetBtn.addEventListener('click', selectTarget);
    els.verifyTargetBtn.addEventListener('click', verifyTarget);
    els.setPaginationMode.addEventListener('change', async () => {
      const settings = await S.saveSettings({ paginationMode: els.setPaginationMode.value, paginationTargetSelector: '', paginationTargetLabel: '' });
      populateSettings(settings);
      renderTargetStatus(settings);
      setHint('Pagination mode changed. Select a page control when using click-link or click-button mode.');
    });
    els.clearBtn.addEventListener('click', async () => { if (!confirm('Clear all collected leads? This cannot be undone.')) return; await S.clearLeads(); await loadData(); });
    els.copyAllBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) { await E.copyAll(leads); setHint(`Copied ${leads.length} leads.`); } });
    els.downloadCsvBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) E.downloadCsv(leads); });
    els.downloadJsonBtn.addEventListener('click', async () => { const leads = await S.getLeads(); if (leads.length) E.downloadJson(leads, await S.getMeta()); });
    els.saveSettingsBtn.addEventListener('click', async () => {
      const patch = {
        paginationMode: els.setPaginationMode.value,
        autoScroll: els.setAutoScroll.checked,
        autoNextPage: els.setAutoNext.checked,
        autoSave: els.setAutoSave.checked,
        autoResume: els.setAutoResume.checked,
        continueWhenPopupClosed: els.setContinueClosed.checked,
        humanMode: els.setHumanMode.checked,
        autoDownload: els.setAutoDownload.checked,
        safetyMode: els.setSafetyMode.checked,
        stopOnSecurityPrompt: els.setStopOnSecurity.checked,
        debugMode: els.setDebug.checked,
        scrollMinPx: Number(els.setScrollMin.value),
        scrollMaxPx: Number(els.setScrollMax.value),
        retryCount: Number(els.setRetry.value),
        timeoutMs: Number(els.setTimeout.value),
        stableMs: Number(els.setStable.value),
        maxPages: Number(els.setMaxPages.value),
        actionDelayMinMs: Number(els.setActionDelayMin.value),
        actionDelayMaxMs: Number(els.setActionDelayMax.value),
        maxActionsPerMinute: Number(els.setActionsPerMinute.value)
      };
      const saved = await S.saveSettings(patch);
      populateSettings(saved);
      await refreshTab();
      setHint('Settings saved.');
    });

    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local') return;
      if (changes.lx_meta) renderState(changes.lx_meta.newValue || {});
      if (changes.lx_leads) await loadData();
      if (changes.lx_settings) {
        const next = { ...C.DEFAULTS, ...(changes.lx_settings.newValue || {}) };
        populateSettings(next);
        renderTargetStatus(next);
      }
    });
    chrome.tabs.onActivated.addListener(refreshTab);
    chrome.tabs.onUpdated.addListener((tabId, info) => { if (tabId === activeTabId && (info.status === 'complete' || info.url)) void refreshTab(); });

    refreshTimer = setInterval(async () => {
      try {
        const meta = await S.getMeta();
        renderState(meta);
        const tab = await getActiveTab();
        if (tab?.id === activeTabId) {
          const ping = await sendToTab({ type: 'LX_PING' });
          if (ping?.ok) {
            renderState(meta, ping);
            renderTargetStatus(await S.getSettings(), ping);
          }
        }
      } catch (_) {
        // Popup refresh errors must never interrupt control actions.
      }
    }, 1500);
  }

  window.addEventListener('unload', () => { if (refreshTimer) clearInterval(refreshTimer); }, { once: true });
  document.addEventListener('DOMContentLoaded', init, { once: true });
})();
