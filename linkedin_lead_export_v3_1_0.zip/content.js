/* content.js — runtime message bridge, picker commands and automatic resume boot. */
(function boot() {
  if (window.__LX_CONTENT_BOOTED__) return;
  window.__LX_CONTENT_BOOTED__ = true;

  const C = window.LXConstants;
  const S = window.LXStorage;
  const U = window.LX;
  const Logger = window.LXLogger;
  const E = window.LXExtractor;
  const Controller = window.LXController;
  const Pagination = window.LXPagination;
  const Picker = window.LXPicker;
  const Safety = window.LXSafety;

  async function bootController() {
    try {
      await Controller.init();
      const settings = await S.getSettings();
      Logger.setDebug(settings.debugMode);
      const meta = await S.getMeta();
      const sameSearch = meta.searchKey === U.searchKey(window.location.href);
      const resumable = [
        C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE
      ].includes(meta.state);
      if (settings.autoResume && sameSearch && resumable && meta.runId) {
        Logger.info('Resuming saved run', meta.runId || 'unknown');
        await Controller.start({ resume: true });
      }
    } catch (error) {
      Logger.error('Controller boot failed', error?.message || error);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    (async () => {
      try {
        switch (message.type) {
          case 'LX_PING': {
            const settings = await S.getSettings();
            const safety = Safety.detect();
            const rows = E.findResultRows();
            sendResponse({
              ok: true,
              url: window.location.href,
              onSearch: /\/sales\/(search|lists|people)/i.test(window.location.pathname),
              rowsVisible: rows.length,
              loading: E.hasBlockingLoader(),
              safetyRisk: safety,
              pagination: Pagination.verifyTarget(settings.paginationMode, settings.paginationTargetSelector),
              state: (await S.getMeta()).state || C.STATES.IDLE,
              page: Number(new URL(window.location.href).searchParams.get('page')) || 1
            });
            return;
          }
          case 'LX_GET_STATE':
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_START':
            await Controller.start({ resume: true });
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_PAUSE':
            await Controller.pause();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESUME':
            await Controller.resume();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_STOP':
            await Controller.stop();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_RESET_RUN':
            await Controller.resetRun();
            sendResponse({ ok: true, state: Controller.getSnapshot() });
            return;
          case 'LX_EXTRACT_PAGE': {
            const result = await Controller.extractCurrentPage();
            if (!result.ok) {
              sendResponse({ ok: false, reason: result.reason || 'Extraction failed', readiness: result.readiness });
              return;
            }
            const leads = await S.getLeads();
            sendResponse({
              ok: true,
              foundOnPage: result.extraction.leads.length,
              added: result.added,
              updated: result.updated,
              duplicates: result.duplicates,
              totalLeads: leads.length,
              leads,
              readiness: (await S.getMeta()).lastReadiness || null
            });
            return;
          }
          case 'LX_VERIFY_TARGET': {
            const settings = await S.getSettings();
            const mode = message.mode || settings.paginationMode;
            const selector = message.selector ?? settings.paginationTargetSelector;
            const result = Pagination.verifyTarget(mode, selector);
            sendResponse({ ok: true, result });
            return;
          }
          case 'LX_PICK_TARGET': {
            const mode = message.mode;
            if (![C.PAGINATION_MODES.CLICK_LINK, C.PAGINATION_MODES.CLICK_BUTTON].includes(mode)) {
              sendResponse({ ok: false, reason: 'Target picker is available only for click-link and click-button modes.' });
              return;
            }
            sendResponse({ ok: true, started: true });
            void Picker.pick(mode).catch((error) => Logger.error('Target picker failed', error?.message || error));
            return;
          }
          case 'LX_GET_NEXT':
            sendResponse({ ok: true, hasNext: Pagination.hasNext() });
            return;
          default:
            sendResponse({ ok: false, reason: 'Unknown message' });
        }
      } catch (error) {
        Logger.error('Message operation failed', message.type, error?.message || error);
        sendResponse({ ok: false, reason: error?.message || 'Operation failed' });
      }
    })();

    return true;
  });

  void bootController();
})();
