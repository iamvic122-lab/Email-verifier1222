/* live_collector.js — incremental DOM observer for person/company records. */
(function attachLiveCollector(root) {
  const U = root.LX;
  const C = root.LXConstants;
  const S = root.LXStorage;
  const Extractor = root.LXExtractor;
  const Logger = root.LXLogger;

  class LiveCollector {
    constructor() {
      this.active = false;
      this.pageKey = '';
      this.mode = C.RECORD_TYPES.PERSON;
      this.observer = null;
      this.scanTimer = null;
      this.flushTimer = null;
      this.fullReconcileTimer = null;
      this.scanQueued = false;
      this.flushRunning = false;
      this.fullReconcileTimer = null;
      this.lastScanAt = 0;
      this.pending = new Map();
      this.revisions = new Map();
      this.pageKeys = new Set();
      this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
      this.onSaved = null;
      this.waiters = [];
    }

    start(pageKey, mode = C.RECORD_TYPES.PERSON, onSaved = null) {
      this.stop({ preserveStats: false });
      this.active = true;
      this.pageKey = String(pageKey || U.pageKey(window.location.href));
      this.mode = mode === C.RECORD_TYPES.COMPANY ? C.RECORD_TYPES.COMPANY : C.RECORD_TYPES.PERSON;
      this.onSaved = typeof onSaved === 'function' ? onSaved : null;
      this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
      this.pageKeys.clear();
      this.revisions.clear();

      const rootNode = document.documentElement || document;
      try {
        this.observer = new MutationObserver((mutations) => this._handleMutations(mutations));
        this.observer.observe(rootNode, {
          subtree: true,
          childList: true,
          characterData: true,
          attributes: true,
          attributeFilter: ['href', 'src', 'alt', 'aria-label', 'title', 'class', 'data-anonymize', 'style']
        });
      } catch (error) {
        Logger.warning('Live collector observer unavailable', error?.message || error);
      }

      this.scanNow();
      const reconcileMs = Math.max(500, Number(C.DEFAULTS.liveReconcileMs) || 1500);
      this.fullReconcileTimer = setInterval(() => {
        if (this.active) this.scanNow();
      }, reconcileMs);
      return this.snapshot();
    }

    stop({ preserveStats = true } = {}) {
      this.active = false;
      this.observer?.disconnect();
      this.observer = null;
      if (this.scanTimer) clearTimeout(this.scanTimer);
      if (this.fullReconcileTimer) clearInterval(this.fullReconcileTimer);
      if (this.flushTimer) clearTimeout(this.flushTimer);
      this.scanTimer = null;
      this.flushTimer = null;
      this.fullReconcileTimer = null;
      this.scanQueued = false;
      if (!preserveStats) {
        this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
        this.pending.clear();
        this.revisions.clear();
        this.pageKeys.clear();
      }
      this._resolveWaitersIfIdle();
    }

    snapshot() {
      return {
        pageKey: this.pageKey,
        mode: this.mode,
        recordType: this.mode,
        active: this.active,
        ...this.stats,
        uniquePageRecords: this.pageKeys.size,
        uniquePageLeads: this.pageKeys.size,
        pending: this.pending.size,
        queueBusy: this.flushRunning
      };
    }

    getUniquePageCount() { return this.pageKeys.size; }
    getPageKeys() { return new Set(this.pageKeys); }

    scanNow() {
      if (!this.active) return this.snapshot();
      this.stats.scans += 1;
      this.lastScanAt = Date.now();
      let rows = [];
      try {
        rows = Extractor.findResultRows(this.mode);
      } catch (error) {
        Logger.warning('Live collector row discovery failed', error?.message || error);
        this._scheduleFlush();
        return this.snapshot();
      }

      rows.forEach((row, index) => {
        try {
          const record = Extractor.extractRecord(row, index, this.mode);
          if (!record) return;
          const key = U.recordKey(record);
          if (!key) return;
          this.pageKeys.add(key);
          this.stats.seen = Math.max(this.stats.seen, this.pageKeys.size);
          const revision = this._revision(record);
          if (this.revisions.get(key) === revision) return;
          this.revisions.set(key, revision);
          this.pending.set(key, record);
        } catch (error) {
          Logger.debug('Live row scan failed', this.mode, index + 1, error?.message || error);
        }
      });

      this._scheduleFlush();
      return this.snapshot();
    }

    _revision(record) {
      return JSON.stringify({
        recordType: record.recordType,
        personName: record.personName || '',
        jobTitle: record.jobTitle || '',
        companyName: record.companyName || '',
        companyLinkedInUrl: record.companyLinkedInUrl || '',
        location: record.location || '',
        employeeCount: record.employeeCount || '',
        connectionDegree: record.connectionDegree || '',
        yearsInRole: record.yearsInRole || '',
        yearsInCompany: record.yearsInCompany || '',
        about: record.about || '',
        industry: record.industry || '',
        revenue: record.revenue || '',
        companyProfileImageUrl: record.companyProfileImageUrl || '',
        premium: !!record.premium
      });
    }

    _handleMutations(mutations) {
      if (!this.active || !Array.isArray(mutations) || !mutations.length) return;
      const relevant = mutations.some((mutation) => {
        if (mutation.type === 'childList' || mutation.type === 'characterData') return true;
        if (mutation.type !== 'attributes') return false;
        return ['href', 'src', 'alt', 'aria-label', 'title', 'class', 'data-anonymize', 'style'].includes(mutation.attributeName);
      });
      if (relevant) this._queueScan();
    }

    _queueScan() {
      if (!this.active || this.scanQueued) return;
      const debounce = Math.max(60, Number(C.DEFAULTS.liveScanDebounceMs) || 140);
      const elapsed = Date.now() - this.lastScanAt;
      const delay = Math.max(0, debounce - elapsed);
      this.scanQueued = true;
      this.scanTimer = setTimeout(() => {
        this.scanTimer = null;
        this.scanQueued = false;
        if (this.active) this.scanNow();
      }, delay);
    }

    _scheduleFlush() {
      if (!this.active || this.flushTimer || this.flushRunning) return;
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        void this.flushPending();
      }, Math.max(40, Number(C.DEFAULTS.liveFlushDebounceMs) || 120));
    }

    async flushPending() {
      if (this.flushRunning) return;
      this.flushRunning = true;
      try {
        while (this.pending.size > 0) {
          const entries = [...this.pending.entries()];
          this.pending.clear();
          for (const [key, record] of entries) {
            try {
              const result = await S.upsertLead(record);
              if (result.added) this.stats.added += 1;
              else if (result.updated) this.stats.updated += 1;
              else this.stats.duplicates += 1;
              if (this.onSaved) await this.onSaved({ key, lead: record, record, result, snapshot: this.snapshot() });
            } catch (error) {
              if (U.isExtensionContextInvalidated?.(error)) throw error;
              this.stats.errors += 1;
              Logger.warning('Live record save failed', key, error?.message || error);
            }
          }
        }
      } finally {
        this.flushRunning = false;
        this._resolveWaitersIfIdle();
      }
    }

    async flushAndWait() {
      if (!this.active) return this.snapshot();
      this.scanNow();
      await this.flushPending();
      if (this.pending.size === 0 && !this.flushRunning) return this.snapshot();
      await new Promise((resolve) => this.waiters.push(resolve));
      return this.snapshot();
    }

    _resolveWaitersIfIdle() {
      if (this.pending.size > 0 || this.flushRunning) return;
      const waiters = this.waiters.splice(0);
      waiters.forEach((resolve) => resolve());
    }
  }

  root.LXLiveCollector = new LiveCollector();
})(typeof window !== 'undefined' ? window : globalThis);
