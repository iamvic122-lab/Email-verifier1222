/* scroll.js — lazy-load scrolling plus page coverage audit. */
(function attachScroll(root) {
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;

  function isScrollable(el) {
    if (!el || el.nodeType !== 1) return false;
    const style = getComputedStyle(el);
    const overflowY = style.overflowY;
    return (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && el.scrollHeight > el.clientHeight + 40;
  }

  function findContainer(rows) {
    const sample = rows && rows[0];
    let node = sample ? sample.parentElement : null;
    while (node && node !== document.body && node !== document.documentElement) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function progressOf(container) {
    const max = Math.max(1, container.scrollHeight - container.clientHeight);
    const top = Number(container.scrollTop || 0);
    return Math.min(100, Math.round((top / max) * 100));
  }

  function atBottom(container, threshold = 48) {
    return container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
  }

  function restorePosition(container, scrollTop) {
    const value = Number(scrollTop);
    if (!container || !Number.isFinite(value) || value < 0) return false;
    const max = Math.max(0, container.scrollHeight - container.clientHeight);
    container.scrollTop = Math.min(value, max);
    return true;
  }

  async function waitForMovement(container, beforeTop, settings, shouldPause) {
    try {
      await Wait.waitForCondition(() => {
        return Math.abs(container.scrollTop - beforeTop) > 8 || atBottom(container);
      }, {
        root: container,
        timeoutMs: Math.min(Number(settings.timeoutMs) || 30000, 3500),
        shouldCancel: shouldPause
      });
    } catch (_) {
      // Scroll movement timeout is recoverable; the caller evaluates actual progress.
    }
  }

  async function scrollToBottom({ findRows, settings, shouldPause, onProgress }) {
    const firstRows = findRows();
    const container = findContainer(firstRows);
    let passes = 0;
    let noGrowth = 0;
    let lastHeight = container.scrollHeight;
    let lastTop = container.scrollTop;
    let lastCount = firstRows.length;

    while (passes < settings.maxScrollPasses) {
      if (shouldPause()) return { paused: true, progress: progressOf(container), scrollTop: container.scrollTop, passes };
      passes += 1;

      const beforeCount = findRows().length;
      const beforeHeight = container.scrollHeight;
      const beforeTop = container.scrollTop;
      const distance = U.randomBetween(settings.scrollMinPx, settings.scrollMaxPx);
      container.scrollBy({ top: distance, left: 0, behavior: settings.humanMode ? 'smooth' : 'auto' });
      await waitForMovement(container, beforeTop, settings, shouldPause);

      if (settings.humanMode) {
        const pause = U.randomBetween(settings.scrollPauseMinMs, settings.scrollPauseMaxMs);
        if (pause > 0) await new Promise((resolve) => setTimeout(resolve, pause));
      }

      const currentCount = findRows().length;
      const currentHeight = container.scrollHeight;
      const currentTop = container.scrollTop;
      const progressed = currentCount > beforeCount || currentHeight > beforeHeight || currentTop > beforeTop + 8;

      if (!progressed) noGrowth += 1;
      else noGrowth = 0;

      if (currentHeight === lastHeight && currentTop === lastTop && currentCount === lastCount) noGrowth += 1;
      lastHeight = currentHeight;
      lastTop = currentTop;
      lastCount = currentCount;

      const progress = progressOf(container);
      Logger.debug('Scroll pass', passes, 'progress', progress, 'rows', currentCount, 'height', currentHeight);
      if (typeof onProgress === 'function') {
        await onProgress({ progress, scrollTop: currentTop, scrollHeight: currentHeight, rows: currentCount, passes });
      }

      if (atBottom(container)) {
        try {
          await Wait.waitForCondition(() => {
            const nowCount = findRows().length;
            return nowCount > currentCount || container.scrollHeight > currentHeight;
          }, {
            root: container,
            timeoutMs: Math.min(Number(settings.timeoutMs) || 30000, 2500),
            shouldCancel: shouldPause
          });
          noGrowth = 0;
          continue;
        } catch (_) {
          // No growth at the bottom is a normal completion signal. Do not spin forever.
          noGrowth += 1;
          if (noGrowth >= 2) break;
        }
      }

      if (noGrowth >= 3) break;
    }

    if (passes >= settings.maxScrollPasses) Logger.warning('Maximum scroll passes reached', settings.maxScrollPasses);
    return {
      paused: false,
      progress: progressOf(container),
      scrollTop: container.scrollTop,
      scrollHeight: container.scrollHeight,
      passes
    };
  }

  async function auditCoverage({ findRows, settings, shouldPause, onScan, getUniqueCount, expectedCount }) {
    const container = findContainer(findRows());
    const originalTop = Number(container.scrollTop || 0);
    const viewport = Math.max(240, Number(container.clientHeight || window.innerHeight || 600));
    const step = Math.max(180, Math.floor(viewport * 0.78));
    const maxPasses = Math.max(1, Math.min(Number(settings.pageAuditPasses) || 3, 5));
    let passes = 0;
    let direction = 'down';
    let attempts = 0;
    let previousUniqueCount = getUniqueCount();

    const scan = async () => {
      try {
        if (typeof onScan === 'function') await onScan();
      } catch (error) {
        Logger.debug('Coverage scan failed', error?.message || error);
      }
    };

    const travel = async (toTop) => {
      direction = toTop ? 'up' : 'down';
      container.scrollTo({ top: toTop ? 0 : container.scrollHeight, behavior: 'auto' });
      await Wait.wait(0);
      await scan();

      let guard = 0;
      while (guard < settings.maxScrollPasses) {
        if (shouldPause()) return false;
        guard += 1;
        const before = container.scrollTop;
        const nextTop = toTop ? Math.max(0, before - step) : Math.min(Math.max(0, container.scrollHeight - container.clientHeight), before + step);
        if (nextTop === before) break;
        container.scrollTop = nextTop;
        attempts += 1;
        try {
          await Wait.waitForCondition(() => Math.abs(container.scrollTop - before) > 8 || (toTop ? container.scrollTop <= 0 : atBottom(container)), {
            root: container,
            timeoutMs: 1800,
            shouldCancel: shouldPause
          });
        } catch (_) {}
        await scan();
        if (toTop ? container.scrollTop <= 0 : atBottom(container)) break;
      }
      return true;
    };

    // First coverage pass ends at the bottom so Next/Load More controls are discoverable.
    passes += 1;
    if (!(await travel(true))) return { paused: true, passes, attempts, uniqueCount: getUniqueCount(), direction };
    if (!(await travel(false))) return { paused: true, passes, attempts, uniqueCount: getUniqueCount(), direction };

    let uniqueCount = getUniqueCount();
    // Coverage is identity-based, not DOM-count-based. If LinkedIn virtualizes rows,
    // a second top-to-bottom sweep can discover records that replaced earlier DOM nodes.
    while (passes < maxPasses) {
      if (uniqueCount >= expectedCount) break;
      const beforeSweep = uniqueCount;
      passes += 1;
      if (!(await travel(true))) return { paused: true, passes, attempts, uniqueCount: getUniqueCount(), direction };
      if (!(await travel(false))) return { paused: true, passes, attempts, uniqueCount: getUniqueCount(), direction };
      uniqueCount = getUniqueCount();
      if (uniqueCount === beforeSweep || uniqueCount === previousUniqueCount) break;
      previousUniqueCount = uniqueCount;
    }

    // Leave the result container at the bottom for automatic Next/Load More detection.
    container.scrollTo({ top: Math.max(0, container.scrollHeight - container.clientHeight), behavior: 'auto' });
    await scan();

    return {
      paused: false,
      passes,
      attempts,
      uniqueCount,
      expectedCount,
      direction,
      originalTop,
      finalTop: container.scrollTop
    };
  }

  root.LXScroll = { findContainer, restorePosition, progressOf, atBottom, scrollToBottom, auditCoverage };
})(typeof window !== 'undefined' ? window : globalThis);
