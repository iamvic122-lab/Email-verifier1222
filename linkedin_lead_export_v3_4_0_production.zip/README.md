# Sales Navigator Extractor v3.4.0

Production-oriented Manifest V3 extension for Sales Navigator person and company/account result extraction.

## v3.4.0 improvements

- Keeps the v3.3.0 People + Company architecture.
- Incremental result collection remains live; records are saved as they appear.
- Progress metadata is checkpointed in a short coalescing window instead of writing popup/controller metadata for every DOM mutation.
- Live DOM observation is mutation-filtered and backed by periodic reconciliation to recover from LinkedIn virtualized row replacement.
- Coverage auditing is identity-based and can perform additional full top-to-bottom sweeps when fewer than the expected page results have been collected.
- Context invalidation remains fail-closed; no attempt is made to bypass Chrome extension lifecycle rules.
- Pagination remains DOM-driven and verified rather than using fixed page-load sleeps.
- Security/challenge signals stop the run rather than attempting to bypass them.

## Supported views

- People / Lead search: `/sales/search/people`
- Company / Account search: `/sales/search/company`, `/sales/search/companies`, `/sales/search/account`, `/sales/search/accounts`
- Automatic DOM fallback detection when the URL is ambiguous.

## Company fields

- Company Name
- Company LinkedIn URL
- Industry
- Employee Count
- Revenue
- About
- Company Profile Image
- Company ID
- Data Quality

Revenue is optional and displays as `N/A` when unavailable.
