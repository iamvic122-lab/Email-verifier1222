# Sales Navigator Lead Export — v3.1.2

Production MV3 extractor rebuilt from v3.1.1.

## Automatic pagination

The manual pagination-action selector has been removed. The engine decides automatically:

1. Prefer a visible **Next** control.
2. Detect LinkedIn's exact `span.artdeco-button__text` text of `Next` and click its nearest button/link.
3. Fall back to supported Next selectors/text detection.
4. If there is no Next control, detect a visible **Load more** control.
5. Lazy-loaded result lists are scrolled automatically while the live collector is active.

No manual pagination selector or picker is required.

## Streaming extraction

The extension no longer waits for the whole result page to become stable before writing data.

A MutationObserver watches the page and the live collector:

- extracts each usable result row as soon as it appears,
- writes the lead immediately,
- updates the popup through `chrome.storage.onChanged`,
- enriches a lead later if more fields appear,
- deduplicates by canonical LinkedIn profile URL / lead ID.

Therefore lead #1 can appear in the table while LinkedIn is still rendering the remaining results. New leads are appended below earlier leads; the popup no longer reverses the table.

## 25-result coverage audit

Sales Navigator result pages are treated as **25 expected unique leads per normal page** by default.

After the normal scroll reaches the end, the engine performs a coverage audit:

- scrolls back to the top and scans again,
- returns to the bottom,
- if fewer than 25 unique leads were collected and another page exists, performs a second coverage pass,
- leaves the result container at the bottom so the Next control is discoverable.

The audit is based on unique LinkedIn lead keys, not merely DOM row count. This matters when rows are virtualized, lazily rendered, or temporarily replaced.

The current page coverage is persisted as `uniqueCollected / expected`.

The final page may legitimately contain fewer than 25 results because there may be no Next control.

## Pagination synchronization

Next-page navigation is considered successful as soon as any of these changes occurs:

- `pageKey` changes,
- URL changes,
- result signature changes,
- first visible lead changes.

The engine does **not** wait for every result row or every secondary field on the new page before continuing. It waits only for the first result row, then starts streaming extraction.

This removes the failure mode where a stale result container caused a 15–30 second page readiness timeout.

## Resume and context recovery

Run metadata is checkpointed before navigation and after lead saves. A new content-script context can resume the saved run after page navigation, extension reload or browser restart when Resume is enabled.

If Chrome reports `Extension context invalidated`, the old controller instance exits without attempting another extension API write. The next valid extension context can resume from its checkpoint.

## Safety behavior

The extension detects visible verification, CAPTCHA, checkpoint, unusual-activity and restriction signals. With the safety guard enabled, those signals stop the run instead of being bypassed.

No extension can guarantee that LinkedIn will never restrict an account.

## Files

| File | Responsibility |
|---|---|
| `constants.js` | States, defaults, limits |
| `logger.js` | Structured logging |
| `selectors.js` | Centralized LinkedIn DOM selectors |
| `utils.js` | Normalization, IDs, export helpers |
| `safety.js` | Security-signal detection and action pacing |
| `wait.js` | Mutation/condition synchronization |
| `storage.js` | Persistent local lead/meta/settings store |
| `extractor.js` | Result discovery and field extraction |
| `scroll.js` | Lazy-loading scroll + coverage audit |
| `pagination.js` | Automatic Next/Load more detection and verified clicks |
| `live_collector.js` | Incremental DOM observation and immediate persistence |
| `controller.js` | State machine and orchestration |
| `content.js` | Runtime bridge and resume boot |
| `popup.*` | Control panel, live metrics and settings |
| `export.js` | CSV/JSON/clipboard export |
| `background.js` | MV3 lifecycle/default initialization |
