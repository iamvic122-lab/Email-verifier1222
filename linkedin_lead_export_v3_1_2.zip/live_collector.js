/* live_collector.js — incremental DOM observer that extracts and persists leads as soon as their rows appear. */
(function attachLiveCollector(root) {
  const U = root.LX;
  const C = root.LXConstants;
  const S = root.LXStorage;
  const Extractor = root.LXExtractor;
  const Logger = root.LXLogger;

  class LiveCollector {
    constructor() {
      this.active = false;
      this.pageKey = '';
      this.observer = null;
      this.scanTimer = null;
      this.flushTimer = null;
      this.scanQueued = false;
      this.flushRunning = false;
      this.pending = new Map();
      this.revisions = new Map();
      this.pageKeys = new Set();
      this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
      this.onSaved = null;
      this.waiters = [];
    }

    start(pageKey, onSaved = null) {
      this.stop({ preserveStats: false });
      this.active = true;
      this.pageKey = String(pageKey || U.pageKey(window.location.href));
      this.onSaved = typeof onSaved === 'function' ? onSaved : null;
      this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
      this.pageKeys.clear();
      this.revisions.clear();

      const rootNode = document.documentElement || document;
      try {
        this.observer = new MutationObserver(() => this._queueScan());
        this.observer.observe(rootNode, {
          subtree: true,
          childList: true,
          characterData: true,
          attributes: true,
          attributeFilter: ['href', 'aria-label', 'title', 'class', 'data-anonymize']
        });
      } catch (error) {
        Logger.warning('Live collector observer unavailable', error?.message || error);
      }

      this.scanNow();
      return this.snapshot();
    }

    stop({ preserveStats = true } = {}) {
      this.active = false;
      this.observer?.disconnect();
      this.observer = null;
      if (this.scanTimer) clearTimeout(this.scanTimer);
      if (this.flushTimer) clearTimeout(this.flushTimer);
      this.scanTimer = null;
      this.flushTimer = null;
      this.scanQueued = false;
      if (!preserveStats) {
        this.stats = { added: 0, updated: 0, duplicates: 0, errors: 0, seen: 0, scans: 0 };
        this.pending.clear();
        this.revisions.clear();
        this.pageKeys.clear();
      }
      this._resolveWaitersIfIdle();
    }

    snapshot() {
      return {
        pageKey: this.pageKey,
        active: this.active,
        ...this.stats,
        uniquePageLeads: this.pageKeys.size,
        pending: this.pending.size,
        queueBusy: this.flushRunning
      };
    }

    getUniquePageCount() {
      return this.pageKeys.size;
    }

    getPageKeys() {
      return new Set(this.pageKeys);
    }

    scanNow() {
      if (!this.active) return this.snapshot();
      this.stats.scans += 1;
      let rows = [];
      try {
        rows = Extractor.findResultRows();
      } catch (error) {
        Logger.warning('Live collector row discovery failed', error?.message || error);
        this._scheduleFlush();
        return this.snapshot();
      }

      rows.forEach((row, index) => {
        try {
          const lead = Extractor.extractLead(row, index);
          if (!lead) return;
          const key = U.leadKey(lead);
          if (!key) return;
          this.pageKeys.add(key);
          this.stats.seen = Math.max(this.stats.seen, this.pageKeys.size);
          const revision = this._revision(lead);
          if (this.revisions.get(key) === revision) return;
          this.revisions.set(key, revision);
          this.pending.set(key, lead);
        } catch (error) {
          Logger.debug('Live row scan failed', index + 1, error?.message || error);
        }
      });

      this._scheduleFlush();
      return this.snapshot();
    }

    _revision(lead) {
      return JSON.stringify({
        personName: lead.personName || '',
        jobTitle: lead.jobTitle || '',
        companyName: lead.companyName || '',
        companyLinkedInUrl: lead.companyLinkedInUrl || '',
        location: lead.location || '',
        employeeCount: lead.employeeCount || '',
        connectionDegree: lead.connectionDegree || '',
        yearsInRole: lead.yearsInRole || '',
        yearsInCompany: lead.yearsInCompany || '',
        about: lead.about || '',
        premium: !!lead.premium
      });
    }

    _queueScan() {
      if (!this.active || this.scanQueued) return;
      this.scanQueued = true;
      this.scanTimer = setTimeout(() => {
        this.scanTimer = null;
        this.scanQueued = false;
        this.scanNow();
      }, Math.max(25, Number(C.DEFAULTS.liveScanDebounceMs) || 90));
    }

    _scheduleFlush() {
      if (!this.active || this.flushTimer || this.flushRunning) return;
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        void this.flushPending();
      }, Math.max(40, Number(C.DEFAULTS.liveFlushDebounceMs) || 120));
    }

    async flushPending() {
      if (this.flushRunning) return;
      this.flushRunning = true;
      try {
        while (this.pending.size > 0) {
          const entries = [...this.pending.entries()];
          this.pending.clear();
          for (const [key, lead] of entries) {
            try {
              const result = await S.upsertLead(lead);
              if (result.added) this.stats.added += 1;
              else if (result.updated) this.stats.updated += 1;
              else this.stats.duplicates += 1;
              if (this.onSaved) await this.onSaved({ key, lead, result, snapshot: this.snapshot() });
            } catch (error) {
              if (U.isExtensionContextInvalidated?.(error)) throw error;
              this.stats.errors += 1;
              Logger.warning('Live lead save failed', key, error?.message || error);
            }
          }
        }
      } finally {
        this.flushRunning = false;
        this._resolveWaitersIfIdle();
      }
    }

    async flushAndWait() {
      if (!this.active) return this.snapshot();
      this.scanNow();
      await this.flushPending();
      if (this.pending.size === 0 && !this.flushRunning) return this.snapshot();
      await new Promise((resolve) => this.waiters.push(resolve));
      return this.snapshot();
    }

    _resolveWaitersIfIdle() {
      if (this.pending.size > 0 || this.flushRunning) return;
      const waiters = this.waiters.splice(0);
      waiters.forEach((resolve) => resolve());
    }
  }

  root.LXLiveCollector = new LiveCollector();
})(typeof window !== 'undefined' ? window : globalThis);
