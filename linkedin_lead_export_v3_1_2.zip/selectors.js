/* selectors.js — all LinkedIn-facing DOM selectors live in one place. */
(function attachSelectors(root) {
  root.LXSelectors = Object.freeze({
    resultRow: [
      'li.artdeco-list__item[data-x-search-result="LEAD"]',
      'li[data-x-search-result="LEAD"]',
      'ol[data-x-search-results-list] > li',
      'ul.artdeco-list > li.artdeco-list__item',
      'li.artdeco-list__item.pl3.pv3'
    ],
    personLink: [
      'a[data-anonymize="person-name"]',
      'a[href*="/sales/lead/"]',
      'a.ember-view[href*="/sales/lead/"]'
    ],
    personName: [
      '[data-anonymize="person-name"]',
      'span[data-anonymize="person-name"]',
      '.artdeco-entity-lockup__title a',
      '.artdeco-entity-lockup__title span'
    ],
    jobTitle: [
      '[data-anonymize="title"]',
      '[data-anonymize="job-title"]',
      '.artdeco-entity-lockup__subtitle span[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle'
    ],
    companyLink: [
      'a[data-anonymize="company-name"]',
      'a[href*="/sales/company/"]'
    ],
    companyName: [
      '[data-anonymize="company-name"]',
      'a[data-anonymize="company-name"]'
    ],
    location: [
      '[data-anonymize="location"]',
      '.artdeco-entity-lockup__caption span[data-anonymize="location"]'
    ],
    employeeCount: [
      '[data-anonymize="company-size"]',
      '.artdeco-entity-lockup__metadata span:nth-child(1)'
    ],
    connectionDegree: [
      '.artdeco-entity-lockup__degree',
      'span.artdeco-entity-lockup__degree',
      '[data-test-connection-degree]'
    ],
    premiumBadge: [
      'li-icon[type="linkedin-premium-gold-icon"]',
      'svg[data-test-icon="premium-app-medium"]',
      '.premium-icon',
      'img[alt*="Premium"]'
    ],
    about: [
      '[data-anonymize="person-blurb"]',
      '.result-lockup__highlight-keyword',
      '.artdeco-entity-lockup__content p'
    ],
    loading: [
      '[data-test-loading-indicator]',
      '.search-results-container .artdeco-loader',
      '.search-results-container [role="progressbar"]',
      '.search-results-container [aria-busy="true"]'
    ],
    paginationControl: 'button, a',
    nextTextSpan: 'span.artdeco-button__text',
    nextButton: [
      'button[data-test-pagination-next]',
      'button.artdeco-pagination__button--next',
      'button[aria-label*="Next"]',
      'button[title*="Next"]'
    ],
    nextLink: [
      'a[data-test-pagination-next]',
      'a.artdeco-pagination__link--next',
      'a[aria-label*="Next"]',
      'a[title*="Next"]'
    ],
    loadMoreButton: [
      'button[data-test-load-more]',
      'button[aria-label*="Load more"]',
      'button[aria-label*="load more"]',
      'button[title*="Load more"]',
      'button[title*="load more"]',
      'button'
    ],
    securityMarkers: [
      '[data-test-security-challenge]',
      '[data-test-checkpoint]',
      '[data-test-verification]',
      'input[name="captcha"]',
      'iframe[src*="captcha"]',
      'iframe[src*="challenge"]'
    ]
  });
})(typeof window !== 'undefined' ? window : globalThis);
