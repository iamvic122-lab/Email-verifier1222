/* controller.js — persistent state-machine orchestrator with streaming extraction and automatic pagination. */
(function attachController(root) {
  const C = root.LXConstants;
  const S = root.LXStorage;
  const U = root.LX;
  const Logger = root.LXLogger;
  const Wait = root.LXWait;
  const Extractor = root.LXExtractor;
  const Scroll = root.LXScroll;
  const Pagination = root.LXPagination;
  const Safety = root.LXSafety;
  const LiveCollector = root.LXLiveCollector;

  function isContextInvalidated(error) {
    return !!U.isExtensionContextInvalidated?.(error);
  }

  const ACTIVE_STATES = new Set([
    C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
    C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE
  ]);

  class Controller {
    constructor() {
      this.settings = { ...C.DEFAULTS };
      this.state = C.STATES.IDLE;
      this.meta = {};
      this.runPromise = null;
      this.pauseRequested = false;
      this.stopRequested = false;
      this.autoSaveTimer = null;
      this.startedAtMs = 0;
      this.lastProgressAt = 0;
    }

    async init() {
      this.settings = Safety.validateSettings(await S.getSettings());
      Logger.setDebug(this.settings.debugMode);
      this.meta = await S.getMeta();
      this.state = this.meta.state || C.STATES.IDLE;
      if (!this.meta.state) await this._persist({ state: C.STATES.IDLE });
      return this.getSnapshot();
    }

    getSnapshot() {
      return U.clone({ state: this.state, settings: this.settings, ...this.meta, live: LiveCollector.snapshot() });
    }

    async refreshSettings() {
      this.settings = Safety.validateSettings(await S.getSettings());
      Logger.setDebug(this.settings.debugMode);
      return this.settings;
    }

    _baseMeta() {
      const now = new Date().toISOString();
      return {
        state: this.state,
        currentUrl: window.location.href,
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        lastActivityAt: now,
        updatedAt: now
      };
    }

    async _persist(patch = {}) {
      this.meta = { ...this.meta, ...this._baseMeta(), ...patch };
      this.meta = await S.setMeta(this.meta);
      return this.meta;
    }

    async _transition(nextState, patch = {}) {
      this.state = Object.values(C.STATES).includes(nextState) ? nextState : C.STATES.ERROR;
      Logger.info('State →', this.state, patch.reason || '');
      await this._persist({ currentStateReason: patch.reason || '', ...patch });
      return this.state;
    }

    _getPageNumber() {
      try {
        const page = Number(new URL(window.location.href).searchParams.get('page'));
        return Number.isFinite(page) && page > 0 ? page : Number(this.meta.currentPage) || 1;
      } catch (_) {
        return Number(this.meta.currentPage) || 1;
      }
    }

    _isSearchView() {
      return /\/sales\/(search|lists|people)/i.test(window.location.pathname);
    }

    _shouldPause() { return this.pauseRequested || this.state === C.STATES.PAUSED; }
    _shouldStop() { return this.stopRequested || this.state === C.STATES.STOPPED; }

    async _checkSafety(context) {
      if (!this.settings.safetyMode) return { risky: false };
      const result = Safety.detect();
      await this._persist({ lastSafetyCheckAt: new Date().toISOString(), safetyContext: context });
      if (result.risky && this.settings.stopOnSecurityPrompt) {
        Logger.error('Safety guard triggered', result.reason);
        this.stopRequested = true;
        try {
          await this._transition(C.STATES.STOPPED, {
            currentStateReason: 'Safety guard stopped the run.',
            lastError: result.reason,
            safetyEvent: result,
            stoppedAt: new Date().toISOString()
          });
        } catch (error) {
          if (!isContextInvalidated(error)) throw error;
        }
        this._stopAutoSave();
        return result;
      }
      return result;
    }

    async _beforeAction(context) {
      if (this._shouldStop() || this._shouldPause()) return false;
      const safety = await this._checkSafety(context);
      if (safety.risky && this.settings.stopOnSecurityPrompt) return false;
      if (!this.settings.safetyMode) return true;
      const budget = await Safety.waitForActionBudget(this.meta, this.settings, Wait);
      await this._persist(budget);
      return !this._shouldStop() && !this._shouldPause();
    }

    _startAutoSave() {
      this._stopAutoSave();
      if (!this.settings.autoSave) return;
      const schedule = () => {
        this.autoSaveTimer = setTimeout(async () => {
          this.autoSaveTimer = null;
          if ([C.STATES.FINISHED, C.STATES.STOPPED, C.STATES.ERROR].includes(this.state)) return;
          try {
            await this._persist({
              lastAutosaveAt: new Date().toISOString(),
              live: LiveCollector.snapshot()
            });
          } catch (error) {
            if (!isContextInvalidated(error)) Logger.warning('Autosave failed', error?.message || error);
          }
          schedule();
        }, this.settings.autoSaveMs);
      };
      schedule();
    }

    _stopAutoSave() {
      if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }

    async start({ resume = true, currentPage = true } = {}) {
      if (this.runPromise) return this.getSnapshot();
      await this.refreshSettings();
      const existing = await S.getMeta();
      const sameSearch = existing.searchKey && existing.searchKey === U.searchKey(window.location.href);
      const resumable = [
        C.STATES.STARTING, C.STATES.SCROLLING, C.STATES.COLLECTING,
        C.STATES.SAVING, C.STATES.NEXT_PAGE, C.STATES.WAITING_PAGE, C.STATES.PAUSED
      ].includes(existing.state);

      if (resume && this.settings.autoResume && sameSearch && resumable && existing.runId) {
        this.meta = existing;
        this.state = existing.state === C.STATES.PAUSED ? C.STATES.PAUSED : C.STATES.STARTING;
        Logger.info('Resuming run', existing.runId, 'page', existing.currentPage);
      } else {
        this.meta = {
          runId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          searchKey: U.searchKey(window.location.href),
          startedAt: new Date().toISOString(),
          pagesProcessed: 0,
          currentPage: currentPage ? this._getPageNumber() : 1,
          collectedThisRun: 0,
          duplicates: 0,
          errors: 0,
          visitedPages: [],
          lastError: '',
          currentStateReason: 'Run started',
          expectedResultsPerPage: this.settings.expectedResultsPerPage,
          pageCoverage: null,
          actionsInWindow: 0,
          actionWindowStartedAt: Date.now(),
          debug: {}
        };
        this.state = C.STATES.STARTING;
      }

      this.pauseRequested = false;
      this.stopRequested = false;
      this.startedAtMs = Date.now();
      this.lastProgressAt = Date.now();
      this.meta.totalLeads = await S.getLeadCount();
      await this._persist({ totalLeads: this.meta.totalLeads, expectedResultsPerPage: this.settings.expectedResultsPerPage });
      this._startAutoSave();
      this.runPromise = this._runLoop().finally(() => { this.runPromise = null; });
      return this.getSnapshot();
    }

    async pause() {
      this.pauseRequested = true;
      if (![C.STATES.FINISHED, C.STATES.STOPPED].includes(this.state)) {
        this.state = C.STATES.PAUSED;
        await this._persist({ state: C.STATES.PAUSED, currentStateReason: 'Paused by user', live: LiveCollector.snapshot() });
      }
      return this.getSnapshot();
    }

    async resume() {
      await this.refreshSettings();
      this.pauseRequested = false;
      this.stopRequested = false;
      const safety = await this._checkSafety('resume');
      if (safety.risky && this.settings.stopOnSecurityPrompt) return this.getSnapshot();
      if (!this.runPromise) return this.start({ resume: true });
      if (this.state === C.STATES.PAUSED) {
        this.state = C.STATES.STARTING;
        await this._persist({ state: C.STATES.STARTING, currentStateReason: 'Resumed by user' });
      }
      return this.getSnapshot();
    }

    async stop() {
      this.stopRequested = true;
      this.pauseRequested = false;
      this._stopAutoSave();
      await LiveCollector.flushAndWait();
      LiveCollector.stop();
      this.state = C.STATES.STOPPED;
      await this._persist({ state: C.STATES.STOPPED, currentStateReason: 'Stopped by user', stoppedAt: new Date().toISOString() });
      return this.getSnapshot();
    }

    async resetRun() {
      this.pauseRequested = false;
      this.stopRequested = true;
      this._stopAutoSave();
      LiveCollector.stop({ preserveStats: false });
      await S.setMeta({
        state: C.STATES.IDLE,
        currentStateReason: 'Run reset',
        currentPage: this._getPageNumber(),
        searchKey: U.searchKey(window.location.href),
        pagesProcessed: 0,
        collectedThisRun: 0,
        duplicates: 0,
        errors: 0,
        visitedPages: [],
        lastError: '',
        actionsInWindow: 0,
        actionWindowStartedAt: Date.now(),
        pageCoverage: null,
        expectedResultsPerPage: this.settings.expectedResultsPerPage,
        debug: {}
      });
      this.meta = await S.getMeta();
      this.state = C.STATES.IDLE;
      this.stopRequested = false;
      return this.getSnapshot();
    }

    async extractCurrentPage() {
      await this.refreshSettings();
      if (!this._isSearchView()) return { ok: false, reason: 'Open a Sales Navigator people search first.' };
      const collector = LiveCollector.start(U.pageKey(window.location.href), async ({ result, lead, key, snapshot }) => {
        await this._onLeadSaved({ result, lead, key, snapshot });
      });
      await LiveCollector.flushAndWait();
      LiveCollector.stop();
      return { ok: true, foundOnPage: collector.uniquePageLeads, live: LiveCollector.snapshot() };
    }

    async _waitForFirstRows() {
      const timeoutMs = Math.max(5000, Number(this.settings.timeoutMs) || 30000);
      const started = Date.now();
      try {
        const result = await Wait.waitForCondition(() => Extractor.findResultRows().length > 0, {
          root: document.documentElement || document,
          timeoutMs,
          observeAttributes: false,
          shouldCancel: () => this._shouldStop() || this._shouldPause()
        });
        return { ready: true, reason: 'first-row-found', waitedMs: result.waitedMs, rowsVisible: Extractor.findResultRows().length };
      } catch (error) {
        return { ready: false, reason: error.message || 'first-row-timeout', waitedMs: Date.now() - started, rowsVisible: Extractor.findResultRows().length };
      }
    }

    async _onLeadSaved({ result, lead, key, snapshot }) {
      const added = !!result?.added;
      const updated = !!result?.updated;
      const duplicates = !added && !updated ? 1 : 0;
      this.lastProgressAt = Date.now();
      const nextCollected = Number(this.meta.collectedThisRun || 0) + (added ? 1 : 0);
      const totalLeads = await S.getLeadCount();
      await this._persist({
        totalLeads,
        collectedThisRun: nextCollected,
        duplicates: Number(this.meta.duplicates || 0) + duplicates,
        lastSavedLead: key,
        lastSavedAt: new Date().toISOString(),
        currentPageLeadCount: snapshot.uniquePageLeads,
        live: snapshot
      });
      if (added) Logger.success('Lead added live', lead.personName || key);
      else if (updated) Logger.info('Lead updated live', lead.personName || key);
    }

    async _auditCurrentPage() {
      const expected = Math.max(1, Number(this.settings.expectedResultsPerPage) || 25);
      const result = await Scroll.auditCoverage({
        findRows: () => Extractor.findResultRows(),
        settings: this.settings,
        shouldPause: () => this._shouldPause() || this._shouldStop(),
        onScan: async () => {
          LiveCollector.scanNow();
          await LiveCollector.flushPending();
        },
        getUniqueCount: () => LiveCollector.getUniquePageCount(),
        expectedCount: expected
      });
      await LiveCollector.flushAndWait();
      const uniqueCount = LiveCollector.getUniquePageCount();
      const nextControl = Pagination.findNext();
      const lastPage = !nextControl;
      const complete = uniqueCount >= expected || lastPage;
      await this._persist({
        pageCoverage: {
          page: this._getPageNumber(),
          uniqueCollected: uniqueCount,
          expected,
          complete,
          lastPage,
          auditPasses: result.passes,
          auditAttempts: result.attempts,
          auditedAt: new Date().toISOString()
        },
        currentPageLeadCount: uniqueCount,
        scrollProgress: 100
      });
      return { ...result, uniqueCount, expected, complete, lastPage };
    }

    async _processCurrentPage() {
      const pageKey = U.pageKey(window.location.href);
      await this._transition(C.STATES.STARTING, { currentPage: this._getPageNumber(), currentStateReason: 'Waiting for first result row', pageKey });
      const firstRows = await this._waitForFirstRows();
      await this._persist({ lastReadiness: firstRows });
      if (!firstRows.ready) return { ok: false, reason: `No result row appeared before timeout (${this.settings.timeoutMs}ms).` };

      LiveCollector.start(pageKey, async (payload) => this._onLeadSaved(payload));
      await LiveCollector.flushAndWait();

      await this._transition(C.STATES.SCROLLING, { currentPage: this._getPageNumber(), currentStateReason: 'Streaming visible rows while loading the page' });
      const scrollResult = await Scroll.scrollToBottom({
        findRows: () => Extractor.findResultRows(),
        settings: this.settings,
        shouldPause: () => this._shouldPause() || this._shouldStop(),
        onProgress: async (progress) => {
          LiveCollector.scanNow();
          await LiveCollector.flushPending();
          await this._persist({ scrollProgress: progress.progress, scrollTop: progress.scrollTop, loadedRows: progress.rows, live: LiveCollector.snapshot() });
        }
      });
      await LiveCollector.flushAndWait();
      await this._persist({ scrollProgress: scrollResult.progress, scrollTop: scrollResult.scrollTop });
      if (scrollResult.paused) {
        await this.pause();
        return { ok: false, paused: true };
      }

      // Automatically support LinkedIn views that expose a Load more button instead of Next.
      let loadMoreIterations = 0;
      while (!this._shouldStop() && !this._shouldPause()) {
        const action = Pagination.detectAction();
        if (action.type !== 'load-more') break;
        loadMoreIterations += 1;
        if (loadMoreIterations > Math.min(Number(this.settings.maxScrollPasses) || 100, 200)) {
          throw new Error('Load-more loop guard reached its maximum iterations.');
        }
        if (!(await this._beforeAction('auto-load-more'))) return { ok: false };
        await this._transition(C.STATES.NEXT_PAGE, { currentPage: this._getPageNumber(), currentStateReason: `Auto load-more (${loadMoreIterations})`, action: action.type });
        const before = Pagination.getPageDescriptor();
        const result = await Pagination.clickLoadMoreWithRetry(before, this.settings, null, () => this._shouldStop() || this._shouldPause());
        await this._persist({ lastLoadMoreAttempt: { iteration: loadMoreIterations, ...result } });
        if (!result.ok) throw new Error(`Load more failed: ${result.reason}`);
        await LiveCollector.flushAndWait();
        if (result.finished) break;
        await Scroll.scrollToBottom({
          findRows: () => Extractor.findResultRows(),
          settings: { ...this.settings, maxScrollPasses: Math.min(20, this.settings.maxScrollPasses) },
          shouldPause: () => this._shouldPause() || this._shouldStop(),
          onProgress: async (progress) => {
            LiveCollector.scanNow();
            await LiveCollector.flushPending();
            await this._persist({ scrollProgress: progress.progress, scrollTop: progress.scrollTop, loadedRows: progress.rows });
          }
        });
      }

      await this._transition(C.STATES.COLLECTING, { currentPage: this._getPageNumber(), currentStateReason: 'Final streaming coverage audit' });
      const coverage = await this._auditCurrentPage();
      if (coverage.paused) {
        await this.pause();
        return { ok: false, paused: true };
      }

      const descriptor = Pagination.getPageDescriptor();
      const pageId = `${descriptor.searchKey}|${descriptor.pageKey}`;
      const visited = new Set(Array.isArray(this.meta.visitedPages) ? this.meta.visitedPages : []);
      if (visited.has(pageId)) throw new Error('Pagination loop detected: this page was already processed.');
      visited.add(pageId);
      await LiveCollector.flushAndWait();
      await this._transition(C.STATES.SAVING, {
        currentPage: this._getPageNumber(),
        pageRowsFound: descriptor.rowCount,
        pageUniqueCollected: coverage.uniqueCount,
        pageCoverage: coverage,
        currentSelector: Extractor._lastResultSelector || 'auto-detected'
      });
      await this._persist({
        pagesProcessed: Number(this.meta.pagesProcessed || 0) + 1,
        visitedPages: Array.from(visited).slice(-Math.max(1, Number(this.settings.maxPages) || 1000)),
        lastPageSavedAt: new Date().toISOString(),
        pageRowsFound: descriptor.rowCount,
        pageUniqueCollected: coverage.uniqueCount,
        pageCoverage: coverage
      });

      if (this.settings.autoDownload && coverage.uniqueCount > 0 && root.LXExport?.downloadCsv) {
        try {
          root.LXExport.downloadCsv(await S.getLeads());
          await this._persist({ lastAutoDownloadAt: new Date().toISOString(), lastAutoDownloadCount: await S.getLeadCount() });
        } catch (error) {
          Logger.warning('Auto-download failed', error?.message || error);
          await this._persist({ lastAutoDownloadError: error?.message || 'Auto-download failed' });
        }
      }

      return { ok: true, descriptor, coverage, action: Pagination.detectAction() };
    }

    async _runLoop() {
      try {
        const pageGuard = await this._validateSearchContext();
        if (!pageGuard.ok) {
          await this._transition(C.STATES.ERROR, { lastError: pageGuard.reason, errors: Number(this.meta.errors || 0) + 1 });
          return;
        }

        const maxPages = Math.max(1, Number(this.settings.maxPages) || 1000);
        while (!this._shouldStop()) {
          if (this._shouldPause()) {
            await this.pause();
            this._stopAutoSave();
            return;
          }
          if (Number(this.meta.pagesProcessed || 0) >= maxPages) {
            await this._transition(C.STATES.FINISHED, { currentStateReason: 'Maximum page limit reached' });
            break;
          }

          const safety = await this._checkSafety('page-start');
          if (safety.risky && this.settings.stopOnSecurityPrompt) return;
          await this._persist({ currentPage: this._getPageNumber(), currentUrl: window.location.href, searchKey: U.searchKey(window.location.href) });

          const pageResult = await this._processCurrentPage();
          if (!pageResult.ok) {
            if (pageResult.paused) return;
            if (this._shouldStop()) return;
            throw new Error(pageResult.reason || 'Page processing failed.');
          }

          LiveCollector.stop();
          const nextAction = Pagination.detectAction();
          if (!this.settings.autoNextPage || nextAction.type !== 'next-page') {
            await this._transition(C.STATES.FINISHED, {
              currentStateReason: nextAction.type === 'none' ? 'No automatic next-page control detected' : 'Automatic pagination disabled',
              paginationAction: nextAction.type,
              pageUniqueCollected: pageResult.coverage.uniqueCount
            });
            break;
          }

          if (!(await this._beforeAction('auto-next-page'))) return;
          const previous = Pagination.getPageDescriptor();
          const first = Extractor.findResultRows()[0];
          previous.firstKey = first ? Extractor.rowSignature(first) : '';
          await this._transition(C.STATES.NEXT_PAGE, {
            currentPage: this._getPageNumber(),
            navigationPending: true,
            navigationStartedAt: new Date().toISOString(),
            navigationFromUrl: previous.url,
            navigationFromPageKey: previous.pageKey,
            currentSignature: previous.signature,
            paginationSelector: nextAction.selector
          });

          const next = await Pagination.clickNextWithRetry(previous, this.settings, null, () => this._shouldStop() || this._shouldPause());
          if (!next.ok) throw new Error(`Next page failed: ${next.reason}`);

          await this._transition(C.STATES.WAITING_PAGE, {
            currentPage: this._getPageNumber(),
            currentUrl: window.location.href,
            pageChangeWaitMs: next.waitedMs || 0,
            scrollTop: 0,
            scrollProgress: 0,
            resumePageKey: U.pageKey(window.location.href),
            navigationPending: false,
            navigationCompletedAt: new Date().toISOString()
          });

          // Do not wait for the entire next page. The next loop immediately waits only for the first row,
          // then LiveCollector starts saving rows incrementally as LinkedIn renders them.
          if (U.searchKey(window.location.href) !== this.meta.searchKey) throw new Error('Search context changed during pagination; run stopped to prevent mixing datasets.');
        }
      } catch (error) {
        if (isContextInvalidated(error)) {
          LiveCollector.stop();
          try { console.warn('[LX] Extension context invalidated; controller instance ended safely. Checkpointed state can be resumed by the next content context.'); } catch (_) {}
          return;
        }
        Logger.error('Controller failed', error?.message || error);
        try {
          await this._transition(C.STATES.ERROR, {
            lastError: error?.message || 'Unknown controller error',
            errors: Number(this.meta.errors || 0) + 1,
            debug: {
              currentState: this.state,
              currentUrl: window.location.href,
              currentPage: this._getPageNumber(),
              lastError: error?.message || 'Unknown controller error'
            }
          });
        } catch (persistError) {
          if (!isContextInvalidated(persistError)) Logger.error('Failed to persist controller error state', persistError?.message || persistError);
        }
      } finally {
        LiveCollector.stop();
        this._stopAutoSave();
      }
    }

    async _validateSearchContext() {
      if (!this._isSearchView()) return { ok: false, reason: 'Open a Sales Navigator search/list/people view before starting.' };
      const existing = await S.getMeta();
      if (existing.searchKey && existing.searchKey !== U.searchKey(window.location.href) && existing.state && ![C.STATES.IDLE, C.STATES.STOPPED, C.STATES.FINISHED].includes(existing.state)) {
        return { ok: false, reason: 'The current search does not match the saved run. Reset the run before starting a different search.' };
      }
      return { ok: true };
    }
  }

  root.LXController = new Controller();
})(typeof window !== 'undefined' ? window : globalThis);
